<#
    FirstBaseBuildIdentity.ps1  (Project LoneWolf)

    Single source of truth for "is this a dev build?" and the version numbers
    that go beside that answer. Dot-sourced by every surface that shows a DEV
    marker: the WinPE banner and deploy screen (destage = red chrome, no DEV tag), the on-device updates splash,
    the handoff splash, and the fb-im technician tool.

    WHY THIS FILE EXISTS
    The same question used to be answered four different ways. Three of them
    read the build stamp; the fourth also treated $FirstBaseBuildStatus from
    FirstBaseVersion.ps1 as a dev signal. That variable is a checked-in
    constant - it cannot know how a given stick was built - so every release
    build inherited whatever value happened to be committed and wrongly showed
    a DEV marker. Build status is a property of the BUILD, so it may only come
    from artifacts the builder stamps per build.

    THE TWO AUTHORITATIVE SIGNALS (in order)
      1. LW_VERSION.json  - written by both builders on every build. npm start
         destage stamps destage=true and channel=destage (plus legacy
         devBuild). Packaged LoneWolf Launcher Dev and production do not.
      2. .dev-build       - a key=value marker the builders write ONLY when
         destaging from npm start (-DevBuild). Present at <root>\.dev-build on
         a device (staged by TechInstall) and <root>\WUPayload\.dev-build on a
         stick.

    RELEASE-SAFE BY DEFAULT: absent or unreadable signals mean release. A destage
    stick missing its pill is cosmetic; a release device claiming DEV is the
    bug this file exists to prevent. Channel "dev" (packaged Launcher Dev) is
    NOT a destage signal.

    Must stay usable in the WinPE PowerShell 5.1 restricted runspace: no
    classes, no modules, no external calls, and it never throws.
#>

function Test-FbJsonTruthy {
    param($Value)
    if ($null -eq $Value) { return $false }
    if ($Value -eq $true -or $Value -eq 1) { return $true }
    $s = [string]$Value
    if ([string]::IsNullOrWhiteSpace($s)) { return $false }
    return ($s -match '^(true|1|yes|destage)$')
}

function Test-FbStampIsDestage {
    param($Json)
    if (-not $Json) { return $false }
    try {
        if ($Json.PSObject.Properties['destage'] -and (Test-FbJsonTruthy $Json.destage)) { return $true }
    } catch {}
    try {
        if ($Json.PSObject.Properties['channel'] -and [string]$Json.channel -eq 'destage') { return $true }
    } catch {}
    return $false
}

function Test-FbStampSkipWu {
    # destageSkipWu is destage-only (npm start:updatesfinished). Never honor it
    # on packaged Destage / production stamps.
    param($Json)
    if (-not (Test-FbStampIsDestage $Json)) { return $false }
    try {
        if ($Json.PSObject.Properties['destageSkipWu'] -and (Test-FbJsonTruthy $Json.destageSkipWu)) { return $true }
    } catch {}
    return $false
}

function Test-FbStampIsDev {
    param($Json)
    if (Test-FbStampIsDestage $Json) { return $true }
    try {
        if ($Json.PSObject.Properties['devBuild'] -and (Test-FbJsonTruthy $Json.devBuild)) { return $true }
    } catch {}
    return $false
}

function Get-FbBuildIdentity {
    <#
        -PayloadRoot : one or more directories to probe, most authoritative
                       first. Callers pass whatever they know:
                         WinPE banner / deploy UI - parent of Deploy\, then the volume root
                         on-device splashes       - C:\Windows\Setup\FirstBase
                         fb-im                    - stick payload root, then the device root
    #>
    param([string[]] $PayloadRoot)

    $info = [ordered]@{
        Dev           = $false
        Destage       = $false
        DestageSkipWu = $false
        Channel       = ''
        Launcher      = ''
        Script        = ''
        ShareLauncher = ''
        ShareScript   = ''
        ImageBuildDate = ''
        Source        = ''   # which signal decided Dev; '' when none was found
    }

    $roots = @()
    foreach ($r in @($PayloadRoot)) {
        if ([string]::IsNullOrWhiteSpace($r)) { continue }
        $roots += ([string]$r).TrimEnd('\')
    }
    if ($roots.Count -eq 0) { return $info }

    # --- Signal 1: LW_VERSION.json -------------------------------------------
    # First readable stamp wins for the version numbers, so the nearest root is
    # authoritative rather than whichever happens to be dev.
    foreach ($root in $roots) {
        $stamp = Join-Path $root 'LW_VERSION.json'
        if (-not (Test-Path -LiteralPath $stamp)) { continue }
        try {
            $j = Get-Content -LiteralPath $stamp -Raw -ErrorAction Stop | ConvertFrom-Json
        } catch { continue }

        $isDestage = Test-FbStampIsDestage $j
        if ($isDestage) {
            $info.Destage = $true
            $info.Channel = 'destage'
            if (Test-FbStampSkipWu $j) { $info.DestageSkipWu = $true }
        } elseif ($j.PSObject.Properties['channel'] -and $j.channel) {
            $info.Channel = [string]$j.channel
        }
        if (Test-FbStampIsDev $j) {
            $info.Dev = $true
            $info.Source = 'LW_VERSION.json'
        }
        # StrictMode Latest (the WU loop) throws if a slim LW_VERSION.json
        # omits launcherVersion. Read only properties that exist.
        $lvProp = $j.PSObject.Properties['launcherVersion']
        if ($lvProp -and $lvProp.Value) { $info.Launcher = [string]$lvProp.Value }
        $pvProp = $j.PSObject.Properties['payloadVersion']
        $svProp = $j.PSObject.Properties['scriptVersion']
        $vProp = $j.PSObject.Properties['version']
        if ($pvProp -and $pvProp.Value) { $info.Script = [string]$pvProp.Value }
        elseif ($svProp -and $svProp.Value) { $info.Script = [string]$svProp.Value }
        elseif ($vProp -and $vProp.Value) { $info.Script = [string]$vProp.Value }
        $slProp = $j.PSObject.Properties['shareLauncherVersion']
        $ssProp = $j.PSObject.Properties['shareScriptVersion']
        if ($slProp -and $slProp.Value) { $info.ShareLauncher = [string]$slProp.Value }
        if ($ssProp -and $ssProp.Value) { $info.ShareScript = [string]$ssProp.Value }
        foreach ($dateKey in @('imageBuildDate', 'buildDate', 'wimBuildDate')) {
            try {
                $dp = $j.PSObject.Properties[$dateKey]
                if ($dp -and $dp.Value) {
                    $info.ImageBuildDate = [string]$dp.Value
                    break
                }
            } catch {}
        }
        break
    }

    # --- Signal 2: .dev-build marker -----------------------------------------
    # Only dev builds carry it, so its mere presence is the answer. Checked even
    # when a stamp was found, because a WIN-INSTALL stick can ship the marker
    # without a devBuild flag in the stamp.
    if (-not $info.Dev) {
        foreach ($root in $roots) {
            foreach ($rel in @('.dev-build', 'WUPayload\.dev-build')) {
                $marker = Join-Path $root $rel
                if (-not (Test-Path -LiteralPath $marker)) { continue }
                $info.Dev = $true
                $info.Destage = $true
                if (-not $info.Channel) { $info.Channel = 'destage' }
                $info.Source = $rel
                # The marker also carries versions, useful when no stamp was found.
                if (-not $info.Launcher -or -not $info.Script) {
                    try {
                        foreach ($line in (Get-Content -LiteralPath $marker -ErrorAction Stop)) {
                            $kv = ([string]$line).Split('=', 2)
                            if ($kv.Count -ne 2) { continue }
                            switch ($kv[0].Trim()) {
                                'launcherVersion'      { if (-not $info.Launcher)      { $info.Launcher      = $kv[1].Trim() } }
                                'payloadVersion'       { if (-not $info.Script)        { $info.Script        = $kv[1].Trim() } }
                                'scriptVersion'        { if (-not $info.Script)        { $info.Script        = $kv[1].Trim() } }
                                'shareLauncherVersion' { if (-not $info.ShareLauncher) { $info.ShareLauncher = $kv[1].Trim() } }
                                'shareScriptVersion'   { if (-not $info.ShareScript)   { $info.ShareScript   = $kv[1].Trim() } }
                                'channel'              { if (-not $info.Channel)       { $info.Channel       = $kv[1].Trim() } }
                                'destageSkipWu'        {
                                    if ((Test-FbJsonTruthy $kv[1].Trim()) -and $info.Destage) {
                                        $info.DestageSkipWu = $true
                                    }
                                }
                            }
                        }
                    } catch {}
                }
                break
            }
            if ($info.Dev) { break }
        }
    }

    return $info
}

function Get-FbBuildIdentityForScript {
    <#
        Convenience wrapper for the common case: resolve identity relative to a
        script's own location. -ScriptRoot is the caller's $PSScriptRoot.

        -Layout Deploy : the caller lives in <payload>\Deploy\, so the payload
                         root is its parent and the volume root its grandparent
                         (a legacy flat stick collapses those two).
        -Layout Payload: the caller lives in the payload root itself - the
                         device's C:\Windows\Setup\FirstBase, or WUPayload\ on a
                         stick.
    #>
    param(
        [string] $ScriptRoot,
        [ValidateSet('Deploy', 'Payload')]
        [string] $Layout = 'Payload'
    )

    if ([string]::IsNullOrWhiteSpace($ScriptRoot)) { return (Get-FbBuildIdentity -PayloadRoot @()) }

    $roots = @($ScriptRoot)
    try {
        $parent = Split-Path -Path $ScriptRoot -Parent
        if ($parent) {
            $roots += $parent
            if ($Layout -eq 'Deploy') {
                $grand = Split-Path -Path $parent -Parent
                if ($grand) { $roots += $grand }
            }
        }
    } catch {}

    if ($Layout -eq 'Deploy') {
        # Drop the script's own folder: Deploy\ never holds the stamp, and
        # probing it first would only waste a Test-Path per call.
        $roots = $roots | Select-Object -Skip 1
    }

    return (Get-FbBuildIdentity -PayloadRoot $roots)
}
