# FirstBase hardware gate — Wi-Fi, camera, usable sound, and critical PnP.
# Called from Invoke-FbOobeHandoff STAGE 2 in the Administrator audit session.
# A check PASSES only when Windows can actually see the device/capability.
# Driver-present-but-error (yellow bang / ConfigManagerErrorCode != 0) is FAIL.
# Missing script or a thrown probe is FAIL — never skip-as-pass.
# PnP extra: present Net/MEDIA/Camera (and System problem 28) must not be Error.
#
# "Usable volume sliders" means active Core Audio endpoints exist for both
# render (output) and capture (input) so Settings and the volume flyout can
# bind. This does NOT UI-robot the sliders (fragile in Audit/OOBE).
# For Internal Use Only.

[CmdletBinding()]
param(
    [string]$ResultPath = '',
    [switch]$Quiet,
    [switch]$DefinitionsOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

$FbPd = 'C:\ProgramData\FirstBase'
$FbRoot = 'C:\Windows\Setup\FirstBase'
if ([string]::IsNullOrWhiteSpace($ResultPath)) {
    $ResultPath = Join-Path $FbPd '.hardware-gate-result.json'
}
$HwRunningMarker = Join-Path $FbPd '.hardware-gate-running'

$fbVer = Join-Path $PSScriptRoot 'FirstBaseVersion.ps1'
if (-not (Test-Path -LiteralPath $fbVer)) { $fbVer = Join-Path $FbRoot 'FirstBaseVersion.ps1' }
if (Test-Path -LiteralPath $fbVer) { . $fbVer }
if (-not (Get-Variable -Name FirstBasePayloadRevision -ErrorAction SilentlyContinue)) {
    $FirstBaseProductVersion = '1.0.0'
    $FirstBasePayloadRevision = 'unknown'
    $FirstBaseScriptVersion = @{}
}
$script:ThisScriptVersion = [string]$FirstBaseScriptVersion['FirstBaseHardwareCheck.ps1']
if ([string]::IsNullOrWhiteSpace($script:ThisScriptVersion)) { $script:ThisScriptVersion = $FirstBaseProductVersion }

function Write-FbHardwareCheckLog {
    param([string]$Message, [string]$Level = 'INFO')
    $line = ('[{0}] [{1}] [hw-gate] {2}' -f (Get-Date -Format 'o'), $Level, $Message)
    foreach ($dir in @($FbPd, (Join-Path $FbRoot 'Logs'))) {
        try {
            if (-not (Test-Path -LiteralPath $dir)) {
                New-Item -ItemType Directory -Path $dir -Force -ErrorAction SilentlyContinue | Out-Null
            }
            Add-Content -LiteralPath (Join-Path $dir 'WU-hardware-gate.log') -Value $line -Encoding ascii -ErrorAction SilentlyContinue
        } catch {}
    }
}

function New-FbHardwareCheckItem {
    param(
        [string]$Name,
        [bool]$Passed,
        [string]$Detail,
        [string]$State = ''
    )
    return [pscustomobject]@{
        Name   = $Name
        Passed = [bool]$Passed
        Detail = [string]$Detail
        State  = [string]$State
    }
}

function Get-FbSecureBootProbeState {
    $reasons = New-Object System.Collections.Generic.List[string]
    $passed = $false
    $state = 'Not available'
    $detail = ''
    try {
        $sbReg = Get-ItemProperty `
            -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' `
            -Name 'UEFISecureBootEnabled' `
            -ErrorAction Stop
        $sbVal = [int]$sbReg.UEFISecureBootEnabled
        if ($sbVal -eq 1) {
            $passed = $true
            $state = 'Enabled'
            $detail = 'Secure Boot: Enabled (UEFISecureBootEnabled=1).'
        } else {
            $state = 'Disabled'
            [void]$reasons.Add('UEFISecureBootEnabled=0')
        }
    } catch {
        [void]$reasons.Add('registry state unavailable')
    }
    if (-not $passed) {
        try {
            if (Get-Command Confirm-SecureBootUEFI -ErrorAction SilentlyContinue) {
                $sbCmd = Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
                if ($sbCmd -eq $true) {
                    $passed = $true
                    $state = 'Enabled'
                    $detail = 'Secure Boot: Enabled (Confirm-SecureBootUEFI).'
                    $reasons.Clear()
                } elseif ($sbCmd -eq $false) {
                    $state = 'Disabled'
                    if ($reasons.Count -eq 0) { [void]$reasons.Add('Confirm-SecureBootUEFI=false') }
                }
            }
        } catch {}
    }
    if (-not $passed) {
        if ($state -eq 'Disabled') {
            $detail = ('Secure Boot: Disabled ({0}).' -f ($reasons -join '; '))
        } else {
            $state = 'Not available'
            if ($reasons.Count -eq 0) { [void]$reasons.Add('could not read state') }
            $detail = ('Secure Boot: Not available ({0}).' -f ($reasons -join '; '))
        }
    }
    return [pscustomobject]@{
        Passed = [bool]$passed
        State  = [string]$state
        Detail = [string]$detail
    }
}

function Get-FbActiveMmAudioEndpoints {
    param([ValidateSet('Render', 'Capture')][string]$Flow)
    $key = Join-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio' $Flow
    $hits = New-Object System.Collections.Generic.List[string]
    if (-not (Test-Path -LiteralPath $key)) { return @() }
    try {
        foreach ($dev in @(Get-ChildItem -LiteralPath $key -ErrorAction SilentlyContinue)) {
            if (-not $dev) { continue }
            $state = 0
            try { $state = [int](Get-ItemProperty -LiteralPath $dev.PSPath -Name DeviceState -ErrorAction SilentlyContinue).DeviceState } catch { $state = 0 }
            # DeviceState low nibble: 1=ACTIVE 2=DISABLED 4=NOTPRESENT 8=UNPLUGGED
            if (($state -band 0xF) -ne 1) { continue }
            $label = $dev.PSChildName
            try {
                $propKey = Join-Path $dev.PSPath 'Properties'
                if (Test-Path -LiteralPath $propKey) {
                    $p = Get-ItemProperty -LiteralPath $propKey -ErrorAction SilentlyContinue
                    foreach ($n in @('{a45c254e-df1c-4efd-8020-67d146a850e0},2', 'Name', 'FriendlyName')) {
                        if ($p -and $p.PSObject.Properties.Name -contains $n -and -not [string]::IsNullOrWhiteSpace([string]$p.$n)) {
                            $label = [string]$p.$n
                            break
                        }
                    }
                }
            } catch {}
            [void]$hits.Add($label)
        }
    } catch {}
    return @($hits)
}

function Get-FbPnpMicrophoneNames {
    $ok = New-Object System.Collections.Generic.List[string]
    foreach ($cls in @('MEDIA', 'AudioEndpoint', 'SoftwareDevice')) {
        try {
            foreach ($dev in @(Get-FbPnpDevicesPresent -ClassName $cls)) {
                if (-not $dev) { continue }
                $name = [string]$dev.FriendlyName
                if ([string]::IsNullOrWhiteSpace($name)) { $name = [string]$dev.InstanceId }
                if ($name -notmatch '(?i)microphone|mic array|\bmic\b|capture') { continue }
                if ($name -match '(?i)speaker|headphone|hdmi|display audio') { continue }
                $problem = 0
                try {
                    if ($null -ne $dev.Problem -and [string]$dev.Problem -ne '') { $problem = [int]$dev.Problem }
                } catch { $problem = 0 }
                if ([string]$dev.Status -eq 'OK' -and $problem -eq 0) {
                    [void]$ok.Add($name)
                }
            }
        } catch {}
    }
    return @($ok)
}

function Test-FbHardwareSecureBoot {
    $probe = Get-FbSecureBootProbeState
    return New-FbHardwareCheckItem -Name 'secureboot' -Passed $probe.Passed -Detail $probe.Detail -State $probe.State
}

function Test-FbHardwareSound {
    # Volume flyout / ms-settings:sound bind to Core Audio endpoints.
    # After a WU/driver reboot the mic often is not ACTIVE for several
    # seconds (or only shows as PnP OK). Retry before failing.
    $reasons = New-Object System.Collections.Generic.List[string]
    $svc = $null
    try { $svc = Get-Service -Name 'Audiosrv' -ErrorAction SilentlyContinue } catch {}
    if (-not $svc) {
        return New-FbHardwareCheckItem -Name 'sound' -Passed $false -Detail 'Windows Audio service (Audiosrv) is missing.'
    }
    if ($svc.Status -ne 'Running') {
        try { Start-Service -Name 'Audiosrv' -ErrorAction SilentlyContinue } catch {}
        Start-Sleep -Milliseconds 800
        try { $svc = Get-Service -Name 'Audiosrv' -ErrorAction SilentlyContinue } catch {}
    }
    if (-not $svc -or $svc.Status -ne 'Running') {
        return New-FbHardwareCheckItem -Name 'sound' -Passed $false -Detail ('Windows Audio service is {0}; volume sliders cannot bind.' -f $(if ($svc) { $svc.Status } else { 'missing' }))
    }

    $render = @()
    $capture = @()
    $pnpMics = @()
    $attempts = 12
    for ($i = 1; $i -le $attempts; $i++) {
        $render = @(Get-FbActiveMmAudioEndpoints -Flow Render)
        $capture = @(Get-FbActiveMmAudioEndpoints -Flow Capture)
        $pnpMics = @(Get-FbPnpMicrophoneNames)
        if ($render.Count -gt 0 -and ($capture.Count -gt 0 -or $pnpMics.Count -gt 0)) { break }
        Write-FbHardwareCheckLog ("sound retry {0}/{1}: render={2} capture={3} pnpMic={4}" -f $i, $attempts, $render.Count, $capture.Count, $pnpMics.Count) 'INFO'
        Start-Sleep -Seconds 2
        try { Start-Service -Name 'Audiosrv' -ErrorAction SilentlyContinue } catch {}
    }
    if ($render.Count -eq 0) { [void]$reasons.Add('no ACTIVE render (output) endpoint') }
    if ($capture.Count -eq 0 -and $pnpMics.Count -eq 0) {
        [void]$reasons.Add('no ACTIVE capture (microphone) endpoint and no working microphone PnP')
    }

    # PnP corroboration: do not treat error-state MEDIA devices as a pass.
    # Get-PnpDevice -Class does not accept a comma list (FBTGJB4: "Argument types do not match").
    $pnpAudioOk = $false
    try {
        $pnp = @()
        foreach ($cls in @('MEDIA', 'AudioEndpoint')) {
            foreach ($dev in @(Get-FbPnpDevicesPresent -ClassName $cls)) {
                $problem = 0
                try {
                    if ($null -ne $dev.Problem -and [string]$dev.Problem -ne '') { $problem = [int]$dev.Problem }
                } catch { $problem = 0 }
                if ([string]$dev.Status -eq 'OK' -and $problem -eq 0) { $pnp += $dev }
            }
        }
        $pnpAudioOk = ($pnp.Count -gt 0)
    } catch {
        try {
            $pnp = @(Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object {
                $_.ConfigManagerErrorCode -eq 0 -and
                ($_.PNPClass -eq 'MEDIA' -or $_.PNPClass -eq 'AudioEndpoint' -or $_.Name -match 'Audio|High Definition|Sound')
            })
            $pnpAudioOk = ($pnp.Count -gt 0)
        } catch {}
    }
    if (-not $pnpAudioOk -and ($render.Count -eq 0 -or ($capture.Count -eq 0 -and $pnpMics.Count -eq 0))) {
        [void]$reasons.Add('no working audio PnP device')
    }

    $passed = ($reasons.Count -eq 0)
    $detail = if ($passed) {
        $capText = if ($capture.Count -gt 0) { ($capture -join ', ') } else { ('PnP {0}' -f ($pnpMics -join ', ')) }
        ('Audiosrv running; ACTIVE render={0}; capture={1} (volume sliders can bind).' -f ($render -join ', '), $capText)
    } else {
        ('Sound not visible/usable: {0}.' -f ($reasons -join '; '))
    }
    return New-FbHardwareCheckItem -Name 'sound' -Passed $passed -Detail $detail
}

function Test-FbHardwareCamera {
    $ok = New-Object System.Collections.Generic.List[string]
    try {
        foreach ($dev in @(Get-PnpDevice -Class Camera -ErrorAction SilentlyContinue)) {
            if (-not $dev) { continue }
            $problem = 0
            try { $problem = [int]$dev.Problem } catch { $problem = 0 }
            if ($dev.Status -eq 'OK' -and $problem -eq 0) {
                [void]$ok.Add([string]$dev.FriendlyName)
            }
        }
    } catch {}
    if ($ok.Count -eq 0) {
        try {
            foreach ($dev in @(Get-PnpDevice -Class Image -ErrorAction SilentlyContinue)) {
                if (-not $dev) { continue }
                $name = [string]$dev.FriendlyName
                if ($name -notmatch '(?i)camera|webcam|integrated cam') { continue }
                if ($name -match '(?i)scanner|printer') { continue }
                $problem = 0
                try { $problem = [int]$dev.Problem } catch { $problem = 0 }
                if ($dev.Status -eq 'OK' -and $problem -eq 0) {
                    [void]$ok.Add($name)
                }
            }
        } catch {}
    }
    if ($ok.Count -eq 0) {
        try {
            foreach ($ent in @(Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue)) {
                if (-not $ent) { continue }
                $cls = [string]$ent.PNPClass
                $nm = [string]$ent.Name
                $isCam = ($cls -eq 'Camera') -or ($cls -eq 'Image' -and $nm -match '(?i)camera|webcam')
                if (-not $isCam) { continue }
                if ([int]$ent.ConfigManagerErrorCode -eq 0 -and $ent.Status -eq 'OK') {
                    [void]$ok.Add($nm)
                }
            }
        } catch {}
    }
    $passed = ($ok.Count -gt 0)
    $detail = if ($passed) {
        ('Internal camera visible to Windows: {0}.' -f ($ok -join ', '))
    } else {
        'No working camera PnP device (Status=OK, ConfigManagerErrorCode=0). Driver-present-with-error is not a pass.'
    }
    return New-FbHardwareCheckItem -Name 'camera' -Passed $passed -Detail $detail
}

function Test-FbHardwareWifi {
    $reasons = New-Object System.Collections.Generic.List[string]
    try {
        $svc = Get-Service -Name 'WlanSvc' -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Running') {
            try { Start-Service -Name 'WlanSvc' -ErrorAction SilentlyContinue } catch {}
            Start-Sleep -Milliseconds 800
            try { $svc = Get-Service -Name 'WlanSvc' -ErrorAction SilentlyContinue } catch {}
        }
        if (-not $svc -or $svc.Status -ne 'Running') {
            [void]$reasons.Add(('WLAN AutoConfig is {0}' -f $(if ($svc) { [string]$svc.Status } else { 'missing' })))
        }
    } catch {
        [void]$reasons.Add(('WLAN AutoConfig probe threw: {0}' -f $_.Exception.Message))
    }

    $adapters = @()
    try {
        $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object {
            $ifType = 0
            try { $ifType = [int]$_.InterfaceType } catch { $ifType = 0 }
            $medium = ''
            try { $medium = [string]$_.NdisPhysicalMedium } catch { $medium = '' }
            ($ifType -eq 71) -or
            ($medium -match 'Native802_11|802.11') -or
            ($_.InterfaceDescription -match '(?i)wi-?fi|wireless|802\.11|wlan') -or
            ($_.Name -match '(?i)wi-?fi|wireless|wlan')
        })
    } catch {}

    if ($adapters.Count -eq 0) {
        [void]$reasons.Add('no Wi-Fi adapter visible to Windows')
    } else {
        $up = @($adapters | Where-Object { $_.Status -eq 'Up' -or $_.AdminStatus -eq 'Up' })
        $disabled = @($adapters | Where-Object { $_.Status -eq 'Disabled' -or $_.AdminStatus -eq 'Down' })
        if ($up.Count -eq 0) {
            [void]$reasons.Add(('Wi-Fi adapter present but not up (status={0})' -f (($adapters | ForEach-Object { '{0}:{1}' -f $_.Name, $_.Status }) -join ', ')))
        }
        if ($disabled.Count -eq $adapters.Count) {
            [void]$reasons.Add('all Wi-Fi adapters are disabled')
        }
    }

    $scanOut = ''
    $scanOk = $false
    $visibleCount = -1
    try {
        $scanOut = [string](& netsh.exe wlan show networks 2>&1 | Out-String)
        if ($scanOut -match '(?i)there is no wireless interface') {
            [void]$reasons.Add('netsh: no wireless interface')
        } elseif ($scanOut -match '(?i)interface is powered down|radio is off|powered off') {
            [void]$reasons.Add('Wi-Fi radio is off / powered down')
        } elseif ($scanOut -match '(?i)not running|WLAN AutoConfig') {
            [void]$reasons.Add('netsh cannot scan (WLAN service)')
        } elseif ($scanOut -match '(?i)The following command was not found|is not recognized') {
            [void]$reasons.Add('netsh wlan show networks is unavailable')
        } else {
            $scanOk = $true
            if ($scanOut -match '(?i)There are (\d+) networks currently visible') {
                $visibleCount = [int]$Matches[1]
            } elseif ($scanOut -match '(?i)SSID\s+\d+\s*:') {
                $visibleCount = @([regex]::Matches($scanOut, '(?i)SSID\s+\d+\s*:')).Count
            } else {
                $visibleCount = 0
            }
        }
    } catch {
        [void]$reasons.Add(('Wi-Fi scan threw: {0}' -f $_.Exception.Message))
    }

    # Scan capability is enough — 0 visible SSIDs still passes (warehouse with no AP).
    # Connected-to-a-specific-SSID is NOT required.
    $passed = ($reasons.Count -eq 0) -and $scanOk
    $detail = if ($passed) {
        ('Adapter up; radio on; scan completed (visible networks={0}; SSID association not required).' -f $visibleCount)
    } else {
        ('Wi-Fi not usable: {0}.' -f ($reasons -join '; '))
    }
    if ($passed -and $visibleCount -eq 0) {
        $detail += ' Scan returned zero SSIDs; interface can scan so this is still a pass.'
    }
    return New-FbHardwareCheckItem -Name 'wifi' -Passed $passed -Detail $detail
}

function Get-FbPnpDevicesPresent {
    param([string]$ClassName)
    $hits = New-Object System.Collections.Generic.List[object]
    # One class string per call. Do not wrap List[object] of CIM devices in @() —
    # Windows PowerShell 5.1 throws ArgumentException "Argument types do not match"
    # (FBTGJB4: sound/camera/wifi PASS, pnp=FAIL with working hardware).
    try {
        foreach ($dev in @(Get-PnpDevice -Class $ClassName -ErrorAction SilentlyContinue)) {
            if (-not $dev) { continue }
            $present = $true
            try {
                if ($null -ne $dev.PSObject.Properties['Present']) { $present = [bool]$dev.Present }
            } catch { $present = $true }
            if ($present) { [void]$hits.Add($dev) }
        }
    } catch {}
    return $hits.ToArray()
}

function Test-FbHardwareCriticalPnp {
    # Extra fail if present Net / MEDIA / Camera (and System with no-driver)
    # show Error after WUA claimed driver installs. Inbox adapters can look
    # OK while OEM packages never committed (YouTube-on-pass with missing OEM).
    $bad = New-Object System.Collections.Generic.List[string]
    $failProblems = @(10, 19, 28, 31, 39, 43)
    $skipNet = '(?i)WAN Miniport|Kernel Debug|Wi-?Fi Direct|Virtual Adapter|Teredo|Microsoft Hosted Network|Bluetooth Device \(Personal Area Network\)|TAP-|Hyper-V|Npcap|Loopback'
    foreach ($tuple in @(
        @{ Class = 'Net'; Mode = 'net' }
        @{ Class = 'MEDIA'; Mode = 'media' }
        @{ Class = 'AudioEndpoint'; Mode = 'media' }
        @{ Class = 'Camera'; Mode = 'camera' }
        @{ Class = 'Image'; Mode = 'image' }
        @{ Class = 'System'; Mode = 'system' }
    )) {
        foreach ($dev in @(Get-FbPnpDevicesPresent -ClassName $tuple.Class)) {
            if (-not $dev) { continue }
            $name = ''
            $st = ''
            $problem = 0
            try {
                $name = [string]$dev.FriendlyName
                if ([string]::IsNullOrWhiteSpace($name)) { $name = [string]$dev.InstanceId }
                $st = [string]$dev.Status
                if ($null -ne $dev.Problem -and [string]$dev.Problem -ne '') {
                    $problem = [int]$dev.Problem
                }
            } catch {
                continue
            }
            if ($problem -eq 22) { continue }
            if ($tuple.Mode -eq 'net' -and $name -match $skipNet) { continue }
            if ($tuple.Mode -eq 'image' -and $name -notmatch '(?i)camera|webcam|integrated cam') { continue }
            if ($tuple.Mode -eq 'image' -and $name -match '(?i)scanner|printer') { continue }
            if ($tuple.Mode -eq 'system') {
                if ($problem -eq 28) {
                    [void]$bad.Add(('System/{0} problem=28 (no driver)' -f $name))
                }
                continue
            }
            $isBadStatus = ($st -eq 'Error' -or $st -eq 'Unknown' -or $st -eq 'Degraded')
            $isBadProblem = ($failProblems -contains $problem)
            if ($isBadStatus -or $isBadProblem) {
                [void]$bad.Add(('{0}/{1} Status={2} Problem={3}' -f $tuple.Class, $name, $st, $problem))
            }
        }
    }
    $unique = @($bad | Select-Object -Unique)
    if ($unique.Count -gt 8) {
        $unique = @($unique[0..7] + (('...and {0} more' -f ($bad.Count - 8))))
    }
    $passed = ($bad.Count -eq 0)
    $detail = if ($passed) {
        'No Error/Unknown present Net, MEDIA, or Camera devices; no System devices with problem 28 (no driver).'
    } else {
        ('PnP driver errors: {0}' -f ($unique -join '; '))
    }
    return New-FbHardwareCheckItem -Name 'pnp' -Passed $passed -Detail $detail
}

function Set-FbHardwareCheckSplashStatus {
    param(
        [string]$Phase = 'HardwareChecks',
        [string]$Message
    )
    $statusPath = Join-Path $FbRoot 'wu-status.json'
    $updates = @()
    try {
        if (Test-Path -LiteralPath $statusPath) {
            $prev = Get-Content -LiteralPath $statusPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if ($prev -and $prev.updates) { $updates = @($prev.updates) }
        }
    } catch {}
    $payload = @{
        phase     = $Phase
        message   = $Message
        updatedAt = (Get-Date).ToString('o')
        updates   = $updates
    }
    try {
        [System.IO.File]::WriteAllText($statusPath, ($payload | ConvertTo-Json -Depth 6), [System.Text.Encoding]::UTF8)
    } catch {
        try { Write-FbHardwareCheckLog ("splash status write failed: {0}" -f $_.Exception.Message) 'WARN' } catch {}
    }
}

function Invoke-FbHardwareGate {
    Write-FbHardwareCheckLog ("start payload={0} script={1}" -f $FirstBasePayloadRevision, $script:ThisScriptVersion)
    try {
        if (-not (Test-Path -LiteralPath $FbPd)) {
            New-Item -ItemType Directory -Path $FbPd -Force -ErrorAction SilentlyContinue | Out-Null
        }
        Set-Content -LiteralPath $HwRunningMarker -Value ('pid={0} at {1}' -f $PID, (Get-Date -Format 'o')) -Encoding ascii -Force
    } catch {}
    try { Set-FbHardwareCheckSplashStatus -Message 'Starting hardware checks (sound, camera, Wi-Fi, PnP, Secure Boot).' } catch {}
    $items = @()
    try {
        try { Set-FbHardwareCheckSplashStatus -Message 'Running hardware checks: sound (microphone and speakers).' } catch {}
        $items += Test-FbHardwareSound
    } catch {
        $items += New-FbHardwareCheckItem -Name 'sound' -Passed $false -Detail ('Sound probe threw: {0}' -f $_.Exception.Message)
    }
    try {
        try { Set-FbHardwareCheckSplashStatus -Message 'Running hardware checks: camera.' } catch {}
        $items += Test-FbHardwareCamera
    } catch {
        $items += New-FbHardwareCheckItem -Name 'camera' -Passed $false -Detail ('Camera probe threw: {0}' -f $_.Exception.Message)
    }
    try {
        try { Set-FbHardwareCheckSplashStatus -Message 'Running hardware checks: Wi-Fi.' } catch {}
        $items += Test-FbHardwareWifi
    } catch {
        $items += New-FbHardwareCheckItem -Name 'wifi' -Passed $false -Detail ('Wi-Fi probe threw: {0}' -f $_.Exception.Message)
    }
    try {
        try { Set-FbHardwareCheckSplashStatus -Message 'Running hardware checks: PnP.' } catch {}
        $items += Test-FbHardwareCriticalPnp
    } catch {
        $items += New-FbHardwareCheckItem -Name 'pnp' -Passed $false -Detail ('PnP probe threw: {0}' -f $_.Exception.Message)
    }
    try {
        try { Set-FbHardwareCheckSplashStatus -Message 'Running hardware checks: Secure Boot.' } catch {}
        $items += Test-FbHardwareSecureBoot
    } catch {
        $items += New-FbHardwareCheckItem -Name 'secureboot' -Passed $false -Detail ('Secure Boot probe threw: {0}' -f $_.Exception.Message) -State 'Not available'
    }

    $failed = @($items | Where-Object { -not $_.Passed })
    $passed = ($failed.Count -eq 0 -and $items.Count -eq 5)
    $summary = ($items | ForEach-Object { '{0}={1}' -f $_.Name, $(if ($_.Passed) { 'PASS' } else { 'FAIL' }) }) -join '; '
    try {
        if ($passed) {
            Set-FbHardwareCheckSplashStatus -Phase 'HardwarePass' -Message ('Hardware passed ({0}). Operator gate is next.' -f $summary)
        } else {
            Set-FbHardwareCheckSplashStatus -Phase 'HardwareFail' -Message ('Hardware failed ({0}). Fix the items below on the splash, then restart or open firmware setup.' -f $summary)
        }
    } catch {}
    Write-FbHardwareCheckLog ("result passed={0} {1}" -f $passed, $summary) $(if ($passed) { 'INFO' } else { 'WARN' })
    foreach ($it in $items) {
        Write-FbHardwareCheckLog ('  {0}: {1}' -f $it.Name, $it.Detail) $(if ($it.Passed) { 'INFO' } else { 'WARN' })
    }

    return [pscustomobject]@{
        Passed    = [bool]$passed
        At        = (Get-Date -Format 'o')
        Payload   = [string]$FirstBasePayloadRevision
        Script    = [string]$script:ThisScriptVersion
        Summary   = [string]$summary
        Checks    = @($items)
        Failed    = @($failed | ForEach-Object { $_.Name })
    }
}

$result = $null
if ($DefinitionsOnly) { return }
try {
    $result = Invoke-FbHardwareGate
} catch {
    Write-FbHardwareCheckLog ("Invoke-FbHardwareGate threw: {0}" -f $_.Exception.Message) 'ERROR'
    $result = [pscustomobject]@{
        Passed  = $false
        At      = (Get-Date -Format 'o')
        Summary = 'probe-threw'
        Error   = [string]$_.Exception.Message
        Checks  = @()
        Failed  = @('sound', 'camera', 'wifi', 'pnp', 'secureboot')
    }
}

try {
    $dir = Split-Path -Parent $ResultPath
    if ($dir -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force -ErrorAction SilentlyContinue | Out-Null
    }
    ($result | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $ResultPath -Encoding UTF8 -Force
} catch {
    Write-FbHardwareCheckLog ("result JSON write failed: {0}" -f $_.Exception.Message) 'WARN'
}

if (-not $Quiet) {
    try { $result | ConvertTo-Json -Depth 6 | Write-Output } catch { Write-Output ($result | Out-String) }
}

if ($result -and $result.Passed) { $exitCode = 0 } else { $exitCode = 1 }
try {
    if (Test-Path -LiteralPath $HwRunningMarker) {
        Remove-Item -LiteralPath $HwRunningMarker -Force -ErrorAction SilentlyContinue
    }
} catch {}
exit $exitCode
