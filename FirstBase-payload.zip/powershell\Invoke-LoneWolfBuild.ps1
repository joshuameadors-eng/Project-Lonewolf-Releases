#Requires -RunAsAdministrator
<#
.SYNOPSIS
  Project LoneWolf Launcher  -  Headless USB Build Wrapper
  Streams JSON events to stdout for Electron IPC consumption.

.DESCRIPTION
  Called by main.js via spawn. Accepts parameters instead of interactive prompts.
  All progress communication is JSON lines to stdout. No Write-Host.

  Build source priority (automatically selected):
    1. Pre-staged WIM  (Staging\Windows * (arch).wim)   -  fastest
    2. ISO direct mode (Staging\Windows * (arch).iso)   -  slower, no pre-staging needed
    Exception: -NoPayload (WIN-INSTALL) prefers ISO when one exists, even if a staged WIM is present.
    Run Update-Staging.ps1 to convert an ISO to a pre-staged WIM.

.PARAMETER WorkflowType
  'AMD64' or 'ARM64' (ISO glob / arch). Quick Install still passes the bare arch
  here; LW_VERSION.json stamps QUICK-INSTALL-<arch> when -QuickInstall is set.

.PARAMETER NoPayload
  Build a minimal WIN-INSTALL USB: no WUPayload, no FirstBase post-install scripts.
  Uses the same TechInstall architecture as a full build (Architecture B):
  startnet -> wpeinit -> WinPE-Startnet.cmd -> TechInstall-Install.cmd -> disksetup.cmd + DISM apply + bcdboot.
  The overlay contains Autounattend.xml (offline unattend only) plus Deploy\TechInstall.cmd,
  Deploy\WinPE-Startnet.cmd, and Deploy\disksetup.cmd.
  After install the machine shuts down instead of rebooting to run update scripts.

.PARAMETER QuickInstall
  Workflow stamp (LW_VERSION.json workflowType QUICK-INSTALL-<arch>).
  Boots FirstBase\Deploy\TechInstall.cmd copied from TechInstall-QuickInstall.cmd
  so WinPE installs Windows and reboots into a stock OOBE. Stages
  Policy\autounattend-quickinstall.xml (no Audit reseal, no SetupComplete).
  Does not stage the Windows Update payload (WUPayload, Edge, or offline
  update packages). Snapdragon Quick Install still injects ARM64 drivers into
  WinPE (boot.wim) only. The Windows install image stays stock.
  Intel/AMD Quick Install does not.

.PARAMETER DiskNumbers
  Comma-separated list of disk numbers to write (e.g. "1,3").
  Pass "0" with -PreCacheOnly to skip disk selection.

.PARAMETER ShareRoot
  UNC path to the share root.

.PARAMETER ShareUser / SharePassword
  Share credentials (embedded defaults match Build-UsbStick-Remote.ps1).

.PARAMETER CacheRoot
  Optional local folder for the ESP template cache used ONLY by non-ISO (staged-WIM /
  MEDIA-CREATOR) builds that inject boot.wim once into a local EspCache before copying
  to USB. Defaults to %TEMP%\LWCache_<guid> when that path is needed. ISO / PreferIso /
  OverlayOnly builds do NOT use CacheRoot — USB-bound content is copied directly to the
  stick (ISO→ESP, ISO→data, ContentRoot→overlay). User-provided CacheRoot is ignored
  on PreferIso/ISO paths.

.PARAMETER PreCacheOnly
  Build the local ESP cache then exit without writing any USB.

.PARAMETER DataVolumeLabel
  USB data-partition volume label. Defaults to 'LoneWolf' (<=11 chars, FAT32-legal so
  the Single and Split layouts share ONE label). FAT32 stores labels uppercase, so it
  reads back as 'LONEWOLF' - all detection is case-insensitive. Legacy sticks labelled
  'Project LoneWolf' or 'WINSETUP' are still detected for overlay-only updates.

.PARAMETER OverlayOnly
  Skip disk wipe, partition, and DISM steps entirely.
  Only copy the deploy overlay onto the existing data (NTFS) partition.
  Safe when the disk already has a valid data partition from a previous full build.
  Emits phase "overlay-update" instead of "partitioning"/"esp-copy"/"dism".

.PARAMETER Sequential
  Process one disk at a time instead of launching all jobs in parallel.
  Each disk's Start-Job (full pipeline: wipe through WinPE/BCD/done) is fully
  drained and removed before the next disk starts.
  Opt-in only — pass this switch explicitly to force sequential builds (e.g. for debugging).
  Release builds run each disk end-to-end in parallel by default.

.OUTPUTS
  JSON lines to stdout only. Examples:
    {"event":"start","disk":1,"workflow":"AMD64"}
    {"event":"iso-mode","disk":0,"isoFile":"Windows 25H2 (AMD64).iso","message":"No pre-staged WIM found  -  mounting ISO directly"}
    {"event":"phase","disk":1,"phase":"partitioning"}
    {"event":"phase","disk":1,"phase":"esp-copy"}
    {"event":"phase","disk":1,"phase":"data-copy"}            <- ISO mode only (robocopy)
    {"event":"progress","disk":1,"phase":"data-copy","pct":0}
    {"event":"phase","disk":1,"phase":"dism"}                 <- WIM mode only (mount + robocopy)
    {"event":"progress","disk":1,"phase":"dism","pct":45}
    {"event":"phase","disk":1,"phase":"overlay"}
    {"event":"done","disk":1,"success":true}
    {"event":"error","disk":1,"message":"failed: ..."}
    {"event":"summary","succeeded":[1,3],"failed":[2]}
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]   $WorkflowType,
    [Parameter(Mandatory)] [string]   $DiskNumbers,
    [string] $ShareRoot        = '\\WIN-HQ5JDEACV3S\Images\FB Image Creation',
    # KEEP IN SYNC: LONEWOLF_SHARE_USER / LONEWOLF_SHARE_PASSWORD env-first in
    # main.js, Get-StagingVersion.ps1, Stage-PreSplitImage.ps1, ConnectDeploymentShare.
    # GATE: HQ UNC connect fails closed when LONEWOLF_SHARE_PASSWORD is unset.
    # Username defaults to Reflect. No share password is stored in this repo.
    [string] $ShareUser        = $(if (-not [string]::IsNullOrWhiteSpace($env:LONEWOLF_SHARE_USER)) { $env:LONEWOLF_SHARE_USER } else { 'Reflect' }),
    [string] $SharePassword    = $(if (-not [string]::IsNullOrWhiteSpace($env:LONEWOLF_SHARE_PASSWORD)) { $env:LONEWOLF_SHARE_PASSWORD } else { '' }),
    [string] $CacheRoot,
    [string] $DataVolumeLabel  = 'LoneWolf',
    [string] $AppResourcesPath = '',
    [string] $LocalProjectRoot = '',   # When non-empty: skip share auth and use this local path as ProjectRoot
    # WinPE optional-component cabs source. Defaults to the share (NOT a local ADK install).
    # LoneWolf builds pull WinPE-WMI/NetFx/Scripting/PowerShell (+ their _en-us cabs) from here.
    [string] $WpeOcRoot = '',
    [switch] $PreCacheOnly,
    [switch] $OverlayOnly,
    [switch] $ForceIsoMode,
    # LoneWolf flow: always pull + mount the NEWEST *(arch)*.iso from the share ISO folder
    # and build from the mounted drive (Architecture B), ignoring any pre-staged WIM.
    # Set by main.js for the LoneWolf workflow. Fails loudly if no matching ISO is present.
    [switch] $PreferIso,
    [switch] $Sequential,
    [switch] $NoPayload,
    # Quick Install USB. Boots TechInstall-QuickInstall.cmd (renamed to
    # Deploy\TechInstall.cmd) and does not stage the Windows Update payload.
    [switch] $QuickInstall,
    # Cleanup-only mode: dismount any share ISO left mounted by a prior cancelled/crashed
    # build (per the mounted-ISO marker), then exit. Invoked by main.js on build:cancel.
    # No disk/share work is performed.
    [switch] $DismountOnly,
    # USB partition layout:
    #   Single (DEFAULT for LoneWolf) - ONE FAT32 Microsoft Basic Data partition
    #     (GPT type {ebd0a0a2-...}, NOT an ESP GUID). Boot files + install media share
    #     the one volume; install.wim is split into install.swm for the FAT32 4 GB limit.
    #     Because the USB has no ESP-GUID partition, only the internal disk's ESP exists
    #     at force-boot time so bcdedit {fwbootmgr} disambiguates cleanly (fixes the
    #     "multiple indistinguishable devices" force-boot failure).
    #   Split - legacy FAT32 ESP ({c12a7328-...}) + NTFS data. Kept as a fallback for
    #     firmware that refuses to boot a non-ESP-GUID removable volume.
    [ValidateSet('Single','Split')]
    [string] $Layout = 'Single',
    # Pre-split fast-copy: deep-verify staged .swm chunks by sha256 (default OFF).
    # Off = size-only integrity check per build (cheap). sha256 of multi-GB chunks on
    # every build is not worth the cost; the producer records hashes for a deep audit.
    [switch] $VerifyPreSplitHash,
    # npm start destage only (main.js passes -DevBuild when !app.isPackaged).
    # Stamps LW_VERSION.json destage/channel=destage + WUPayload\.dev-build so splash, deploy UI, and badges show DEV.
    # Packaged LoneWolf Launcher Dev and production must NOT pass this.
    [switch] $DevBuild,
    [string] $LauncherVersion = '',
    [string] $ScriptVersion = '',
    [string] $ShareLauncherVersion = '',
    [string] $ShareScriptVersion = '',
    # Windows SKU: Home or Pro. Selects Staging\ISO\ by filename (home/pro + arch)
    # and PreSplit\<imageVersion>\ (legacy PreSplit\<ARCH>\<SKU>\ still read).
    # Independent of LoneWolf vs Quick Install. Default Pro (packaged-safe).
    [string] $WindowsEdition = 'Pro',
    # npm start destage only (main.js passes -DestageMedia when !app.isPackaged).
    # ISO from share first, else C:\Repos\Windows_Installation\UUP\25h2\ISO.
    # PreSplit read from C:\Repos\Windows_Installation\UUP\25h2\PreSplit (not share).
    # Packaged production/Dev must not pass this.
    [switch] $DestageMedia,
    # npm start:updatesfinished only (main.js passes -DestageSkipWu when !app.isPackaged
    # AND --destage-updates-finished / LONEWOLF_DESTAGE_UPDATES_FINISHED). Packaged Destage
    # must never pass this. Stamps destageSkipWu on slim LW_VERSION.json (destage only).
    [switch] $DestageSkipWu,
    [ValidateSet('local', 'share', 'googleDrive', '')]
    [string] $MediaSource = '',
    # Producer: write startnet/WinPeUi-injected boot.wim under BootInject on Drive, then exit.
    [string] $ExportStagedBootWimRoot = '',
    # Producer: write injected boot.wim into <PreSplit set>\sources (googleDrive staging).
    [string] $ExportStagedBootWimSetDir = '',
    [string] $StagingIsoPath = '',
    # Public Drive folder → USB over HTTPS (no local ShareRoot cache). npm start / packaged when Desktop absent.
    [switch] $DriveHttpDirect,
    [string] $DriveHttpFolderId = '',
    # Packaged Full Rebuild: base URL for bin/WinPeUi-AMD64.zip + WinPeUi-ARM64.zip
    # (raw.githubusercontent.com/.../dev|main/bin). Empty = local trees only (npm start).
    [string] $WinPeUiZipBaseUrl = ''
)

$ErrorActionPreference = 'Stop'

# --- JSON event emitter -------------------------------------------------------
function Emit {
    param([hashtable]$Data)
    # Write DIRECTLY to the process stdout instead of the PowerShell success stream.
    # Critical: if this used Write-Output, every Emit call inside a function whose return
    # value is captured (e.g. Get-LWPreSplitSet) would leak the JSON event into that return
    # value - which silently corrupted $PreSplitSetDir and disabled the pre-split fast path.
    # [Console]::Out reaches the same stdout main.js parses, but never enters the pipeline.
    [Console]::Out.WriteLine(($Data | ConvertTo-Json -Compress -Depth 3))
}

function EmitPhase   { param([int]$Disk, [string]$Phase) Emit @{ event='phase'; disk=$Disk; phase=$Phase } }
function EmitStart   { param([int]$Disk) Emit @{ event='start'; disk=$Disk; workflow=$WorkflowType } }
function EmitDone    { param([int]$Disk, [bool]$Success, [string]$Msg)
    $d = @{ event='done'; disk=$Disk; success=$Success }
    if ($Msg) { $d['message'] = $Msg }
    Emit $d
}
function EmitError   { param([int]$Disk, [string]$Msg) Emit @{ event='error'; disk=$Disk; message=$Msg } }
function EmitProgress{ param([int]$Disk, [string]$Phase, [int]$Pct) Emit @{ event='progress'; disk=$Disk; phase=$Phase; pct=$Pct } }
function EmitSummary { param([int[]]$Succeeded, [int[]]$Failed) Emit @{ event='summary'; succeeded=@($Succeeded); failed=@($Failed) } }
function EmitLog     { param([int]$Disk, [string]$Msg) Emit @{ event='log'; disk=$Disk; message=$Msg } }

# --- Mounted-ISO marker + self-healing sweep ----------------------------------
# The share ISO is mounted once per build (Mount-DiskImage) and dismounted in the
# finally. That covers thrown errors and `exit 1`, but NOT a hard-kill (build:cancel ->
# killAllBuildProcesses) or a crash. To make dismount reliable across those cases we
# record each mounted ISO path in a marker file; a startup sweep (and the -DismountOnly
# cancel hook from main.js) dismounts anything the previous run left behind.
$script:LwMountMarker = 'C:\ProgramData\LoneWolf\mounted-isos.txt'

function Add-LwMountedIso {
    param([string]$Path)
    try {
        $dir = Split-Path -Parent $script:LwMountMarker
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Add-Content -LiteralPath $script:LwMountMarker -Value $Path -Encoding UTF8
    } catch { }
}

function Remove-LwMountedIso {
    param([string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $script:LwMountMarker)) { return }
        $remaining = @(Get-Content -LiteralPath $script:LwMountMarker -ErrorAction SilentlyContinue |
            Where-Object { $_ -and ($_.Trim() -ne $Path) })
        if ($remaining.Count -gt 0) {
            Set-Content -LiteralPath $script:LwMountMarker -Value $remaining -Encoding UTF8
        } else {
            Remove-Item -LiteralPath $script:LwMountMarker -Force -ErrorAction SilentlyContinue
        }
    } catch { }
}

# Dismount every ISO recorded in the marker that is still attached, then clear it.
# Safe to run before this build mounts its own ISO (the new mount is recorded afterward).
function Invoke-LwIsoSweep {
    try {
        if (-not (Test-Path -LiteralPath $script:LwMountMarker)) { return }
        $recorded = @(Get-Content -LiteralPath $script:LwMountMarker -ErrorAction SilentlyContinue |
            ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique)
        foreach ($p in $recorded) {
            try {
                $img = Get-DiskImage -ImagePath $p -ErrorAction SilentlyContinue
                if ($img -and $img.Attached) {
                    Dismount-DiskImage -ImagePath $p -ErrorAction SilentlyContinue | Out-Null
                    EmitLog -Disk 0 -Msg "iso-sweep: dismounted stale ISO from prior run: $p"
                }
            } catch { }
        }
        Remove-Item -LiteralPath $script:LwMountMarker -Force -ErrorAction SilentlyContinue
    } catch { }
}

# --- Orphan %TEMP% litter sweep (crashed / hard-killed builds) ----------------
# Best-effort: unmount any leftover DISM mount dirs then delete matching folders/logs.
# Safe to run at start, end, and on -DismountOnly (cancel). Never throws.
# -IncludeCache also removes LWCache_* (use at end / cancel — NOT at build-start, so a
# user-provided persistent EspCache under %TEMP% is not wiped before a WIM-mode build).
function Invoke-LwTempOrphanSweep {
    param(
        [string]$Reason = 'orphan-sweep',
        [switch]$IncludeCache
    )
    try {
        $tempRoot = $env:TEMP
        if ([string]::IsNullOrWhiteSpace($tempRoot) -or -not (Test-Path -LiteralPath $tempRoot)) { return }

        $dirPatterns = @('LWMount_*', 'LWPEMount_*', 'LW-WimWork-*', 'LW-WimShared-*')
        if ($IncludeCache) { $dirPatterns = @('LWCache_*') + $dirPatterns }

        foreach ($pat in $dirPatterns) {
            Get-ChildItem -LiteralPath $tempRoot -Directory -Filter $pat -ErrorAction SilentlyContinue | ForEach-Object {
                $dir = $_.FullName
                try {
                    # If this looks like an active/stale DISM mount, discard before delete.
                    $mountProbe = Join-Path $dir 'Windows'
                    $isMountish = (Test-Path -LiteralPath $mountProbe) -or ($_.Name -like 'LWMount_*') -or ($_.Name -like 'LWPEMount_*') -or ($_.Name -like 'LW-Wim*')
                    if ($isMountish) {
                        & dism.exe /Unmount-Image /MountDir:"$dir" /Discard 2>&1 | Out-Null
                        $nestedMount = Join-Path $dir 'mount'
                        if (Test-Path -LiteralPath $nestedMount) {
                            & dism.exe /Unmount-Image /MountDir:"$nestedMount" /Discard 2>&1 | Out-Null
                        }
                    }
                } catch { }
                Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
        Get-ChildItem -LiteralPath $tempRoot -File -Filter 'LW-robocopy-disk*.log' -ErrorAction SilentlyContinue |
            ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
        EmitLog -Disk 0 -Msg "temp-sweep ($Reason): cleaned leftover mount/work/robocopy litter under $tempRoot"
    } catch { }
}

# --- Cleanup-only mode (build:cancel hook) ------------------------------------
# Runs the marker-based ISO sweep + temp orphan sweep and exits without touching disks.
if ($DismountOnly) {
    Invoke-LwIsoSweep
    Invoke-LwTempOrphanSweep -Reason 'dismount-only' -IncludeCache
    exit 0
}

# Startup sweep: prior cancelled/crashed builds may have left mount dirs in %TEMP%.
# Does not touch LWCache_* (may be a deliberate persistent EspCache for WIM builds).
Invoke-LwTempOrphanSweep -Reason 'build-start'

# --- Parse DiskNumbers arg ----------------------------------------------------
$requestedDisks = @($DiskNumbers -split '[,\s]+' |
    Where-Object { $_ -match '^\d+$' } |
    ForEach-Object { [int]$_ } |
    Select-Object -Unique)

# --- Paths --------------------------------------------------------------------
$wfUpper = $WorkflowType.ToUpper()   # AMD64 or ARM64
$winEdition = 'Pro'
if ($WindowsEdition -match '^(?i)home$') { $winEdition = 'Home' }

$shareLayoutLib = Join-Path $PSScriptRoot 'lib\Resolve-LwShareLayout.ps1'
if (Test-Path -LiteralPath $shareLayoutLib) { . $shareLayoutLib }

# Drive HTTP direct must not inherit the default HQ ShareRoot — that made googleDrive
# layout bind to HQ ISO/PreSplit and fall into local ESP cache ("Preparing ESP cache").
$script:DriveHttpSupportRoot = ''
if ($DriveHttpDirect) {
    $ShareRoot = ''
}

if ($OverlayOnly) {
    # Quick Update copies the GitHub or local payload. Do not probe the HQ share
    # (Resolve-LwShareLayout Test-Path on the UNC root hangs or fails off-site).
    $shareLayout = [pscustomobject]@{
        Layout       = 'overlay-payload'
        StagingRoot  = ''
        IsoRoot      = ''
        PreSplitRoot = ''
        WpeOcRoot    = ''
        EdgeRoot     = ''
    }
} elseif ($DriveHttpDirect) {
    $shareLayout = [pscustomobject]@{
        Layout       = 'drive-http-direct'
        StagingRoot  = ''
        IsoRoot      = ''
        PreSplitRoot = ''
        WpeOcRoot    = ''
        EdgeRoot     = ''
    }
} else {
    $shareLayout = Resolve-LwShareLayout -ShareRoot $ShareRoot -LocalProjectRoot $LocalProjectRoot
}

if (-not [string]::IsNullOrWhiteSpace($LocalProjectRoot)) {
    $ProjectRoot = $LocalProjectRoot
} elseif (-not [string]::IsNullOrWhiteSpace($ShareRoot)) {
    $ProjectRoot = Join-Path $ShareRoot 'Remote'
} else {
    # DriveHttpDirect clears ShareRoot; payload comes from AppResourcesPath.
    $ProjectRoot = ''
}
$StagingRoot = $shareLayout.StagingRoot
$IsoFallbackRoot = ''
$isoSearchStaging = $StagingRoot

# Deploy overlay root  -  prefer payload bundled inside the .exe (AppResourcesPath\payload),
# fall back to Staging\Payload on the share when the bundled path is absent.
$bundledPayload = if ($AppResourcesPath) { Join-Path $AppResourcesPath 'payload' } else { '' }
$ContentRoot = if ($bundledPayload -and (Test-Path -LiteralPath $bundledPayload)) {
    $bundledPayload
} elseif (-not [string]::IsNullOrWhiteSpace($StagingRoot)) {
    Join-Path $StagingRoot 'Payload'
} else {
    ''
}

# Refuse to build an Updates stick from a truncated/corrupt loop script.
# Field (52R7X84-0854/0855): packaged 5.3.10 extraResources payload ended mid-function
# (`if ($stage1InlineConverged) {`) so powershell -File exited 1 with no WU-*.log and
# the splash sat on "Checking for updates". Dev sticks (src/payload) were complete.
function Test-LwUpdateLoopPayload {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "FATAL: Invoke-WindowsUpdateLoop.ps1 missing at '$Path'. Cannot build an Updates stick."
    }
    $len = [int64]0
    try { $len = [int64](Get-Item -LiteralPath $Path).Length } catch { $len = [int64]0 }
    # Known truncated extraResources copy is 753480 bytes and ends mid-function.
    if ($len -lt 900000) {
        throw ("FATAL: Invoke-WindowsUpdateLoop.ps1 is truncated ({0} bytes, need >= 900000). Refusing to ship. File: '{1}'." -f $len, $Path)
    }
    $errs = $null
    $toks = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$toks, [ref]$errs)
    if ($errs -and $errs.Count -gt 0) {
        $first = $errs[0]
        $line = 0
        try { $line = [int]$first.Extent.StartLineNumber } catch {}
        throw ("FATAL: Invoke-WindowsUpdateLoop.ps1 does not parse ({0} error(s); first L{1}: {2}). File is truncated or corrupt: '{3}'." -f $errs.Count, $line, $first.Message, $Path)
    }
    $tail = ''
    try { $tail = (Get-Content -LiteralPath $Path -Tail 8 -ErrorAction Stop | Out-String) } catch {}
    if ($tail -notmatch 'Complete-And-Exit') {
        throw "FATAL: Invoke-WindowsUpdateLoop.ps1 is truncated (missing Complete-And-Exit trailer): '$Path'."
    }
    if ($tail -notmatch 'FIRSTBASE-LOOP-EOF-OK') {
        throw "FATAL: Invoke-WindowsUpdateLoop.ps1 is truncated (missing FIRSTBASE-LOOP-EOF-OK marker): '$Path'."
    }
}
function Assert-LwUpdateLoopCopy {
    param([Parameter(Mandatory)][string]$Src, [Parameter(Mandatory)][string]$Dst)
    if (-not (Test-Path -LiteralPath $Dst)) {
        throw "FATAL: Invoke-WindowsUpdateLoop.ps1 missing after copy: '$Dst'"
    }
    $srcLen = [int64](Get-Item -LiteralPath $Src).Length
    $dstLen = [int64](Get-Item -LiteralPath $Dst).Length
    if ($srcLen -ne $dstLen) {
        throw ("FATAL: Invoke-WindowsUpdateLoop.ps1 truncated during copy ({0} -> {1} bytes): '{2}'." -f $srcLen, $dstLen, $Dst)
    }
    Test-LwUpdateLoopPayload -Path $Dst
}

function Copy-LwRepoEdgeInstaller {
    # Destage local installer: C:\Repos\ProjectLoneWolfLauncher\tools\edge.exe (gitignored).
    # Lands on the stick as FirstBase\WUPayload\Edge so TechInstall can stage it into
    # C:\Windows\Setup\FirstBase\Edge for Install-FbMicrosoftEdge.ps1.
    param([Parameter(Mandatory)][string]$DestRoot)
    try {
        $repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
        $toolsDir = Join-Path $repoRoot 'tools'
        if (-not (Test-Path -LiteralPath $toolsDir)) { return }
        $files = @(Get-ChildItem -LiteralPath $toolsDir -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -match '\.(exe|msi)$' -and $_.Name -match '(?i)edge' })
        if ($files.Count -eq 0) { return }
        $edgeRoot = Join-Path $DestRoot 'FirstBase\WUPayload\Edge'
        $archDirs = @(
            $edgeRoot
            (Join-Path $edgeRoot 'AMD64')
            (Join-Path $edgeRoot 'ARM64')
        )
        foreach ($d in $archDirs) {
            if (-not (Test-Path -LiteralPath $d)) {
                New-Item -ItemType Directory -Force -Path $d | Out-Null
            }
        }
        foreach ($f in $files) {
            foreach ($d in $archDirs) {
                Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $d $f.Name) -Force -ErrorAction SilentlyContinue
            }
            EmitLog -Disk 0 -Msg ("payload: staged local Edge installer {0} ({1} bytes) under FirstBase\WUPayload\Edge" -f $f.Name, $f.Length)
        }
    } catch {
        EmitLog -Disk 0 -Msg ("payload: Edge installer copy skipped: {0}" -f $_.Exception.Message)
    }
}

# New fixed-path layout: Staging\AMD64\ and Staging\AMD64\AMD64.wim
# Quick Update has no staging root. Join-Path rejects an empty Path.
if ([string]::IsNullOrWhiteSpace($StagingRoot)) {
    $ArchRoot   = ''
    $StagingWim = ''
} else {
    $ArchRoot    = Join-Path $StagingRoot $wfUpper          # e.g. Staging\AMD64
    $StagingWim  = Join-Path $ArchRoot    "$wfUpper.wim"    # e.g. Staging\AMD64\AMD64.wim
}
$IsoRoot     = $shareLayout.IsoRoot                     # share-root ISO\ or legacy Staging\ISO
$PreSplitRoot = $shareLayout.PreSplitRoot               # share-root PreSplit\ or legacy Staging\PreSplit
$resolvedMediaSource = if ($DestageMedia) { 'local' } elseif (-not [string]::IsNullOrWhiteSpace($MediaSource)) { $MediaSource } else { '' }
$script:LwBootInjectSourcesDir = ''
$script:DestageMediaLayout = $null
if ($DriveHttpDirect) {
    # Package + WinPE support stream over HTTPS; no Desktop/HQ destage layout.
    $IsoRoot = ''
    $IsoFallbackRoot = ''
    $PreSplitRoot = ''
    $isoSearchStaging = ''
} elseif ($DestageMedia -or (-not [string]::IsNullOrWhiteSpace($resolvedMediaSource))) {
    $msLayout = if ($DestageMedia) { 'local' } else { $resolvedMediaSource }
    $script:DestageMediaLayout = Resolve-LwDestageMediaLayout -ShareRoot $ShareRoot -MediaSource $msLayout
    $destageLayout = $script:DestageMediaLayout
    if ($msLayout -eq 'local') {
        $null = Initialize-LwDestageUupDirs
    }
    $IsoRoot = $destageLayout.IsoRoot
    $IsoFallbackRoot = ''
    $PreSplitRoot = $destageLayout.PreSplitRoot
    $isoSearchStaging = $destageLayout.IsoRoot
}

# Shared split-helper lib. Dot-sourced on the MAIN thread here (for Get-LWImageVersionId
# + Test-LWPreSplitSet used by Get-LWPreSplitSet below), and its full path is ALSO passed
# into each per-disk Start-Job so the worker runspace can dot-source Split-LWImageForFat32
# (a job runspace cannot see script-scope functions of the parent).
$SplitLibPath = Join-Path $PSScriptRoot 'lib\Split-LWImage.ps1'
if (Test-Path -LiteralPath $SplitLibPath) { . $SplitLibPath }
$Arm64DriverLibPath = Join-Path $PSScriptRoot 'lib\Add-LwArm64Drivers.ps1'
if (Test-Path -LiteralPath $Arm64DriverLibPath) { . $Arm64DriverLibPath }
$UsbOverlayLibPath = Join-Path $PSScriptRoot 'lib\LwUsbOverlay.ps1'
if (Test-Path -LiteralPath $UsbOverlayLibPath) { . $UsbOverlayLibPath }
$DriveHttpLibPath = Join-Path $PSScriptRoot 'lib\Invoke-LwDriveHttpUsbMedia.ps1'
if (Test-Path -LiteralPath $DriveHttpLibPath) { . $DriveHttpLibPath }
$LcuLibPath = Join-Path $PSScriptRoot 'lib\Invoke-LwOfflineLcuInject.ps1'
if (Test-Path -LiteralPath $LcuLibPath) { . $LcuLibPath }

# Full Windows Updates (Intel/AMD and Snapdragon) parses the update loop.
# Both Quick Install workflows and WIN-INSTALL skip that payload.
# Image Ready boot.wim export (-ExportStagedBootWim*) only needs Deploy\WinPE-Startnet.cmd
# under ContentRoot — not the multi-MB update loop (Keyes / Stage-GoogleDriveMedia producers).
$exportOnlyBootWim = (-not [string]::IsNullOrWhiteSpace($ExportStagedBootWimSetDir)) -or
    (-not [string]::IsNullOrWhiteSpace($ExportStagedBootWimRoot))
$stageWuPayload = $false
if (-not $exportOnlyBootWim -and (Get-Command -Name Test-LwStageWindowsUpdatePayload -ErrorAction SilentlyContinue)) {
    $stageWuPayload = [bool](Test-LwStageWindowsUpdatePayload -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload ([bool]$NoPayload))
}
if ($stageWuPayload) {
    if ([string]::IsNullOrWhiteSpace($ContentRoot)) {
        throw 'FATAL: ContentRoot is empty; cannot validate Invoke-WindowsUpdateLoop.ps1 (pass -AppResourcesPath).'
    }
    Test-LwUpdateLoopPayload -Path (Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1')
    EmitLog -Disk 0 -Msg "payload: update-loop script parse+trailer OK ($ContentRoot)"
}

# WinPE OC source: arch-bearing Staging\WinPE-OCs, explicit -WpeOcRoot, share / HQ.
# Drive HTTP still needs a real OC root when the package lacks an inject sentinel
# (per-disk startnet inject). Empty UUP\WinPE-OCs must not beat HQ.
$WpeOcSource = if (-not [string]::IsNullOrWhiteSpace($LocalProjectRoot) -and
                   -not [string]::IsNullOrWhiteSpace($StagingRoot) -and
                   (Get-Command -Name Test-LwWpeOcRootHasArch -ErrorAction SilentlyContinue) -and
                   (Test-LwWpeOcRootHasArch (Join-Path $StagingRoot 'WinPE-OCs'))) {
    Join-Path $StagingRoot 'WinPE-OCs'
} elseif (-not [string]::IsNullOrWhiteSpace($WpeOcRoot)) {
    $WpeOcRoot
} elseif ($DriveHttpDirect) {
    if (Get-Command -Name Resolve-LwWpeOcRoot -ErrorAction SilentlyContinue) {
        Resolve-LwWpeOcRoot -ShareRoot (Get-LwHqShareRoot) -LocalOcRoot ''
    } else {
        ''
    }
} else {
    Resolve-LwWpeOcRoot -ShareRoot $ShareRoot -LocalOcRoot $shareLayout.WpeOcRoot
}

# WinPE-OCs on HQ: Images\FB Image Creation\WinPE-OCs\{AMD64|ARM64}.
# Prefer <root>\<ARCH>; flat root with WinPE-PowerShell.cab (legacy / ADK); then
# local ADK WinPE_OCs when HQ is offline. When nothing exists, return the arch
# subfolder path so the required-cab guard fails naming that path.
function Resolve-WpeOcArchRoot {
    param([string]$BaseRoot, [string]$Arch)

    $archKey = if ($Arch -match '(?i)ARM64') { 'ARM64' } else { 'AMD64' }
    if (-not [string]::IsNullOrWhiteSpace($BaseRoot)) {
        $archRoot = Join-Path $BaseRoot $archKey
        if (Test-Path -LiteralPath $archRoot) { return $archRoot }
        # Legacy flat WinPE-OCs\ or ADK WinPE_OCs\ (cabs at root). Never feed a
        # flat AMD64 ADK tree to ARM64.
        $hasArchChildren = (Test-Path -LiteralPath (Join-Path $BaseRoot 'AMD64')) -or
            (Test-Path -LiteralPath (Join-Path $BaseRoot 'ARM64'))
        if (-not $hasArchChildren -and
            (Test-Path -LiteralPath (Join-Path $BaseRoot 'WinPE-PowerShell.cab'))) {
            if ($archKey -eq 'AMD64') { return $BaseRoot }
            # ARM64: flat AMD64-only tree is wrong; try ADK below.
        } elseif (-not $hasArchChildren -and [string]::IsNullOrWhiteSpace($BaseRoot) -eq $false) {
            # Base exists but empty / wrong — fall through to ADK.
        }
    }
    if (Get-Command -Name Get-LwAdkWpeOcArchRoot -ErrorAction SilentlyContinue) {
        $adk = [string](Get-LwAdkWpeOcArchRoot -Arch $archKey)
        if (-not [string]::IsNullOrWhiteSpace($adk) -and (Test-Path -LiteralPath $adk)) {
            return $adk
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($BaseRoot)) {
        return (Join-Path $BaseRoot $archKey)
    }
    return ''
}

# Full Rebuild / EspCache inject: preferred root → HQ → Drive HTTPS → ADK.
function Resolve-WpeOcArchRootForInject {
    param(
        [string]$PreferredRoot = '',
        [Parameter(Mandatory)][string]$Arch,
        [scriptblock]$Log
    )
    $tryPath = {
        param([string]$Root)
        if ([string]::IsNullOrWhiteSpace($Root)) { return '' }
        $p = Resolve-WpeOcArchRoot -BaseRoot $Root -Arch $Arch
        if (-not [string]::IsNullOrWhiteSpace($p) -and (Test-Path -LiteralPath $p)) { return $p }
        return ''
    }
    $hit = & $tryPath $PreferredRoot
    if ($hit) { return $hit }

    if (Get-Command -Name Resolve-LwWpeOcRoot -ErrorAction SilentlyContinue) {
        $hqShare = if (Get-Command -Name Get-LwHqShareRoot -ErrorAction SilentlyContinue) {
            [string](Get-LwHqShareRoot)
        } else { '' }
        $hqRoot = Resolve-LwWpeOcRoot -ShareRoot $hqShare -LocalOcRoot ''
        $hit = & $tryPath $hqRoot
        if ($hit) { return $hit }
    }

    $driveParent = Get-LwDriveHttpSupportDestRoot -ShareRoot ''
    if (Get-Command -Name Ensure-LwDriveHttpWpeOcRoot -ErrorAction SilentlyContinue) {
        if ($Log) { & $Log "WinPE-OCs: fetching public Drive folder into $driveParent\WinPE-OCs" }
        $fetched = Ensure-LwDriveHttpWpeOcRoot -DestRoot $driveParent -Arch $Arch -Log $Log
        $hit = & $tryPath $fetched
        if ($hit) { return $hit }
    }

    # Last resort: ADK (Resolve-WpeOcArchRoot with empty base).
    $hit = & $tryPath ''
    if ($hit) { return $hit }
    return ''
}

function Get-LwDriveHttpSupportDestRoot {
    param([string] $ShareRoot = '')
    $driveParent = ''
    if (Get-Command -Name Get-LwDestageUupLayout -ErrorAction SilentlyContinue) {
        try { $driveParent = [string](Get-LwDestageUupLayout).Root } catch { }
    }
    if ([string]::IsNullOrWhiteSpace($driveParent) -and -not [string]::IsNullOrWhiteSpace($ShareRoot) -and
        (Get-Command -Name Test-LwLooksLikeStagingRoot -ErrorAction SilentlyContinue) -and
        (Test-LwLooksLikeStagingRoot $ShareRoot)) {
        $driveParent = $ShareRoot
    }
    if ([string]::IsNullOrWhiteSpace($driveParent)) {
        $driveParent = Join-Path $env:TEMP 'LW-WinPeOc-Drive'
    }
    return $driveParent
}

function Resolve-LwArm64DriverDirForBuild {
    param(
        [string] $ShareRoot = '',
        [scriptblock] $Log
    )
    if (-not (Get-Command -Name Resolve-LwArm64DriverDir -ErrorAction SilentlyContinue)) { return '' }
    $dir = [string](Resolve-LwArm64DriverDir -ShareRoot $ShareRoot)
    if (-not [string]::IsNullOrWhiteSpace($dir)) { return $dir }
    if (-not (Get-Command -Name Ensure-LwDriveHttpWinPeDriversRoot -ErrorAction SilentlyContinue)) { return '' }
    $driveParent = Get-LwDriveHttpSupportDestRoot -ShareRoot $ShareRoot
    $fetched = Ensure-LwDriveHttpWinPeDriversRoot -DestRoot $driveParent -Log $Log
    if (-not [string]::IsNullOrWhiteSpace($fetched)) { return $fetched }
    return [string](Resolve-LwArm64DriverDir -ShareRoot $driveParent)
}

# Copy-LwEdgeOfflineInstaller lives in lib\LwUsbOverlay.ps1 (dotted above and into disk jobs).

# UEFI removable-media loader is arch-specific (same path for bootmgfw.efi on both):
#   AMD64 -> efi\boot\bootx64.efi
#   ARM64 -> efi\boot\bootaa64.efi
# Some ISOs omit efi\microsoft\boot\bootmgfw.efi and only ship the removable loader.
# Never synthesise ARM from bootx64 (or AMD from bootaa64) -- those PE images will not boot.
function Get-LwRemovableBootEfiName {
    param([string]$WorkflowType)
    if ([string]$WorkflowType -match 'ARM') { return 'bootaa64.efi' }
    return 'bootx64.efi'
}

function Get-LwEfiArchTag {
    param([string]$WorkflowType)
    if ([string]$WorkflowType -match 'ARM') { return 'ARM64' }
    return 'AMD64'
}

function Get-LwEfiFolderListing {
    param([string]$Dir)
    if (-not (Test-Path -LiteralPath $Dir)) { return '(missing)' }
    $names = @(Get-ChildItem -LiteralPath $Dir -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
    if ($names.Count -eq 0) { return '(empty)' }
    return ($names -join ', ')
}

# If bootmgfw.efi is missing, copy it from the arch removable loader.
# If the removable loader is missing, copy it from bootmgfw.efi.
# Returns the removable EFI filename when bootmgfw was synthesised; otherwise $null.
function Repair-LwEspBootLoaders {
    param([string]$EspRoot, [string]$WorkflowType)
    $efiName = Get-LwRemovableBootEfiName -WorkflowType $WorkflowType
    $bootmgfw = Join-Path $EspRoot 'efi\microsoft\boot\bootmgfw.efi'
    $removable = Join-Path $EspRoot ('efi\boot\' + $efiName)
    $synthFrom = $null
    if (-not (Test-Path -LiteralPath $bootmgfw) -and (Test-Path -LiteralPath $removable)) {
        New-Item -ItemType Directory -Force -Path (Split-Path $bootmgfw -Parent) -ErrorAction SilentlyContinue | Out-Null
        Copy-Item -LiteralPath $removable -Destination $bootmgfw -Force
        $synthFrom = $efiName
    }
    if (-not (Test-Path -LiteralPath $removable) -and (Test-Path -LiteralPath $bootmgfw)) {
        New-Item -ItemType Directory -Force -Path (Split-Path $removable -Parent) -ErrorAction SilentlyContinue | Out-Null
        Copy-Item -LiteralPath $bootmgfw -Destination $removable -Force
    }
    return $synthFrom
}

function Get-LwEspBootmgfwMissingMessage {
    param(
        [string]$Prefix,
        [string]$EspRoot,
        [string]$WorkflowType,
        [string]$IsoHint = ''
    )
    $arch = Get-LwEfiArchTag -WorkflowType $WorkflowType
    $efiName = Get-LwRemovableBootEfiName -WorkflowType $WorkflowType
    $isoBit = ''
    if (-not [string]::IsNullOrWhiteSpace($IsoHint)) { $isoBit = " ISO='$IsoHint'." }
    $espBoot = Get-LwEfiFolderListing -Dir (Join-Path $EspRoot 'efi\boot')
    $espMs = Get-LwEfiFolderListing -Dir (Join-Path $EspRoot 'efi\microsoft\boot')
    $isoExtra = ''
    if (-not [string]::IsNullOrWhiteSpace($IsoHint)) {
        $isoBoot = Get-LwEfiFolderListing -Dir (Join-Path $IsoHint 'efi\boot')
        $isoMs = Get-LwEfiFolderListing -Dir (Join-Path $IsoHint 'efi\microsoft\boot')
        $isoExtra = " ISO efi\boot: $isoBoot; ISO efi\microsoft\boot: $isoMs."
    }
    return ("{0} ({1}): efi\microsoft\boot\bootmgfw.efi missing and efi\boot\{2} unavailable to synthesise it.{3} ESP efi\boot: {4}; ESP efi\microsoft\boot: {5}.{6}" -f $Prefix, $arch, $efiName, $isoBit, $espBoot, $espMs, $isoExtra)
}

# --- Pre-split fast-copy set detection (main thread) --------------------------
# Does a VALID, matching pre-split install*.swm set exist for the ISO this build is
# about to use? Runs once on the main thread (before the per-disk jobs launch); the
# resolved set dir (or '') is passed into every job so each USB robocopies the staged
# .swm instead of running dism /Split-Image. Returns the set dir on a match, else $null.
# A miss/mismatch/corruption is NEVER fatal - the caller passes '' and the worker falls
# back to the on-the-fly split (behaviour identical to before this feature).
function Get-LWPreSplitSet {
    param(
        [Parameter(Mandatory)] [System.IO.FileInfo] $Iso,
        [Parameter(Mandatory)] [string] $PreSplitRoot,
        [Parameter(Mandatory)] [string] $Arch,
        [string] $Edition = 'Pro',
        [switch] $VerifyHash
    )
    try {
        if (-not (Get-Command -Name Get-LWImageVersionId -ErrorAction SilentlyContinue) -or
            -not (Get-Command -Name Test-LWPreSplitSet -ErrorAction SilentlyContinue)) {
            EmitLog -Disk 0 -Msg 'presplit: shared split lib not loaded - skipping fast path, using on-the-fly split'
            return $null
        }
        $ed = if (Get-Command -Name Get-LWWindowsEdition -ErrorAction SilentlyContinue) {
            Get-LWWindowsEdition $Edition
        } else { 'Pro' }
        if ([string]::IsNullOrWhiteSpace($PreSplitRoot)) {
            EmitLog -Disk 0 -Msg "presplit: PreSplitRoot is empty - on-the-fly split will be used"
            return $null
        }
        $scanDirs = if (Get-Command -Name Get-LWPreSplitScanDirs -ErrorAction SilentlyContinue) {
            @(Get-LWPreSplitScanDirs -PreSplitRoot $PreSplitRoot -Arch $Arch -Edition $ed)
        } else {
            @($PreSplitRoot, (Join-Path $PreSplitRoot $Arch))
        }
        $anyDir = $false
        foreach ($d in $scanDirs) {
            if ([string]::IsNullOrWhiteSpace($d)) { continue }
            if (Test-Path -LiteralPath $d) { $anyDir = $true; break }
        }
        if (-not $anyDir) {
            EmitLog -Disk 0 -Msg "presplit: no staged sets folder for $Arch $ed under '$PreSplitRoot' - on-the-fly split will be used"
            return $null
        }
        $candidates = New-Object System.Collections.Generic.List[string]
        if (Get-Command -Name Get-LWPreSplitCandidateDirs -ErrorAction SilentlyContinue) {
            foreach ($c in @(Get-LWPreSplitCandidateDirs -PreSplitRoot $PreSplitRoot -Arch $Arch -Edition $ed)) {
                [void]$candidates.Add($c)
            }
        } else {
            foreach ($archDir in $scanDirs) {
                if (-not (Test-Path -LiteralPath $archDir)) { continue }
                $marker = Join-Path $archDir 'current'
                if (Test-Path -LiteralPath $marker) {
                    try {
                        $mk = Get-Content -Raw -LiteralPath $marker -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                        if ($mk.imageVersion) {
                            $cand = Join-Path $archDir ([string]$mk.imageVersion)
                            if (Test-Path -LiteralPath $cand) { $candidates.Add($cand) }
                        }
                    } catch {
                        EmitLog -Disk 0 -Msg "presplit: 'current' marker unreadable ($($_.Exception.Message)) - scanning set folders instead"
                    }
                }
                foreach ($d in @(Get-ChildItem -LiteralPath $archDir -Directory -ErrorAction SilentlyContinue |
                        Sort-Object LastWriteTime -Descending)) {
                    if ($d.Name -like '*.tmp-*') { continue }
                    if ($d.Name -match '^(?i)(AMD64|ARM64|Home|Pro)$') { continue }
                    if ((Get-Command -Name Test-LWPreSplitFolderMatches -ErrorAction SilentlyContinue) -and
                        -not (Test-LWPreSplitFolderMatches -FolderName $d.Name -Arch $Arch -Edition $ed)) { continue }
                    if (-not ($candidates -contains $d.FullName)) { $candidates.Add($d.FullName) }
                }
            }
        }
        if ($candidates.Count -eq 0) {
            EmitLog -Disk 0 -Msg "presplit: no staged set folders for $Arch $ed - on-the-fly split will be used"
            return $null
        }

        foreach ($setDir in $candidates) {
            # Test-LWPreSplitSet accepts install.swm + install2.swm (and further
            # chunks). A single install.wim/esd is accepted only under 512 MiB.
            # The one-file AMD set for a multi-GB image is rejected here so the
            # fast path does not copy that install.wim; Stage ISO re-stages it.
            $chk = Test-LWPreSplitSet -SetDir $setDir -VerifyHash:$VerifyHash
            if (-not $chk.Valid) {
                EmitLog -Disk 0 -Msg "presplit: set '$setDir' rejected ($($chk.Reason))"
                continue
            }
            $arm64DriverSet = $false
            try {
                if (Get-Command -Name Test-LwPreSplitHasArm64Drivers -ErrorAction SilentlyContinue) {
                    $arm64DriverSet = [bool](Test-LwPreSplitHasArm64Drivers -Manifest $chk.Manifest)
                }
            } catch { }
            if ($arm64DriverSet) {
                EmitLog -Disk 0 -Msg "presplit: set '$setDir' has ARM64 drivers in the install image and is not used (WinPE injects drivers into boot.wim only)"
                continue
            }
            $m   = $chk.Manifest
            $manEd = $null
            try {
                if ($m.PSObject.Properties['windowsEdition'] -and $m.windowsEdition) { $manEd = [string]$m.windowsEdition }
                elseif ($m.PSObject.Properties['edition'] -and $m.edition) { $manEd = [string]$m.edition }
            } catch { }
            if ($manEd) {
                $manNorm = if ($manEd -match '^(?i)home$') { 'Home' } else { 'Pro' }
                if ($manNorm -ne $ed) {
                    EmitLog -Disk 0 -Msg "presplit: set '$setDir' skipped (edition $manNorm != $ed)"
                    continue
                }
            } elseif ($ed -ne 'Pro') {
                EmitLog -Disk 0 -Msg "presplit: set '$setDir' skipped (no edition in manifest; Home requires an explicit SKU)"
                continue
            }
            $manArch = $null
            try {
                if ($m.PSObject.Properties['arch'] -and $m.arch) { $manArch = Get-LWBareArch ([string]$m.arch) }
            } catch { }
            if ($manArch -and $manArch -ne $arch) {
                EmitLog -Disk 0 -Msg "presplit: set '$setDir' skipped (arch $manArch != $arch)"
                continue
            }
            $setLeaf = Split-Path -Leaf $setDir
            if ((Get-Command -Name Test-LWPreSplitFolderMatches -ErrorAction SilentlyContinue) -and
                -not (Test-LWPreSplitFolderMatches -FolderName $setLeaf -Arch $arch -Edition $ed)) {
                EmitLog -Disk 0 -Msg "presplit: set '$setDir' skipped (folder arch/SKU does not match $arch $ed)"
                continue
            }
            # Match by source name+size (and soft last-write). Do not recompute
            # Get-LWImageVersionId for string equality — stamps are staging UTC.
            $reasons = @()
            if (-not (Get-Command -Name Test-LWPreSplitSourceMatchesIso -ErrorAction SilentlyContinue) -or
                -not (Test-LWPreSplitSourceMatchesIso -Manifest $m -Iso $Iso)) {
                $src = $m.source
                if (-not $src) {
                    $reasons += 'manifest has no source block'
                } else {
                    if ([string]$src.isoName -ne $Iso.Name) {
                        $reasons += "isoName '$([string]$src.isoName)' != '$($Iso.Name)'"
                    }
                    if ([long]$src.isoSizeBytes -ne [long]$Iso.Length) {
                        $reasons += "isoSizeBytes $([long]$src.isoSizeBytes) != $([long]$Iso.Length)"
                    }
                    if ($reasons.Count -eq 0) { $reasons += 'source identity mismatch' }
                }
            }
            if ($reasons.Count -gt 0) {
                EmitLog -Disk 0 -Msg "presplit: set '$setDir' does not match current ISO - $([string]::Join('; ', $reasons))"
                continue
            }
            $matchIv = [string]$m.imageVersion
            if (-not $matchIv) { $matchIv = $setLeaf }
            EmitLog -Disk 0 -Msg "presplit: MATCH - staged set '$setDir' (imageVersion=$matchIv, edition=$ed); builds will fast-copy install*.swm and skip the on-the-fly split"
            return $setDir
        }
        EmitLog -Disk 0 -Msg "presplit: no staged set matched the current $ed ISO '$($Iso.Name)' - falling back to on-the-fly split"
        return $null
    } catch {
        EmitLog -Disk 0 -Msg "presplit: detection error ($($_.Exception.Message)) - falling back to on-the-fly split"
        return $null
    }
}

# CacheRoot / EspCache is allocated ONLY for non-ISO staged-WIM builds (see ensure block
# after ISO detection). ISO / PreferIso / OverlayOnly copy USB-bound content directly to
# the stick — no local LWCache overlay or ESP staging. PreferIso ignores a user-provided
# -CacheRoot so a persistent EspCache folder cannot accidentally suppress per-disk inject.
$userProvidedCache = (-not [string]::IsNullOrWhiteSpace($CacheRoot))
if ($PreferIso) {
    $CacheRoot = ''
    $userProvidedCache = $false
}
$espCache     = ''
$overlayCache = ''

# --- Share authentication -----------------------------------------------------
function Connect-Share {
    param([string]$ShareHost, [string]$User, [string]$Pass, [string]$ProbePath)

    if ([string]::IsNullOrWhiteSpace($Pass)) {
        throw 'HQ share password is not set. Set LONEWOLF_SHARE_PASSWORD before connecting to the deployment share.'
    }
    $cmdkey = Join-Path $env:SystemRoot 'System32\cmdkey.exe'
    if (Test-Path -LiteralPath $cmdkey) {
        & $cmdkey /delete:$ShareHost 2>$null | Out-Null
        & $cmdkey /add:$ShareHost /user:$User /pass:$Pass 2>&1 | Out-Null
    }
    try { $null = & net use "\\$ShareHost\IPC$" /delete 2>$null } catch { }

    if (Test-Path -LiteralPath $ProbePath) { return }

    # Fallback: PSDrive
    try {
        $sec  = ConvertTo-SecureString $Pass -AsPlainText -Force
        $cred = New-Object System.Management.Automation.PSCredential($User, $sec)
        $letter = ('Z','Y','X','W','V','U','T','S' | Where-Object {
            -not (Get-PSDrive -Name $_ -ErrorAction SilentlyContinue)
        } | Select-Object -First 1)
        if ($letter) {
            New-PSDrive -Name $letter -PSProvider FileSystem -Root "\\$ShareHost" `
                -Credential $cred -Scope Global -ErrorAction Stop | Out-Null
        }
    } catch { }
}

# Stage Cascadia Mono into the USB overlay (and optionally boot.wim Fonts).
# WinPE raster OEM cannot draw U+28xx; AddFontResourceEx at deploy UI time
# loads this TTF. Does not rebuild the share WIM.
function Copy-LwPeBrailleFont {
    param(
        [string]$OverlayRoot = '',
        [string]$WimFontsDir = ''
    )
    $srcList = New-Object System.Collections.Generic.List[string]
    if ($ContentRoot) {
        [void]$srcList.Add((Join-Path $ContentRoot 'Deploy\Fonts\cascadiamono.ttf'))
    }
    if ($env:WINDIR) {
        foreach ($n in @('cascadiamono.ttf', 'CascadiaMono.ttf', 'CascadiaMonoPL.ttf')) {
            [void]$srcList.Add((Join-Path $env:WINDIR ('Fonts\' + $n)))
        }
    }
    $src = $null
    foreach ($c in $srcList) {
        if ($c -and (Test-Path -LiteralPath $c)) { $src = $c; break }
    }
    if (-not $src) {
        EmitLog -Disk 0 -Msg 'WinPE Braille font: cascadiamono.ttf not found in payload Deploy\Fonts or Windows\Fonts (wolf may show as ?)'
        return
    }
    if ($OverlayRoot) {
        $dstDir = Join-Path $OverlayRoot 'FirstBase\Deploy\Fonts'
        New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
        Copy-Item -LiteralPath $src -Destination (Join-Path $dstDir 'cascadiamono.ttf') -Force
        EmitLog -Disk 0 -Msg ("WinPE Braille font staged to overlay: {0}" -f (Join-Path $dstDir 'cascadiamono.ttf'))
    }
    if ($WimFontsDir) {
        New-Item -ItemType Directory -Force -Path $WimFontsDir | Out-Null
        Copy-Item -LiteralPath $src -Destination (Join-Path $WimFontsDir 'cascadiamono.ttf') -Force
        EmitLog -Disk 0 -Msg ("WinPE Braille font staged into boot.wim Fonts: {0}" -f (Join-Path $WimFontsDir 'cascadiamono.ttf'))
    }
}

# Self-contained WPF deploy UI (AMD64 + ARM64 publish trees under payload Deploy\WinPeUi).
function Copy-LwWinPeUiOverlay {
    param([string]$OverlayRoot = '')
    if (-not $OverlayRoot) { return }
    foreach ($arch in @('AMD64', 'ARM64')) {
        $src = ''
        try { $src = Ensure-LwWinPeUiArchDir -Arch $arch } catch { $src = '' }
        if (-not $src -or -not (Test-Path -LiteralPath (Join-Path $src 'LoneWolf.WinPeUi.exe'))) {
            EmitLog -Disk 0 -Msg ("WinPeUi: {0} not available (local publish or GitHub bin/WinPeUi-{0}.zip)" -f $arch)
            continue
        }
        $dst = Join-Path $OverlayRoot ("FirstBase\Deploy\WinPeUi\{0}" -f $arch)
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force -ErrorAction SilentlyContinue
        EmitLog -Disk 0 -Msg ("WinPeUi staged: {0}" -f $dst)
    }
}

# Flat copy of the arch-matched publish tree into a mounted boot.wim as FirstBase\WinPeUi\
# (becomes X:\FirstBase\WinPeUi\ at boot). startnet launches this before USB is lettered.
function Copy-LwWinPeUiIntoBootMount {
    param(
        [Parameter(Mandatory)][string] $MountDir,
        [string] $WinPeUiSrcDir = '',
        [scriptblock] $Log = $null
    )
    if ([string]::IsNullOrWhiteSpace($WinPeUiSrcDir) -or -not (Test-Path -LiteralPath $WinPeUiSrcDir)) {
        if ($Log) { & $Log ("WinPeUi boot inject: source missing '{0}' - splash stays USB-only" -f $WinPeUiSrcDir) }
        return $false
    }
    $exe = Join-Path $WinPeUiSrcDir 'LoneWolf.WinPeUi.exe'
    if (-not (Test-Path -LiteralPath $exe)) {
        if ($Log) { & $Log ("WinPeUi boot inject: LoneWolf.WinPeUi.exe missing under '{0}'" -f $WinPeUiSrcDir) }
        return $false
    }
    $dst = Join-Path $MountDir 'FirstBase\WinPeUi'
    if (Test-Path -LiteralPath $dst) {
        Remove-Item -LiteralPath $dst -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Force -Path $dst | Out-Null
    Copy-Item -Path (Join-Path $WinPeUiSrcDir '*') -Destination $dst -Recurse -Force -ErrorAction Stop
    if ($Log) { & $Log ("WinPeUi boot inject: staged -> {0}" -f $dst) }
    return $true
}

function Resolve-LwWinPeUiPublishDir {
    param(
        [string] $ContentRootPath,
        [string] $Arch = 'AMD64'
    )
    $folder = if ($Arch -match '(?i)ARM64|Snapdragon') { 'ARM64' } else { 'AMD64' }
    try {
        $ensured = Ensure-LwWinPeUiArchDir -Arch $folder
        if ($ensured) { return $ensured }
    } catch {}
    if ([string]::IsNullOrWhiteSpace($ContentRootPath)) { return '' }
    return (Join-Path $ContentRootPath ("Deploy\WinPeUi\{0}" -f $folder))
}

function Get-LwWinPeUiFolderName {
    param([string] $Arch = 'AMD64')
    if ($Arch -match '(?i)ARM64|Snapdragon') { return 'ARM64' }
    return 'AMD64'
}

function Ensure-LwWinPeUiArchDir {
    # Prefer local publish trees (npm start). Else: staged UUP\WinPEUI zips, then
    # Warehouse - Imaging > WinPEUI on Drive, then GitHub bin/ (under 100 MB).
    # Cache expands into a writable dir — resources\payload is often read-only.
    param(
        [Parameter(Mandatory)][ValidateSet('AMD64', 'ARM64')][string] $Arch,
        [switch] $Required
    )
    $bundled = ''
    if ($ContentRoot) {
        $bundled = Join-Path $ContentRoot ("Deploy\WinPeUi\{0}" -f $Arch)
        $bundledExe = Join-Path $bundled 'LoneWolf.WinPeUi.exe'
        if (Test-Path -LiteralPath $bundledExe) { return $bundled }
    }
    $cacheRoot = $script:LwWinPeUiCacheRoot
    if ([string]::IsNullOrWhiteSpace($cacheRoot)) {
        $cacheRoot = Join-Path $env:TEMP 'LWWinPeUi'
        $script:LwWinPeUiCacheRoot = $cacheRoot
    }
    $cached = Join-Path $cacheRoot $Arch
    $cachedExe = Join-Path $cached 'LoneWolf.WinPeUi.exe'
    if (Test-Path -LiteralPath $cachedExe) { return $cached }

    $zipName = "WinPeUi-$Arch.zip"
    $zipCandidates = New-Object System.Collections.Generic.List[string]
    if ($ContentRoot) {
        [void]$zipCandidates.Add((Join-Path $ContentRoot ("Deploy\{0}" -f $zipName)))
        [void]$zipCandidates.Add((Join-Path $ContentRoot $zipName))
    }
    if ($AppResourcesPath) {
        [void]$zipCandidates.Add((Join-Path $AppResourcesPath ("bin\{0}" -f $zipName)))
        [void]$zipCandidates.Add((Join-Path (Split-Path -Parent $AppResourcesPath) ("bin\{0}" -f $zipName)))
    }
    if (Get-Command -Name Get-LwDestageUupLayout -ErrorAction SilentlyContinue) {
        try {
            $uupWinPeUi = Join-Path (Get-LwDestageUupLayout).Root 'WinPEUI'
            [void]$zipCandidates.Add((Join-Path $uupWinPeUi $zipName))
        } catch { }
    } else {
        [void]$zipCandidates.Add((Join-Path 'C:\Repos\Windows_Installation\UUP\25h2\WinPEUI' $zipName))
    }
    $localZip = $null
    foreach ($c in $zipCandidates) {
        if ($c -and (Test-Path -LiteralPath $c)) { $localZip = $c; break }
    }

    $downloadZip = Join-Path $cacheRoot $zipName
    if (-not $localZip) {
        New-Item -ItemType Directory -Path $cacheRoot -Force -ErrorAction SilentlyContinue | Out-Null
        $driveOk = $false
        if (Get-Command -Name Invoke-LwDriveHttpWinPeUiZip -ErrorAction SilentlyContinue) {
            Emit @{ event = 'progress'; disk = 0; phase = 'winpe-ui'; pct = 0; message = ("Downloading WinPE UI ({0}) from Drive..." -f $Arch) }
            EmitLog -Disk 0 -Msg ("WinPeUi: Drive WinPEUI/{0} -> {1}" -f $zipName, $downloadZip)
            try {
                Invoke-LwDriveHttpWinPeUiZip -DestPath $downloadZip -FileName $zipName -OnJsonLine {
                    param($line)
                    if ([string]::IsNullOrWhiteSpace($line)) { return }
                    $trim = $line.TrimStart()
                    if (-not $trim.StartsWith('{')) { return }
                    try {
                        $obj = $trim | ConvertFrom-Json -ErrorAction Stop
                        if ($obj.event -eq 'log' -and $obj.message) {
                            EmitLog -Disk 0 -Msg ([string]$obj.message)
                        } elseif ($obj.event -eq 'progress' -and ($null -ne $obj.pct)) {
                            Emit @{ event = 'progress'; disk = 0; phase = 'winpe-ui'; pct = [int]$obj.pct; message = ("Downloading WinPE UI ({0})..." -f $Arch) }
                        }
                    } catch { }
                }
                if (Test-Path -LiteralPath $downloadZip) {
                    $localZip = $downloadZip
                    $driveOk = $true
                }
            } catch {
                EmitLog -Disk 0 -Msg ("WinPeUi: Drive download skipped ({0})" -f $_.Exception.Message)
            }
        }
        if (-not $driveOk) {
            $base = [string]$WinPeUiZipBaseUrl
            if ([string]::IsNullOrWhiteSpace($base)) {
                if ($Required) {
                    throw ("WinPeUi {0}: no local/Drive zip and -WinPeUiZipBaseUrl was not set (run npm run winpe-ui:stage-drive, or pass the public bin/ URL)." -f $Arch)
                }
                return ''
            }
            $base = $base.TrimEnd('/')
            $url = "$base/$zipName"
            EmitLog -Disk 0 -Msg ("WinPeUi: downloading {0} -> {1}" -f $url, $downloadZip)
            Emit @{ event = 'progress'; disk = 0; phase = 'winpe-ui'; pct = 0; message = ("Downloading WinPE UI ({0})..." -f $Arch) }
            try {
                Invoke-WebRequest -Uri $url -OutFile $downloadZip -UseBasicParsing -ErrorAction Stop
            } catch {
                if ($Required) { throw ("WinPeUi {0}: download failed from {1}: {2}" -f $Arch, $url, $_.Exception.Message) }
                EmitLog -Disk 0 -Msg ("WinPeUi: download failed ({0}) - splash stays USB-only" -f $_.Exception.Message)
                return ''
            }
            $localZip = $downloadZip
        }
    }

    if (-not $localZip -or -not (Test-Path -LiteralPath $localZip)) {
        if ($Required) { throw ("WinPeUi {0}: zip missing" -f $Arch) }
        return ''
    }

    if (Test-Path -LiteralPath $cached) {
        Remove-Item -LiteralPath $cached -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Path $cached -Force | Out-Null
    Expand-Archive -LiteralPath $localZip -DestinationPath $cached -Force
    if (-not (Test-Path -LiteralPath $cachedExe)) {
        # Some zips nest one folder; flatten one level if needed.
        $nested = Get-ChildItem -LiteralPath $cached -Directory -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($nested -and (Test-Path -LiteralPath (Join-Path $nested.FullName 'LoneWolf.WinPeUi.exe'))) {
            Copy-Item -Path (Join-Path $nested.FullName '*') -Destination $cached -Recurse -Force
        }
    }
    if (-not (Test-Path -LiteralPath $cachedExe)) {
        if ($Required) { throw ("WinPeUi {0}: LoneWolf.WinPeUi.exe missing after expand of {1}" -f $Arch, $localZip) }
        EmitLog -Disk 0 -Msg ("WinPeUi: expand of {0} did not yield LoneWolf.WinPeUi.exe" -f $localZip)
        return ''
    }
    EmitLog -Disk 0 -Msg ("WinPeUi: ready at {0}" -f $cached)
    return $cached
}

function Ensure-LwWinPeUiForBuild {
    param([string[]] $Arches = @('AMD64', 'ARM64'))
    if (-not $script:LwWinPeUiCacheRoot) {
        if ($CacheRoot) {
            $script:LwWinPeUiCacheRoot = Join-Path $CacheRoot 'WinPeUi'
        } else {
            $script:LwWinPeUiCacheRoot = Join-Path $env:TEMP ('LWWinPeUi_' + [guid]::NewGuid().ToString('n').Substring(0, 8))
        }
    }
    foreach ($a in $Arches) {
        $folder = Get-LwWinPeUiFolderName -Arch $a
        $null = Ensure-LwWinPeUiArchDir -Arch $folder
    }
}

# --- Build ESP + overlay local cache -----------------------------------------
function Build-Cache {
    param([string]$StagingWindowsDir, [string]$StagingWim)

    if ([string]::IsNullOrWhiteSpace($StagingWindowsDir)) {
        throw 'Build-Cache: StagingWindowsDir is empty (no staging root for WIM-mode ESP cache)'
    }
    if ([string]::IsNullOrWhiteSpace($espCache) -or [string]::IsNullOrWhiteSpace($overlayCache)) {
        throw 'Build-Cache: espCache/overlayCache not initialized'
    }
    New-Item -ItemType Directory -Force -Path $espCache, $overlayCache | Out-Null

    # ESP: copy all staging content except sources\install.* and staged *.wim/*.esd/*.swm files
    # (The arch WIM e.g. AMD64.wim lives alongside the ISO files; exclude it from the ESP copy.)
    EmitProgress -Disk 0 -Phase 'esp-copy' -Pct 0
    $items = Get-ChildItem -LiteralPath $StagingWindowsDir -Force -ErrorAction SilentlyContinue |
        Where-Object { -not (-not $_.PSIsContainer -and $_.Name -match '\.(wim|esd|swm)$') }
    $total = @($items).Count; $i = 0
    foreach ($item in $items) {
        $i++
        $pct = [math]::Min(95, [math]::Round($i / [math]::Max($total,1) * 100))
        EmitProgress -Disk 0 -Phase 'esp-copy' -Pct $pct

        if ($item.PSIsContainer -and $item.Name -ieq 'sources') {
            $dstSrc = Join-Path $espCache 'sources'
            New-Item -ItemType Directory -Force -Path $dstSrc | Out-Null
            # ESP only needs boot.wim (WinPE boot image) and *.sdi from sources/.
            # Skip all subdirectories (sxs/, en-us/, migration/, etc.) and the hundreds of
            # setup DLLs - those belong on the data partition, not the FAT32 ESP.
            foreach ($child in (Get-ChildItem -LiteralPath $item.FullName -File -Force -ErrorAction SilentlyContinue)) {
                if ($child.Name -ieq 'boot.wim' -or $child.Name -match '\.sdi$') {
                    Copy-Item -LiteralPath $child.FullName -Destination $dstSrc -Force -ErrorAction SilentlyContinue
                }
            }
        } elseif ($item.PSIsContainer) {
            Copy-Item -LiteralPath $item.FullName -Destination $espCache -Recurse -Force -ErrorAction SilentlyContinue
        } else {
            Copy-Item -LiteralPath $item.FullName -Destination $espCache -Force -ErrorAction SilentlyContinue
        }
    }

    # Copy pre-injection sentinel alongside boot.wim so the runtime skip-check works.
    # Written by _inject-boot-wim.ps1; contains the SHA256 hash of WinPE-Startnet.cmd.
    #
    # Always delete any existing ESP cache sentinel first: boot.wim was just replaced with
    # a fresh copy from staging whose preserved timestamp may be OLDER than a previous
    # injection sentinel, fooling the age check into skipping injection on a stock boot.wim.
    $sentinelSrc = Join-Path $StagingWindowsDir 'sources\boot.wim.lw-injected'
    $sentinelDst = Join-Path $espCache           'sources\boot.wim.lw-injected'
    $espBootWim  = Join-Path $espCache           'sources\boot.wim'
    if (-not [string]::IsNullOrWhiteSpace($script:LwBootInjectSourcesDir)) {
        $biBoot = Join-Path $script:LwBootInjectSourcesDir 'boot.wim'
        $biSent = Join-Path $script:LwBootInjectSourcesDir 'boot.wim.lw-injected'
        if (Test-Path -LiteralPath $biBoot) {
            Copy-Item -LiteralPath $biBoot -Destination $espBootWim -Force -ErrorAction Stop
        }
        Remove-Item -LiteralPath $sentinelDst -Force -ErrorAction SilentlyContinue
        if ((Test-Path -LiteralPath $biSent) -and (Test-Path -LiteralPath $espBootWim)) {
            Copy-Item -LiteralPath $biSent -Destination $sentinelDst -Force -ErrorAction SilentlyContinue
        }
    } else {
        Remove-Item -LiteralPath $sentinelDst -Force -ErrorAction SilentlyContinue
        # Only restore the sentinel when the staging copy is newer than the staging boot.wim,
        # which proves the staging boot.wim itself is the pre-injected version.
        if ((Test-Path -LiteralPath $sentinelSrc) -and (Test-Path -LiteralPath $espBootWim)) {
            if ((Get-Item -LiteralPath $sentinelSrc).LastWriteTime -ge (Get-Item -LiteralPath $espBootWim).LastWriteTime) {
                Copy-Item -LiteralPath $sentinelSrc -Destination $sentinelDst -Force -ErrorAction SilentlyContinue
            }
        }
    }

    # Ensure efi\microsoft\boot\bootmgfw.efi and the arch removable loader exist.
    # AMD64 ISOs may only ship efi\boot\bootx64.efi; ARM64 ISOs ship efi\boot\bootaa64.efi.
    # The ISO-sourced BCD uses a `locate` device anchored to \EFI\Microsoft\Boot\bootmgfw.efi
    # to establish the Boot Manager's home partition context.  If that file is absent the
    # locate fails, the ramdisk device for \sources\boot.wim cannot be resolved, and the
    # system shows the 0xc0000098 (STATUS_NO_SUCH_FILE) recovery screen.
    $synthFrom = Repair-LwEspBootLoaders -EspRoot $espCache -WorkflowType $WorkflowType
    if ($synthFrom) {
        EmitLog -Disk 0 -Msg ("esp-cache: synthesised efi\microsoft\boot\bootmgfw.efi from efi\boot\{0} (ISO omitted it)" -f $synthFrom)
    }

    # SetupConfig.ini in ESP cache
    @('[SetupConfig]','BitLocker=AlwaysSuspend','NoReboot','ShowOOBE=None',
      'Quiet','BypassNRO=1','[Compat]','IgnoreWarning=1') |
        Set-Content -LiteralPath (Join-Path $espCache 'sources\SetupConfig.ini') -Encoding ascii -Force -ErrorAction SilentlyContinue

    EmitProgress -Disk 0 -Phase 'esp-copy' -Pct 100

    # Overlay cache — wipe and recreate so no stale payload files survive across workflow-type
    # switches (e.g. a prior full AMD64 build populates Deploy\, WUPayload\, Scripts\ in the
    # same cache root; New-Item -Force on an existing directory does NOT clear old content).
    Remove-Item -LiteralPath $overlayCache -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $overlayCache | Out-Null

    if (-not $NoPayload) {
        # Deploy\ and Scripts\ are the install boot path. WUPayload is staged only for
        # full Snapdragon Windows Updates ($stageWuPayload).
        $cacheOverlayProfile = Get-LwUsbOverlayProfile -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload $false
        New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Deploy'), (Join-Path $overlayCache 'FirstBase\Policy'), (Join-Path $overlayCache 'FirstBase\Scripts'), (Join-Path $overlayCache 'FirstBase\WUPayload'), (Join-Path $overlayCache 'FirstBase\WUPayload\Tools') | Out-Null
        $overlayMap = @(
            @{ Src = (Join-Path $ContentRoot $cacheOverlayProfile.TechInstallSource);         Dst = $cacheOverlayProfile.TechInstallDest },
            @{ Src = (Join-Path $ContentRoot 'Deploy\disksetup.cmd');                         Dst = 'FirstBase\Deploy\disksetup.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Invoke-FirstBaseRaidProbe.ps1');         Dst = 'FirstBase\Deploy\Invoke-FirstBaseRaidProbe.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd');                    Dst = 'FirstBase\Deploy\WinPE-Startnet.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Show-DeployBanner.ps1');                 Dst = 'FirstBase\Deploy\Show-DeployBanner.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Invoke-FbDeployUi.ps1');                 Dst = 'FirstBase\Deploy\Invoke-FbDeployUi.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Launch-FbWinPeUiEarly.cmd');             Dst = 'FirstBase\Deploy\Launch-FbWinPeUiEarly.cmd' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1');                   Dst = 'FirstBase\Deploy\FirstBaseBuildIdentity.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\Invoke-FirstBaseDismApply.ps1');        Dst = 'FirstBase\Scripts\Invoke-FirstBaseDismApply.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\Remove-FbProvisionedBloat.ps1');        Dst = 'FirstBase\Scripts\Remove-FbProvisionedBloat.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\LayoutModification.json');              Dst = 'FirstBase\Scripts\LayoutModification.json' },
            @{ Src = (Join-Path $ContentRoot (Get-LwUsbOverlayUnattendSource -QuickInstall ([bool]$QuickInstall))); Dst = 'FirstBase\Autounattend.xml' },
            @{ Src = (Join-Path $ContentRoot (Get-LwUsbOverlayUnattendSource -QuickInstall ([bool]$QuickInstall))); Dst = 'FirstBase\Policy\Autounattend.xml' },
            @{ Src = (Join-Path $ContentRoot 'SetupComplete.cmd');                            Dst = 'FirstBase\WUPayload\SetupComplete.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1');                 Dst = 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Tools\fb-dump.ps1');                             Dst = 'FirstBase\WUPayload\Tools\fb-dump.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Tools\fb-im.cmd');                               Dst = 'fb-im.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Tools\fb-im.ps1');                               Dst = 'FirstBase\WUPayload\Tools\fb-im.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseDebugHotkeyWatcher.ps1');              Dst = 'FirstBase\WUPayload\FirstBaseDebugHotkeyWatcher.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseDeferredOobeSound.ps1');               Dst = 'FirstBase\WUPayload\FirstBaseDeferredOobeSound.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseHandoffSplash.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseHandoffSplash.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseOobeDeferredSoundBootstrap.ps1');      Dst = 'FirstBase\WUPayload\FirstBaseOobeDeferredSoundBootstrap.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseOobeOperatorFinalize.ps1');            Dst = 'FirstBase\WUPayload\FirstBaseOobeOperatorFinalize.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseOpenSettingsAndFinish.ps1');           Dst = 'FirstBase\WUPayload\FirstBaseOpenSettingsAndFinish.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseHardwareCheck.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseHardwareCheck.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Install-FbMicrosoftEdge.ps1');                  Dst = 'FirstBase\WUPayload\Install-FbMicrosoftEdge.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBasePostSysprepOobeSoundArm.ps1');         Dst = 'FirstBase\WUPayload\FirstBasePostSysprepOobeSoundArm.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseShowSplash.ps1');                      Dst = 'FirstBase\WUPayload\FirstBaseShowSplash.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashSingleInstance.ps1');            Dst = 'FirstBase\WUPayload\FirstBaseSplashSingleInstance.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashWatcher.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseSplashWatcher.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseVersion.cmd');                         Dst = 'FirstBase\WUPayload\FirstBaseVersion.cmd' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseVersion.ps1');                         Dst = 'FirstBase\WUPayload\FirstBaseVersion.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseBuildIdentity.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseWuEngine.ps1');                        Dst = 'FirstBase\WUPayload\FirstBaseWuEngine.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Show-UpdateProgress.ps1');                      Dst = 'FirstBase\WUPayload\Show-UpdateProgress.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashTechMenu.ps1');                  Dst = 'FirstBase\WUPayload\FirstBaseSplashTechMenu.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Tools\seal_command.txt');                       Dst = 'FirstBase\WUPayload\Tools\seal_command.txt' },
            @{ Src = (Join-Path $ContentRoot 'FirstBase.ico');                                Dst = 'FirstBase\FirstBase.ico' }
        )
        if (-not $stageWuPayload) {
            $overlayMap = @($overlayMap | Where-Object { -not (Test-LwUpdatePayloadOverlayDest -Destination $_.Dst) })
        }
        if ($QuickInstall) {
            $overlayMap = @($overlayMap | Where-Object { -not (Test-LwQuickInstallSkipDeployOverlayDest -Destination $_.Dst) })
        }
        foreach ($o in $overlayMap) {
            $cacheDst = Join-Path $overlayCache $o.Dst
            $copied = Copy-LwOverlayPayloadFile -Source $o.Src -Destination $cacheDst
            if (-not $copied -and $o.Dst -eq 'FirstBase\Deploy\TechInstall.cmd' -and -not $NoPayload) {
                throw "FATAL: updates overlay source missing: $($o.Src)"
            }
        }
        if (-not $NoPayload) {
            Assert-LwUpdatesOverlayTechInstall -PartRoot $overlayCache -WorkflowType $WorkflowType -QuickInstall $false -NoPayload $false
        }
        if ($QuickInstall) {
            Assert-LwQuickInstallUnattend -PartRoot $overlayCache
            Remove-LwQuickInstallStartnetFromDeploy -PartRoot $overlayCache
        }
        if ($stageWuPayload) {
            Copy-LwRepoEdgeInstaller -DestRoot $overlayCache
            Assert-LwUpdateLoopCopy -Src (Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1') -Dst (Join-Path $overlayCache 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1')
        }
        $scriptsSrc = Join-Path $ContentRoot 'Scripts'
        if (Test-Path -LiteralPath $scriptsSrc) {
            $scriptsDst = Join-Path $overlayCache 'FirstBase\Scripts'
            New-Item -ItemType Directory -Path $scriptsDst -Force | Out-Null
            Copy-Item -Path (Join-Path $scriptsSrc '*') -Destination $scriptsDst -Recurse -Force -ErrorAction SilentlyContinue
        }
        if ($stageWuPayload) {
            $edgeShare = ''
            try { $edgeShare = [string]$shareLayout.EdgeRoot } catch {}
            $null = Copy-LwEdgeOfflineInstaller -WuPayloadRoot (Join-Path $overlayCache 'FirstBase\WUPayload') -Arch $wfUpper -ContentRoot $ContentRoot -EdgeShareRoot $edgeShare
        }
        if ($DevBuild -and $stageWuPayload) {
            try {
                $wuDir = Join-Path $overlayCache 'FirstBase\WUPayload'
                if (-not (Test-Path -LiteralPath $wuDir)) { New-Item -ItemType Directory -Force -Path $wuDir | Out-Null }
                $pv = if ($ScriptVersion) { [string]$ScriptVersion } else { [string]$StagingVersion }
                $markerBody = "destage=1`r`nchannel=destage`r`npayloadVersion=$pv`r`nscriptVersion=$pv`r`nbuiltAt=$(Get-Date -Format 'o')`r`n"
                if ($DestageSkipWu) { $markerBody += "destageSkipWu=1`r`n" }
                [System.IO.File]::WriteAllText((Join-Path $wuDir '.dev-build'), $markerBody, [System.Text.UTF8Encoding]::new($false))
            } catch {}
        } else {
            foreach ($rel in @('FirstBase\WUPayload\.dev-build', 'FirstBase\.dev-build', '.dev-build')) {
                $marker = Join-Path $overlayCache $rel
                if (Test-Path -LiteralPath $marker) {
                    Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
                }
            }
        }
        if (-not $stageWuPayload) {
            Remove-LwStagedWindowsUpdatePayload -PartRoot $overlayCache
        }
    } else {
        # WIN-INSTALL: overlay uses the same TechInstall architecture as a full build.
        # startnet -> wpeinit -> WinPE-Startnet.cmd -> TechInstall.cmd -> disksetup.cmd + DISM apply + bcdboot + shutdown.
        New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Policy'), (Join-Path $overlayCache 'FirstBase\Deploy'), (Join-Path $overlayCache 'FirstBase\WUPayload\Tools') | Out-Null
        # Prefer autounattend-install.xml (no SetupComplete.cmd RunSynchronous) over the full version.
        $autounattendInstallSrc = Join-Path $ContentRoot 'Policy\autounattend-install.xml'
        $autounattendSrc = if (Test-Path -LiteralPath $autounattendInstallSrc) { $autounattendInstallSrc } else { Join-Path $ContentRoot 'Policy\autounattend.xml' }
        if (Test-Path -LiteralPath $autounattendSrc) {
            Copy-Item -LiteralPath $autounattendSrc -Destination (Join-Path $overlayCache 'FirstBase\Autounattend.xml') -Force
            Copy-Item -LiteralPath $autounattendSrc -Destination (Join-Path $overlayCache 'FirstBase\Policy\Autounattend.xml') -Force
        }
        # TechInstall-Install.cmd: stripped deploy script (no WU payload staging).
        $techInstallInstallSrc = Join-Path $ContentRoot 'Deploy\TechInstall-Install.cmd'
        if (Test-Path -LiteralPath $techInstallInstallSrc) {
            Copy-Item -LiteralPath $techInstallInstallSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\TechInstall.cmd') -Force
        }
        # WinPE-Startnet.cmd: WinPE bootstrap that finds and calls FirstBase\Deploy\TechInstall.cmd on the data partition.
        $winpeStartnetSrc = Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd'
        if (Test-Path -LiteralPath $winpeStartnetSrc) {
            Copy-Item -LiteralPath $winpeStartnetSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\WinPE-Startnet.cmd') -Force
        }
        # Show-DeployBanner.ps1: PowerShell-rendered animated WinPE title banner.
        $bannerSrc = Join-Path $ContentRoot 'Deploy\Show-DeployBanner.ps1'
        if (Test-Path -LiteralPath $bannerSrc) {
            Copy-Item -LiteralPath $bannerSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\Show-DeployBanner.ps1') -Force
        }
        # Invoke-FbDeployUi.ps1: the PowerShell deploy screen that TechInstall*.cmd
        # repaints at every step. Without it the deploy falls back to the plain
        # echo progress bar, so it must ship alongside the banner.
        $deployUiSrc = Join-Path $ContentRoot 'Deploy\Invoke-FbDeployUi.ps1'
        if (Test-Path -LiteralPath $deployUiSrc) {
            Copy-Item -LiteralPath $deployUiSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\Invoke-FbDeployUi.ps1') -Force
        }
        $earlyUiSrc = Join-Path $ContentRoot 'Deploy\Launch-FbWinPeUiEarly.cmd'
        if (Test-Path -LiteralPath $earlyUiSrc) {
            Copy-Item -LiteralPath $earlyUiSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\Launch-FbWinPeUiEarly.cmd') -Force
        }
        # FirstBaseBuildIdentity.ps1: the shared dev/release resolver. The banner
        # and the deploy screen both dot-source it from Deploy\, and default to
        # release without it, so it has to land beside them.
        $identitySrc = Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1'
        if (Test-Path -LiteralPath $identitySrc) {
            Copy-Item -LiteralPath $identitySrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\FirstBaseBuildIdentity.ps1') -Force
        }
        # disksetup.cmd: diskpart script that creates ESP + Windows partitions on the target disk.
        $disksetupSrc = Join-Path $ContentRoot 'Deploy\disksetup.cmd'
        if (Test-Path -LiteralPath $disksetupSrc) {
            Copy-Item -LiteralPath $disksetupSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\disksetup.cmd') -Force
        }
        # Invoke-FirstBaseDismApply.ps1: PowerShell DISM apply UI (live progress) for the QuickInstall console.
        $dismApplySrc = Join-Path $ContentRoot 'Scripts\Invoke-FirstBaseDismApply.ps1'
        if (Test-Path -LiteralPath $dismApplySrc) {
            New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Scripts') | Out-Null
            Copy-Item -LiteralPath $dismApplySrc -Destination (Join-Path $overlayCache 'FirstBase\Scripts\Invoke-FirstBaseDismApply.ps1') -Force
        }
        $bloatSrc = Join-Path $ContentRoot 'Scripts\Remove-FbProvisionedBloat.ps1'
        if (Test-Path -LiteralPath $bloatSrc) {
            New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Scripts') | Out-Null
            Copy-Item -LiteralPath $bloatSrc -Destination (Join-Path $overlayCache 'FirstBase\Scripts\Remove-FbProvisionedBloat.ps1') -Force
        }
        $layoutSrc = Join-Path $ContentRoot 'Scripts\LayoutModification.json'
        if (Test-Path -LiteralPath $layoutSrc) {
            New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Scripts') | Out-Null
            Copy-Item -LiteralPath $layoutSrc -Destination (Join-Path $overlayCache 'FirstBase\Scripts\LayoutModification.json') -Force
        }
        # fb-im front-end: cmd launcher stays at volume ROOT; PS backend + fb-dump backend under FirstBase\WUPayload\Tools\.
        $imCmdSrc = Join-Path $ContentRoot 'Tools\fb-im.cmd'
        if (Test-Path -LiteralPath $imCmdSrc) {
            Copy-Item -LiteralPath $imCmdSrc -Destination (Join-Path $overlayCache 'fb-im.cmd') -Force
        }
        $imPs1Src = Join-Path $ContentRoot 'Tools\fb-im.ps1'
        if (Test-Path -LiteralPath $imPs1Src) {
            Copy-Item -LiteralPath $imPs1Src -Destination (Join-Path $overlayCache 'FirstBase\WUPayload\Tools\fb-im.ps1') -Force
        }
        $dumpPs1Src = Join-Path $ContentRoot 'Tools\fb-dump.ps1'
        if (Test-Path -LiteralPath $dumpPs1Src) {
            Copy-Item -LiteralPath $dumpPs1Src -Destination (Join-Path $overlayCache 'FirstBase\WUPayload\Tools\fb-dump.ps1') -Force
        }
        $icoSrc = Join-Path $ContentRoot 'FirstBase.ico'
        if (Test-Path -LiteralPath $icoSrc) {
            Copy-Item -LiteralPath $icoSrc -Destination (Join-Path $overlayCache 'FirstBase\FirstBase.ico') -Force
        }
        Copy-LwPeBrailleFont -OverlayRoot $overlayCache
        Copy-LwWinPeUiOverlay -OverlayRoot $overlayCache
    }
}

# --- ISO-direct ESP + overlay cache builder -----------------------------------
# Used when no pre-staged WIM exists and the build runs directly from a mounted ISO.
# The ISO must already be mounted; $IsoDrive is the drive root (e.g. "D:\").
function Build-IsoCache {
    param([string]$IsoDrive)

    New-Item -ItemType Directory -Force -Path $espCache, $overlayCache | Out-Null

    EmitProgress -Disk 0 -Phase 'esp-copy' -Pct 0

    # Copy all ISO root items except sources\ (and any loose WIM/ESD/SWM files).
    # Iterate per item so the progress bar advances instead of staying at 0% for minutes.
    $isoEntries = @(Get-ChildItem -LiteralPath $IsoDrive -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ine 'sources' -and
                       -not (-not $_.PSIsContainer -and $_.Name -match '\.(wim|esd|swm)$') })
    $isoEntryTotal = [math]::Max(1, $isoEntries.Count)
    $isoEntryIdx   = 0
    foreach ($isoEntry in $isoEntries) {
        $isoEntryIdx++
        $pct = [math]::Min(79, [math]::Round($isoEntryIdx / $isoEntryTotal * 80))
        EmitProgress -Disk 0 -Phase 'esp-copy' -Pct $pct
        if ($isoEntry.PSIsContainer) {
            Copy-Item -LiteralPath $isoEntry.FullName -Destination $espCache -Recurse -Force -ErrorAction SilentlyContinue
        } else {
            Copy-Item -LiteralPath $isoEntry.FullName -Destination $espCache -Force -ErrorAction SilentlyContinue
        }
    }

    # Copy sources\boot.wim only (needed for ESP; install.wim stays on the ISO)
    EmitProgress -Disk 0 -Phase 'esp-copy' -Pct 85
    $espSourcesDir = Join-Path $espCache 'sources'
    New-Item -ItemType Directory -Force -Path $espSourcesDir | Out-Null
    $bootWimSrc = Join-Path $IsoDrive 'sources\boot.wim'
    if (-not [string]::IsNullOrWhiteSpace($script:LwBootInjectSourcesDir)) {
        $bootWimSrc = Join-Path $script:LwBootInjectSourcesDir 'boot.wim'
    }
    if (Test-Path -LiteralPath $bootWimSrc) {
        Copy-Item -LiteralPath $bootWimSrc -Destination $espSourcesDir -Force -ErrorAction SilentlyContinue
    }

    # Copy pre-injection sentinel from BootInject or staging (not from the ISO).
    $sentinelSrc = if (-not [string]::IsNullOrWhiteSpace($script:LwBootInjectSourcesDir)) {
        Join-Path $script:LwBootInjectSourcesDir 'boot.wim.lw-injected'
    } else {
        Join-Path $ArchRoot 'sources\boot.wim.lw-injected'
    }
    $sentinelDst = Join-Path $espSourcesDir 'boot.wim.lw-injected'
    $espBootWim  = Join-Path $espSourcesDir 'boot.wim'
    Remove-Item -LiteralPath $sentinelDst -Force -ErrorAction SilentlyContinue
    if (-not [string]::IsNullOrWhiteSpace($script:LwBootInjectSourcesDir)) {
        if ((Test-Path -LiteralPath $sentinelSrc) -and (Test-Path -LiteralPath $espBootWim)) {
            Copy-Item -LiteralPath $sentinelSrc -Destination $sentinelDst -Force -ErrorAction SilentlyContinue
        }
    } elseif ((Test-Path -LiteralPath $sentinelSrc) -and (Test-Path -LiteralPath $espBootWim)) {
        if ((Get-Item -LiteralPath $sentinelSrc).LastWriteTime -ge (Get-Item -LiteralPath $espBootWim).LastWriteTime) {
            Copy-Item -LiteralPath $sentinelSrc -Destination $sentinelDst -Force -ErrorAction SilentlyContinue
        }
    }

    # Ensure efi\microsoft\boot\bootmgfw.efi and the arch removable loader exist.
    # AMD64 ISOs may only ship efi\boot\bootx64.efi; ARM64 ISOs ship efi\boot\bootaa64.efi.
    $synthFrom = Repair-LwEspBootLoaders -EspRoot $espCache -WorkflowType $WorkflowType
    if ($synthFrom) {
        EmitLog -Disk 0 -Msg ("esp-cache: synthesised efi\microsoft\boot\bootmgfw.efi from efi\boot\{0} (ISO omitted it)" -f $synthFrom)
    }

    # SetupConfig.ini in ESP cache
    EmitProgress -Disk 0 -Phase 'esp-copy' -Pct 95
    @('[SetupConfig]','BitLocker=AlwaysSuspend','NoReboot','ShowOOBE=None',
      'Quiet','BypassNRO=1','[Compat]','IgnoreWarning=1') |
        Set-Content -LiteralPath (Join-Path $espCache 'sources\SetupConfig.ini') -Encoding ascii -Force -ErrorAction SilentlyContinue

    EmitProgress -Disk 0 -Phase 'esp-copy' -Pct 100

    # Overlay cache — wipe and recreate so no stale payload files survive across workflow-type
    # switches (same logic as Build-Cache; New-Item -Force never clears existing content).
    Remove-Item -LiteralPath $overlayCache -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $overlayCache | Out-Null

    if (-not $NoPayload) {
        # Deploy\ and Scripts\ are the install boot path. WUPayload is staged only for
        # full Snapdragon Windows Updates ($stageWuPayload).
        $cacheOverlayProfile = Get-LwUsbOverlayProfile -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload $false
        New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Deploy'), (Join-Path $overlayCache 'FirstBase\Policy'), (Join-Path $overlayCache 'FirstBase\Scripts'), (Join-Path $overlayCache 'FirstBase\WUPayload'), (Join-Path $overlayCache 'FirstBase\WUPayload\Tools') | Out-Null
        $overlayMap = @(
            @{ Src = (Join-Path $ContentRoot $cacheOverlayProfile.TechInstallSource);         Dst = $cacheOverlayProfile.TechInstallDest },
            @{ Src = (Join-Path $ContentRoot 'Deploy\disksetup.cmd');                         Dst = 'FirstBase\Deploy\disksetup.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Invoke-FirstBaseRaidProbe.ps1');         Dst = 'FirstBase\Deploy\Invoke-FirstBaseRaidProbe.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd');                    Dst = 'FirstBase\Deploy\WinPE-Startnet.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Show-DeployBanner.ps1');                 Dst = 'FirstBase\Deploy\Show-DeployBanner.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Invoke-FbDeployUi.ps1');                 Dst = 'FirstBase\Deploy\Invoke-FbDeployUi.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Launch-FbWinPeUiEarly.cmd');             Dst = 'FirstBase\Deploy\Launch-FbWinPeUiEarly.cmd' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1');                   Dst = 'FirstBase\Deploy\FirstBaseBuildIdentity.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\Invoke-FirstBaseDismApply.ps1');        Dst = 'FirstBase\Scripts\Invoke-FirstBaseDismApply.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\Remove-FbProvisionedBloat.ps1');        Dst = 'FirstBase\Scripts\Remove-FbProvisionedBloat.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\LayoutModification.json');              Dst = 'FirstBase\Scripts\LayoutModification.json' },
            @{ Src = (Join-Path $ContentRoot (Get-LwUsbOverlayUnattendSource -QuickInstall ([bool]$QuickInstall))); Dst = 'FirstBase\Autounattend.xml' },
            @{ Src = (Join-Path $ContentRoot (Get-LwUsbOverlayUnattendSource -QuickInstall ([bool]$QuickInstall))); Dst = 'FirstBase\Policy\Autounattend.xml' },
            @{ Src = (Join-Path $ContentRoot 'SetupComplete.cmd');                            Dst = 'FirstBase\WUPayload\SetupComplete.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1');                 Dst = 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Tools\fb-dump.ps1');                             Dst = 'FirstBase\WUPayload\Tools\fb-dump.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Tools\fb-im.cmd');                               Dst = 'fb-im.cmd' },
            @{ Src = (Join-Path $ContentRoot 'Tools\fb-im.ps1');                               Dst = 'FirstBase\WUPayload\Tools\fb-im.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseDebugHotkeyWatcher.ps1');              Dst = 'FirstBase\WUPayload\FirstBaseDebugHotkeyWatcher.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseDeferredOobeSound.ps1');               Dst = 'FirstBase\WUPayload\FirstBaseDeferredOobeSound.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseHandoffSplash.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseHandoffSplash.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseOobeDeferredSoundBootstrap.ps1');      Dst = 'FirstBase\WUPayload\FirstBaseOobeDeferredSoundBootstrap.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseOobeOperatorFinalize.ps1');            Dst = 'FirstBase\WUPayload\FirstBaseOobeOperatorFinalize.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseOpenSettingsAndFinish.ps1');           Dst = 'FirstBase\WUPayload\FirstBaseOpenSettingsAndFinish.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseHardwareCheck.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseHardwareCheck.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Install-FbMicrosoftEdge.ps1');                  Dst = 'FirstBase\WUPayload\Install-FbMicrosoftEdge.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBasePostSysprepOobeSoundArm.ps1');         Dst = 'FirstBase\WUPayload\FirstBasePostSysprepOobeSoundArm.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseShowSplash.ps1');                      Dst = 'FirstBase\WUPayload\FirstBaseShowSplash.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashSingleInstance.ps1');            Dst = 'FirstBase\WUPayload\FirstBaseSplashSingleInstance.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashWatcher.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseSplashWatcher.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseVersion.cmd');                         Dst = 'FirstBase\WUPayload\FirstBaseVersion.cmd' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseVersion.ps1');                         Dst = 'FirstBase\WUPayload\FirstBaseVersion.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseBuildIdentity.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseWuEngine.ps1');                        Dst = 'FirstBase\WUPayload\FirstBaseWuEngine.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Show-UpdateProgress.ps1');                      Dst = 'FirstBase\WUPayload\Show-UpdateProgress.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashTechMenu.ps1');                  Dst = 'FirstBase\WUPayload\FirstBaseSplashTechMenu.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Tools\seal_command.txt');                       Dst = 'FirstBase\WUPayload\Tools\seal_command.txt' },
            @{ Src = (Join-Path $ContentRoot 'FirstBase.ico');                                Dst = 'FirstBase\FirstBase.ico' }
        )
        if (-not $stageWuPayload) {
            $overlayMap = @($overlayMap | Where-Object { -not (Test-LwUpdatePayloadOverlayDest -Destination $_.Dst) })
        }
        if ($QuickInstall) {
            $overlayMap = @($overlayMap | Where-Object { -not (Test-LwQuickInstallSkipDeployOverlayDest -Destination $_.Dst) })
        }
        foreach ($o in $overlayMap) {
            $cacheDst = Join-Path $overlayCache $o.Dst
            $copied = Copy-LwOverlayPayloadFile -Source $o.Src -Destination $cacheDst
            if (-not $copied -and $o.Dst -eq 'FirstBase\Deploy\TechInstall.cmd' -and -not $NoPayload) {
                throw "FATAL: updates overlay source missing: $($o.Src)"
            }
        }
        if (-not $NoPayload) {
            Assert-LwUpdatesOverlayTechInstall -PartRoot $overlayCache -WorkflowType $WorkflowType -QuickInstall $false -NoPayload $false
        }
        if ($QuickInstall) {
            Assert-LwQuickInstallUnattend -PartRoot $overlayCache
            Remove-LwQuickInstallStartnetFromDeploy -PartRoot $overlayCache
        }
        if ($stageWuPayload) {
            Copy-LwRepoEdgeInstaller -DestRoot $overlayCache
            Assert-LwUpdateLoopCopy -Src (Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1') -Dst (Join-Path $overlayCache 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1')
        }
        $scriptsSrc = Join-Path $ContentRoot 'Scripts'
        if (Test-Path -LiteralPath $scriptsSrc) {
            $scriptsDst = Join-Path $overlayCache 'FirstBase\Scripts'
            New-Item -ItemType Directory -Path $scriptsDst -Force | Out-Null
            Copy-Item -Path (Join-Path $scriptsSrc '*') -Destination $scriptsDst -Recurse -Force -ErrorAction SilentlyContinue
        }
        if ($stageWuPayload) {
            $edgeShare = ''
            try { $edgeShare = [string]$shareLayout.EdgeRoot } catch {}
            $null = Copy-LwEdgeOfflineInstaller -WuPayloadRoot (Join-Path $overlayCache 'FirstBase\WUPayload') -Arch $wfUpper -ContentRoot $ContentRoot -EdgeShareRoot $edgeShare
        }
        if ($DevBuild -and $stageWuPayload) {
            try {
                $wuDir = Join-Path $overlayCache 'FirstBase\WUPayload'
                if (-not (Test-Path -LiteralPath $wuDir)) { New-Item -ItemType Directory -Force -Path $wuDir | Out-Null }
                $pv = if ($ScriptVersion) { [string]$ScriptVersion } else { [string]$StagingVersion }
                $markerBody = "destage=1`r`nchannel=destage`r`npayloadVersion=$pv`r`nscriptVersion=$pv`r`nbuiltAt=$(Get-Date -Format 'o')`r`n"
                if ($DestageSkipWu) { $markerBody += "destageSkipWu=1`r`n" }
                [System.IO.File]::WriteAllText((Join-Path $wuDir '.dev-build'), $markerBody, [System.Text.UTF8Encoding]::new($false))
            } catch {}
        } else {
            foreach ($rel in @('FirstBase\WUPayload\.dev-build', 'FirstBase\.dev-build', '.dev-build')) {
                $marker = Join-Path $overlayCache $rel
                if (Test-Path -LiteralPath $marker) {
                    Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
                }
            }
        }
        if (-not $stageWuPayload) {
            Remove-LwStagedWindowsUpdatePayload -PartRoot $overlayCache
        }
    } else {
        # WIN-INSTALL: overlay uses the same TechInstall architecture as a full build.
        # startnet -> wpeinit -> WinPE-Startnet.cmd -> TechInstall.cmd -> disksetup.cmd + DISM apply + bcdboot + shutdown.
        New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Policy'), (Join-Path $overlayCache 'FirstBase\Deploy'), (Join-Path $overlayCache 'FirstBase\WUPayload\Tools') | Out-Null
        # Prefer autounattend-install.xml (no SetupComplete.cmd RunSynchronous) over the full version.
        $autounattendInstallSrc = Join-Path $ContentRoot 'Policy\autounattend-install.xml'
        $autounattendSrc = if (Test-Path -LiteralPath $autounattendInstallSrc) { $autounattendInstallSrc } else { Join-Path $ContentRoot 'Policy\autounattend.xml' }
        if (Test-Path -LiteralPath $autounattendSrc) {
            Copy-Item -LiteralPath $autounattendSrc -Destination (Join-Path $overlayCache 'FirstBase\Autounattend.xml') -Force
            Copy-Item -LiteralPath $autounattendSrc -Destination (Join-Path $overlayCache 'FirstBase\Policy\Autounattend.xml') -Force
        }
        # TechInstall-Install.cmd: stripped deploy script (no WU payload staging).
        $techInstallInstallSrc = Join-Path $ContentRoot 'Deploy\TechInstall-Install.cmd'
        if (Test-Path -LiteralPath $techInstallInstallSrc) {
            Copy-Item -LiteralPath $techInstallInstallSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\TechInstall.cmd') -Force
        }
        # WinPE-Startnet.cmd: WinPE bootstrap that finds and calls FirstBase\Deploy\TechInstall.cmd on the data partition.
        $winpeStartnetSrc = Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd'
        if (Test-Path -LiteralPath $winpeStartnetSrc) {
            Copy-Item -LiteralPath $winpeStartnetSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\WinPE-Startnet.cmd') -Force
        }
        # Show-DeployBanner.ps1: PowerShell-rendered animated WinPE title banner.
        $bannerSrc = Join-Path $ContentRoot 'Deploy\Show-DeployBanner.ps1'
        if (Test-Path -LiteralPath $bannerSrc) {
            Copy-Item -LiteralPath $bannerSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\Show-DeployBanner.ps1') -Force
        }
        # Invoke-FbDeployUi.ps1: the PowerShell deploy screen that TechInstall*.cmd
        # repaints at every step. Without it the deploy falls back to the plain
        # echo progress bar, so it must ship alongside the banner.
        $deployUiSrc = Join-Path $ContentRoot 'Deploy\Invoke-FbDeployUi.ps1'
        if (Test-Path -LiteralPath $deployUiSrc) {
            Copy-Item -LiteralPath $deployUiSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\Invoke-FbDeployUi.ps1') -Force
        }
        $earlyUiSrc = Join-Path $ContentRoot 'Deploy\Launch-FbWinPeUiEarly.cmd'
        if (Test-Path -LiteralPath $earlyUiSrc) {
            Copy-Item -LiteralPath $earlyUiSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\Launch-FbWinPeUiEarly.cmd') -Force
        }
        # FirstBaseBuildIdentity.ps1: the shared dev/release resolver. The banner
        # and the deploy screen both dot-source it from Deploy\, and default to
        # release without it, so it has to land beside them.
        $identitySrc = Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1'
        if (Test-Path -LiteralPath $identitySrc) {
            Copy-Item -LiteralPath $identitySrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\FirstBaseBuildIdentity.ps1') -Force
        }
        # disksetup.cmd: diskpart script that creates ESP + Windows partitions on the target disk.
        $disksetupSrc = Join-Path $ContentRoot 'Deploy\disksetup.cmd'
        if (Test-Path -LiteralPath $disksetupSrc) {
            Copy-Item -LiteralPath $disksetupSrc -Destination (Join-Path $overlayCache 'FirstBase\Deploy\disksetup.cmd') -Force
        }
        # Invoke-FirstBaseDismApply.ps1: PowerShell DISM apply UI (live progress) for the QuickInstall console.
        $dismApplySrc = Join-Path $ContentRoot 'Scripts\Invoke-FirstBaseDismApply.ps1'
        if (Test-Path -LiteralPath $dismApplySrc) {
            New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Scripts') | Out-Null
            Copy-Item -LiteralPath $dismApplySrc -Destination (Join-Path $overlayCache 'FirstBase\Scripts\Invoke-FirstBaseDismApply.ps1') -Force
        }
        $bloatSrc = Join-Path $ContentRoot 'Scripts\Remove-FbProvisionedBloat.ps1'
        if (Test-Path -LiteralPath $bloatSrc) {
            New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Scripts') | Out-Null
            Copy-Item -LiteralPath $bloatSrc -Destination (Join-Path $overlayCache 'FirstBase\Scripts\Remove-FbProvisionedBloat.ps1') -Force
        }
        $layoutSrc = Join-Path $ContentRoot 'Scripts\LayoutModification.json'
        if (Test-Path -LiteralPath $layoutSrc) {
            New-Item -ItemType Directory -Force -Path (Join-Path $overlayCache 'FirstBase\Scripts') | Out-Null
            Copy-Item -LiteralPath $layoutSrc -Destination (Join-Path $overlayCache 'FirstBase\Scripts\LayoutModification.json') -Force
        }
        # fb-im front-end: cmd launcher stays at volume ROOT; PS backend + fb-dump backend under FirstBase\WUPayload\Tools\.
        $imCmdSrc = Join-Path $ContentRoot 'Tools\fb-im.cmd'
        if (Test-Path -LiteralPath $imCmdSrc) {
            Copy-Item -LiteralPath $imCmdSrc -Destination (Join-Path $overlayCache 'fb-im.cmd') -Force
        }
        $imPs1Src = Join-Path $ContentRoot 'Tools\fb-im.ps1'
        if (Test-Path -LiteralPath $imPs1Src) {
            Copy-Item -LiteralPath $imPs1Src -Destination (Join-Path $overlayCache 'FirstBase\WUPayload\Tools\fb-im.ps1') -Force
        }
        $dumpPs1Src = Join-Path $ContentRoot 'Tools\fb-dump.ps1'
        if (Test-Path -LiteralPath $dumpPs1Src) {
            Copy-Item -LiteralPath $dumpPs1Src -Destination (Join-Path $overlayCache 'FirstBase\WUPayload\Tools\fb-dump.ps1') -Force
        }
        $icoSrc = Join-Path $ContentRoot 'FirstBase.ico'
        if (Test-Path -LiteralPath $icoSrc) {
            Copy-Item -LiteralPath $icoSrc -Destination (Join-Path $overlayCache 'FirstBase\FirstBase.ico') -Force
        }
        Copy-LwPeBrailleFont -OverlayRoot $overlayCache
        Copy-LwWinPeUiOverlay -OverlayRoot $overlayCache
    }
}

# Build-OverlayCache removed (5.2.88): USB-bound overlay copies ContentRoot → USB
# directly in the per-disk worker. EspCache (Build-Cache / Build-IsoCache) remains
# only for non-ISO staged-WIM boot.wim template injection.

# --- DISM WIM mount-race helpers ---------------------------------------------
# DISM allows only ONE read-write mount per WIM file at a time - mounting index 2
# while index 1 (or a leftover mount from an earlier crashed build) is still
# registered against the same boot.wim fails with 0xc1420127 ("The specified
# image in the specified wim is already mounted for read/write access"). This
# can happen even when index 1's own /Unmount-Image /Commit reported success,
# because the WIMMount filter driver can release its lock on the file slightly
# after DISM's exit code comes back. Test-WimMounted is read-only (used to wait
# for a just-committed mount to actually clear); Clear-StaleWimMount is used
# defensively before every mount attempt to discard any mount - this run's or
# an older crashed run's - still registered against the WIM.
function Test-WimMounted {
    param([string] $WimPath)
    try {
        Import-Module -Name Dism -ErrorAction SilentlyContinue
        $fullWimPath = [System.IO.Path]::GetFullPath($WimPath)
        return @(Get-WindowsImage -Mounted -ErrorAction SilentlyContinue | Where-Object {
            $_.ImagePath -and ([System.IO.Path]::GetFullPath($_.ImagePath) -ieq $fullWimPath)
        })
    } catch {
        return @()
    }
}

function Clear-StaleWimMount {
    param([string] $WimPath)
    $stale = @(Test-WimMounted -WimPath $WimPath)
    foreach ($m in $stale) {
        & dism.exe /Unmount-Image /MountDir:"$($m.MountPath)" /Discard 2>&1 | Out-Null
    }
    if ($stale.Count -gt 0) {
        & dism.exe /Cleanup-Mountpoints 2>&1 | Out-Null
    }
    return $stale.Count
}

# Add-LwArm64DriversToMountedImage lives in lib\Add-LwArm64Drivers.ps1.
# It recurse-injects the WinPE-Drivers tree into a mounted image.

# --- Inject WinPE-Startnet.cmd into boot.wim in the ESP cache ----------------
# Mounts boot.wim index 1 offline with DISM, replaces Windows\System32\startnet.cmd
# with our custom launcher (WinPE-Startnet.cmd), then commits and dismounts.
# Called once after Build-Cache / Build-IsoCache so every USB written from this
# cache gets a boot.wim that auto-launches TechInstall.cmd on WinPE start.
# Non-fatal: emits a warning and continues if DISM fails so the build does not
# abort - the USB will boot to a WinPE prompt instead of auto-launching.
function Invoke-StartnetInjection {
    param(
        [string] $BootWimPath,       # espCache\sources\boot.wim
        [string] $StartnetCmdPath,   # payload\Deploy\WinPE-Startnet.cmd
        [string] $WpeOcPath = '',    # Images\FB Image Creation\WinPE-OCs\<ARCH>\ (adds PS to WinPE)
        # ARM64 only. Empty on AMD64. Recurse-injected into boot.wim indexes 1 and 2.
        [string] $Arm64UsbDriverDir = '',
        # Arch-matched self-contained publish dir (…\Deploy\WinPeUi\AMD64 or ARM64).
        [string] $WinPeUiSrcDir = ''
    )

    if (-not (Test-Path -LiteralPath $BootWimPath)) {
        EmitLog -Disk 0 -Msg "startnet inject: boot.wim not found at '$BootWimPath' - WinPE will NOT auto-launch TechInstall.cmd"
        return
    }
    if (-not (Test-Path -LiteralPath $StartnetCmdPath)) {
        EmitLog -Disk 0 -Msg "startnet inject: WinPE-Startnet.cmd not found at '$StartnetCmdPath' - WinPE will NOT auto-launch TechInstall.cmd"
        return
    }

    # FAIL LOUD: WinPE PowerShell is mandatory for LoneWolf (TechInstall depends on it).
    # WinPE PowerShell has a strict dependency chain and a language requirement: each
    # base cab MUST be paired with its matching en-us LANGUAGE cab. Adding
    # WinPE-PowerShell.cab without WinPE-NetFx_en-us.cab / WinPE-PowerShell_en-us.cab
    # produces a WinPE where powershell.exe exists on disk but cannot actually start
    # (missing .NET / language resources) - which is exactly the "PowerShell absent on
    # the booted stick" symptom. So the FULL 8-cab set (base + _en-us) is REQUIRED on
    # the share and verified BEFORE mounting anything, so a missing dependency aborts
    # the whole build (naming the exact files) instead of silently shipping a
    # PowerShell-less / broken-PowerShell WinPE (root cause of the re-image loop).
    $requiredOc = @(
        'WinPE-WMI.cab',        'WinPE-WMI_en-us.cab',
        'WinPE-NetFx.cab',      'WinPE-NetFx_en-us.cab',
        'WinPE-Scripting.cab',  'WinPE-Scripting_en-us.cab',
        'WinPE-PowerShell.cab', 'WinPE-PowerShell_en-us.cab')
    if ([string]::IsNullOrWhiteSpace($WpeOcPath) -or -not (Test-Path -LiteralPath $WpeOcPath)) {
        throw "FATAL: WinPE OC folder not found at '$WpeOcPath'. LoneWolf requires the WinPE optional-component cabs in the per-architecture subfolder (WinPE-WMI/NetFx/Scripting/PowerShell plus their _en-us language cabs). Stage them under '$WpeOcPath'."
    }
    # Accept either a flat WinPE-OCs\ layout or one where the _en-us cabs live in an
    # en-us\ subfolder (both are valid ADK layouts).
    $missingOc = @($requiredOc | Where-Object {
        -not (Test-Path -LiteralPath (Join-Path $WpeOcPath $_)) -and
        -not (Test-Path -LiteralPath (Join-Path (Join-Path $WpeOcPath 'en-us') $_))
    })
    if ($missingOc.Count -gt 0) {
        throw ("FATAL: Required WinPE OC cab(s) missing in '$WpeOcPath': " + ($missingOc -join ', ') +
               ". WinPE PowerShell needs the base cabs AND their matching en-us language cabs. OPERATOR ACTION: copy the missing file(s) into the arch subfolder '$WpeOcPath' then re-run a Full Rebuild. LoneWolf will not ship a stick without a working PowerShell.")
    }
    EmitLog -Disk 0 -Msg "startnet inject: WinPE OCs verified present at '$WpeOcPath' (full base + en-us set: $($requiredOc -join ', '))"

    # boot.wim copied from a network share often has the ReadOnly attribute set.
    # DISM /Commit must write back to the WIM file - it fails on a read-only file.
    # Clear the attribute unconditionally before mounting.
    try {
        Set-ItemProperty -LiteralPath $BootWimPath -Name IsReadOnly -Value $false -ErrorAction Stop
    } catch {
        EmitLog -Disk 0 -Msg "startnet inject: WARNING - could not clear ReadOnly on boot.wim: $($_.Exception.Message)"
    }

    # Patch both index 1 and index 2 - the Windows BCD boots from index 2 (Windows Setup
    # WinPE image) on standard ISOs, while index 1 is the minimal PE used internally by
    # Windows Setup itself. Leaving index 2 unpatched means setup.exe still launches from
    # the stock winpeshl.ini [LaunchApps] entry, causing the language-selection screen.
    foreach ($wimIndex in 1, 2) {
        $mountDir  = Join-Path $env:TEMP ("LWMount_" + [guid]::NewGuid().ToString('N').Substring(0, 8))
        $isMounted = $false
        $_winjBase      = if ($wimIndex -eq 1) { 0 } else { 50 }
        $_winjInitPct   = if ($wimIndex -eq 1) { 5 } else { 52 }
        $_winjCommitPct = if ($wimIndex -eq 1) { 50 } else { 95 }
        $_winjOcStep    = 0
        try {
            New-Item -ItemType Directory -Force -Path $mountDir | Out-Null
            EmitProgress -Disk 0 -Phase 'winpe-inject' -Pct $_winjInitPct
            EmitLog -Disk 0 -Msg "startnet inject: mounting boot.wim index $wimIndex at $mountDir ..."

            # Defensively discard any mount already registered against this boot.wim
            # (this run's or a leftover from an earlier crashed build) before mounting -
            # DISM permits only one read-write mount per WIM file.
            Clear-StaleWimMount -WimPath $BootWimPath | Out-Null

            # Use /Mount-Image (/ImageFile:) - the modern non-deprecated DISM syntax.
            # The old /Mount-Wim /WimFile: variant is rejected on some Windows 11 builds.
            # Retry with backoff: mounting a different index of the same WIM right after
            # another index was unmounted can transiently fail with 0xc1420127 ("already
            # mounted for read/write access") if DISM's mount registry has not caught up.
            $__mountAttempt = 0
            $__mountMax     = 3
            do {
                $__mountAttempt++
                $mountOut = & dism.exe /Mount-Image /ImageFile:"$BootWimPath" /Index:$wimIndex /MountDir:"$mountDir" 2>&1
                if ($LASTEXITCODE -eq 0) { break }
                if ($__mountAttempt -ge $__mountMax) {
                    throw "DISM /Mount-Image (index $wimIndex) failed (exit $LASTEXITCODE): $($mountOut -join ' | ')"
                }
                EmitLog -Disk 0 -Msg "startnet inject: /Mount-Image (index $wimIndex) attempt $__mountAttempt failed (exit $LASTEXITCODE) - clearing stale mounts and retrying in 2s ..."
                Clear-StaleWimMount -WimPath $BootWimPath | Out-Null
                Start-Sleep -Seconds 2
            } while ($__mountAttempt -lt $__mountMax)
            $isMounted = $true

            $sysDir = Join-Path $mountDir 'Windows\System32'
            if (-not (Test-Path -LiteralPath $sysDir)) {
                throw "Windows\System32 not found in mounted boot.wim index $wimIndex (unexpected WIM structure)"
            }

            $targetFile = Join-Path $sysDir 'startnet.cmd'
            Copy-Item -LiteralPath $StartnetCmdPath -Destination $targetFile -Force
            EmitLog -Disk 0 -Msg "startnet inject: startnet.cmd written (index $wimIndex) ..."

            # Inject the UEFI pre-flight helper alongside startnet.cmd (mirrors Build-UsbStick.ps1
            # Invoke-TiPatchBootWim). startnet.cmd looks for it at X:\Windows\System32\Invoke-FbUefiPreflight.ps1;
            # without this copy the pre-flight (Secure Boot / RAID) check is silently skipped at boot.
            $pnpSrc = Join-Path (Split-Path -Parent $StartnetCmdPath) 'Get-FbUsbPnp.ps1'
            if (Test-Path -LiteralPath $pnpSrc) {
                Copy-Item -LiteralPath $pnpSrc -Destination (Join-Path $sysDir 'Get-FbUsbPnp.ps1') -Force
                EmitLog -Disk 0 -Msg "startnet inject: Get-FbUsbPnp.ps1 written (index $wimIndex) ..."
            }
            $preflightSrc = Join-Path (Split-Path -Parent $StartnetCmdPath) 'Invoke-FbUefiPreflight.ps1'
            if (Test-Path -LiteralPath $preflightSrc) {
                Copy-Item -LiteralPath $preflightSrc -Destination (Join-Path $sysDir 'Invoke-FbUefiPreflight.ps1') -Force
                EmitLog -Disk 0 -Msg "startnet inject: Invoke-FbUefiPreflight.ps1 written (index $wimIndex) ..."
            } else {
                EmitLog -Disk 0 -Msg "startnet inject: Invoke-FbUefiPreflight.ps1 not found at '$preflightSrc' (index $wimIndex) - preflight will be skipped at boot"
            }

            # Replace winpeshl.ini to prevent setup.exe from launching alongside startnet.cmd.
            # The stock boot.wim winpeshl.ini has a [LaunchApps] entry pointing to \sources\setup.exe
            # which causes the Windows language-selection UI. Explicitly listing startnet.cmd in
            # [LaunchApps] (matching the reference builder) ensures it runs and setup.exe does not.
            $winpeshlPath = Join-Path $sysDir 'winpeshl.ini'
            Set-ItemProperty -LiteralPath $winpeshlPath -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
            [System.IO.File]::WriteAllText($winpeshlPath, "[LaunchApps]`r`ncmd.exe, /k X:\Windows\System32\startnet.cmd`r`n", [System.Text.Encoding]::ASCII)
            EmitLog -Disk 0 -Msg "startnet inject: winpeshl.ini set to launch startnet.cmd (index $wimIndex, setup.exe suppressed) ..."

            # WinPE PowerShell optional components, added in STRICT dependency order:
            # each base cab immediately followed by its en-us language cab, WMI -> NetFx
            # -> Scripting -> PowerShell. The pre-mount guard already verified all 8 cabs
            # exist, so ANY /Add-Package failure (base OR language) is FATAL (throws ->
            # build aborts) - a partial add produces a non-functional PowerShell. Each
            # cab's exit code is checked individually and logged per-cab.
            foreach ($oc in @(
                @{ base = 'WinPE-WMI.cab';        lang = 'WinPE-WMI_en-us.cab' },
                @{ base = 'WinPE-NetFx.cab';      lang = 'WinPE-NetFx_en-us.cab' },
                @{ base = 'WinPE-Scripting.cab';  lang = 'WinPE-Scripting_en-us.cab' },
                @{ base = 'WinPE-PowerShell.cab'; lang = 'WinPE-PowerShell_en-us.cab' })) {
                foreach ($cabName in @($oc.base, $oc.lang)) {
                    $cabPath = Join-Path $WpeOcPath $cabName
                    if (-not (Test-Path -LiteralPath $cabPath)) { $cabPath = Join-Path (Join-Path $WpeOcPath 'en-us') $cabName }
                    EmitLog -Disk 0 -Msg "startnet inject: adding $cabName to boot.wim index $wimIndex from '$cabPath' ..."
                    # Do not pipe DISM to Out-Null — that can clobber $LASTEXITCODE on Windows PowerShell 5.1.
                    $addOut = & dism.exe /Image:"$mountDir" /Add-Package /PackagePath:"$cabPath" 2>&1
                    $addCode = $LASTEXITCODE
                    if ($addCode -ne 0) {
                        $addText = (($addOut | ForEach-Object { "$_" }) -join ' | ')
                        # Newer boot.wim indexes often already include NetFx/PowerShell.
                        if ($addText -match '(?i)already (installed|present)|0x800f080c|not applicable|0x800f081e|0x800f0816') {
                            EmitLog -Disk 0 -Msg "startnet inject: $cabName already present or not applicable on index $wimIndex (DISM $addCode) - continuing"
                        } else {
                            throw "FATAL: WinPE OC $cabName /Add-Package failed (exit $addCode) on boot.wim index $wimIndex (OC root '$WpeOcPath'): $addText"
                        }
                    } else {
                        EmitLog -Disk 0 -Msg "startnet inject: $cabName added OK (index $wimIndex)"
                    }
                }
                $_winjOcStep += 10
                EmitProgress -Disk 0 -Phase 'winpe-inject' -Pct ($_winjBase + $_winjOcStep)
            }

            # Verify PowerShell actually landed in the image before committing.
            $peShellPath = Join-Path $mountDir 'Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
            if (-not (Test-Path -LiteralPath $peShellPath)) {
                throw "FATAL: powershell.exe NOT present in boot.wim index $wimIndex after adding WinPE OCs - refusing to ship a PowerShell-less WinPE"
            }
            EmitLog -Disk 0 -Msg "startnet inject: PowerShell verified present in WinPE (index $wimIndex)"

            $peFontsDir = Join-Path $mountDir 'Windows\Fonts'
            Copy-LwPeBrailleFont -WimFontsDir $peFontsDir

            $null = Copy-LwWinPeUiIntoBootMount -MountDir $mountDir -WinPeUiSrcDir $WinPeUiSrcDir -Log {
                param($m)
                EmitLog -Disk 0 -Msg ("startnet inject: {0}" -f $m)
            }

            if (-not [string]::IsNullOrWhiteSpace($Arm64UsbDriverDir)) {
                EmitLog -Disk 0 -Msg "startnet inject: adding ARM64 drivers to boot.wim index $wimIndex from $Arm64UsbDriverDir"
                Add-LwArm64DriversToMountedImage -MountDir $mountDir -DriverRoot $Arm64UsbDriverDir -Log {
                    param($m)
                    EmitLog -Disk 0 -Msg $m
                } -Progress {
                    param($p)
                    $lo = $_winjBase + 40
                    $hi = [math]::Max($lo, $_winjCommitPct - 1)
                    EmitProgress -Disk 0 -Phase 'winpe-inject' -Pct ($lo + [int](($hi - $lo) * ([math]::Min(100, $p) / 100.0)))
                }
            }

            EmitLog -Disk 0 -Msg "startnet inject: committing boot.wim index $wimIndex ..."
            $unmountOut = & dism.exe /Unmount-Image /MountDir:"$mountDir" /Commit 2>&1
            if ($LASTEXITCODE -ne 0) {
                # Do NOT clear $isMounted here - the finally block must still discard
                # the live mount so DISM does not leave a stale registry entry.
                throw "DISM /Unmount-Image /Commit (index $wimIndex) failed (exit $LASTEXITCODE): $($unmountOut -join ' | ')"
            }
            $isMounted = $false
            # /Unmount-Image can report success before the WIMMount filter driver has
            # actually released its lock on the file. Poll (read-only, up to ~5s) so the
            # next index's /Mount-Image does not race the driver and fail with 0xc1420127.
            $__unmountWaitTries = 0
            while ($__unmountWaitTries -lt 10 -and (Test-WimMounted -WimPath $BootWimPath).Count -gt 0) {
                Start-Sleep -Milliseconds 500
                $__unmountWaitTries++
            }
            EmitLog -Disk 0 -Msg "startnet inject: committing boot.wim index $wimIndex complete - WinPE will auto-launch TechInstall.cmd"
            EmitProgress -Disk 0 -Phase 'winpe-inject' -Pct $_winjCommitPct

        } catch {
            $__ocMsg = $_.Exception.Message
            if ($__ocMsg -like 'FATAL:*') {
                # A mandatory dependency (WinPE OCs / PowerShell) failed. Discard the
                # live mount and propagate so the whole build aborts loudly instead of
                # producing a USB that boots a PowerShell-less WinPE.
                if ($isMounted) {
                    & dism.exe /Unmount-Image /MountDir:"$mountDir" /Discard 2>&1 | Out-Null
                    $isMounted = $false
                }
                Remove-Item -LiteralPath $mountDir -Recurse -Force -ErrorAction SilentlyContinue
                throw
            }
            EmitLog -Disk 0 -Msg "WARNING: startnet inject FAILED (index $wimIndex) - $__ocMsg"
            EmitLog -Disk 0 -Msg "WARNING: WinPE may NOT auto-launch TechInstall.cmd; USB boots to PE command prompt"
        } finally {
            if ($isMounted) {
                EmitLog -Disk 0 -Msg "startnet inject: discarding uncommitted WIM mount (index $wimIndex, cleanup) ..."
                & dism.exe /Unmount-Image /MountDir:"$mountDir" /Discard 2>&1 | Out-Null
            }
            Remove-Item -LiteralPath $mountDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

# --- Per-disk end-to-end worker (runs as background job) ----------------------
# Full pipeline per disk (true parallel across disks):
#   wipe/partition -> ESP copy -> DISM/data -> WinPE inject (this USB's boot.wim) ->
#   overlay / Autounattend -> BCD -> version stamp -> done
# Shared staging WIM / ISO mounts stay on the main thread (read-only); jobs only
# robocopy from them. WinPE DISM inject mounts only the per-USB ESP boot.wim.
# On failure: emits error + done(success=false), then throws (job state = Failed).
$workerDiskBlock = {
    param(
        [int]    $DiskNumber,
        [string] $EspCache,
        [string] $StagingWim,
        [long]   $EspPartitionBytes,
        [bool]   $OverlayOnly,
        [string] $DataVolumeLabel,
        # ISO-mode: when non-empty the build reads install.wim from the mounted ISO drive
        [string] $IsoDrive,
        [bool]   $NoPayload,
        # WIM-mode parallel: shared read-only mount dir prepared on the main thread.
        # When set, this job robocopies from it (no per-disk DISM /Mount-Image).
        [string] $SharedWimMount,
        [string] $OverlayCache,
        [string] $StartnetForInjection,
        [string] $WpeOcStaging,
        [string] $ContentRoot,
        [string] $WorkflowType,
        [string] $StagingVersion,
        # 'Single' (FAT32 Basic-Data, one volume, WIM-split) or 'Split' (FAT32 ESP + NTFS data)
        [string] $Layout,
        # QUICK-INSTALL minimal payload-free install (independent of $NoPayload).
        [bool]   $QuickInstall,
        # Full path to the shared split helper lib (lib\Split-LWImage.ps1). Dot-sourced
        # below so this job runspace gets Split-LWImageForFat32 (script-scope functions
        # are NOT visible inside a Start-Job runspace).
        [string] $SplitLibPath,
        # Pre-split fast-copy set dir for THIS build's ISO ('' when none/mismatch/corrupt).
        # Resolved ONCE on the main thread (Get-LWPreSplitSet). When non-empty the ISO-mode
        # Single branch robocopies the staged install*.swm instead of splitting on the fly.
        [string] $PreSplitSetDir,
        [bool]   $DevBuild,
        [string] $LauncherVersion,
        [string] $ScriptVersion,
        [string] $ShareLauncherVersion,
        [string] $ShareScriptVersion,
        [string] $ImageBuildDate,
        # PreSplit / Image Ready folder identity (e.g. 25h2-home-9-22-amd64-20261005T164435Z).
        [string] $ImageVersion,
        [string] $WindowsEdition,
        # Job runspaces cannot see script-scope Copy-LwRepoEdgeInstaller / $PSScriptRoot.
        # Resolved on the main thread (repo tools\ for destage, app-adjacent tools\ packaged).
        [string] $EdgeToolsDir,
        # Destage skip-WU (npm start:updatesfinished). Only honored when $DevBuild is true.
        [bool]   $DestageSkipWu,
        # ARM64 driver folder. Empty on AMD64 and on overlay-only.
        [string] $Arm64UsbDriverDir,
        [string] $Arm64DriverLibPath,
        # Folder of ARM64-driver install.wim or install*.swm. Empty on AMD64.
        [string] $Arm64InstallImageDir,
        # lib\LwUsbOverlay.ps1. Start-Job cannot see parent functions.
        [string] $UsbOverlayLibPath,
        # googleDrive: BootInject\sources when sentinel matches (ISO-mode ESP boot.wim source).
        [string] $BootInjectSourcesDir,
        [bool]   $DriveHttpDirect,
        [string] $DriveHttpFolderId,
        [string] $DriveHttpLibPath,
        # Main-thread Ensure-LwWinPeUiForBuild cache (…\AMD64, …\ARM64). Empty = ContentRoot only.
        [string] $WinPeUiCacheRoot,
        [string] $LcuLibPath,
        [string] $LcuRefreshSetDir,
        [string] $InstallLcuKb,
        [string] $OsBuild,
        [string] $LcuImageVersion,
        [string] $LcuImageBuildDate
    )

    $ErrorActionPreference = 'Stop'
    $lcuDidRefresh = $false
    $refreshedLcuKb = ''
    $refreshedOsBuild = ''
    $refreshedImageVersion = ''
    $refreshedImageDate = ''

    # Dot-source the shared split helper into THIS job runspace (see $SplitLibPath note).
    # The on-the-fly fallback split (Split-LWImageForFat32) and the producer both use this
    # exact file, so a build's fallback output is byte-identical to a staged set.
    if (-not [string]::IsNullOrWhiteSpace($SplitLibPath) -and (Test-Path -LiteralPath $SplitLibPath)) {
        . $SplitLibPath
    }
    if (-not [string]::IsNullOrWhiteSpace($Arm64DriverLibPath) -and (Test-Path -LiteralPath $Arm64DriverLibPath)) {
        . $Arm64DriverLibPath
    }
    if (-not [string]::IsNullOrWhiteSpace($LcuLibPath) -and (Test-Path -LiteralPath $LcuLibPath)) {
        . $LcuLibPath
    }
    if (-not [string]::IsNullOrWhiteSpace($UsbOverlayLibPath) -and (Test-Path -LiteralPath $UsbOverlayLibPath)) {
        . $UsbOverlayLibPath
    }
    # Snapdragon Windows Updates and Snapdragon Quick Install only.
    # A driver path passed into an Intel/AMD job is ignored.
    $snapdragonWorkflow = $false
    if (Get-Command -Name Test-LwSnapdragonWorkflow -ErrorAction SilentlyContinue) {
        $snapdragonWorkflow = [bool](Test-LwSnapdragonWorkflow -WorkflowType $WorkflowType)
    }
    if (-not $snapdragonWorkflow) {
        $Arm64UsbDriverDir = ''
        $Arm64InstallImageDir = ''
    }
    # Same gate as the main thread. Jobs cannot see the parent $stageWuPayload.
    $stageWuPayload = $false
    if (Get-Command -Name Test-LwStageWindowsUpdatePayload -ErrorAction SilentlyContinue) {
        $stageWuPayload = [bool](Test-LwStageWindowsUpdatePayload -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload ([bool]$NoPayload))
    }

    function Set-LwFat32BpbLabel {
        param([string]$DriveLetter, [string]$Label)
        # WinPE diskpart shows the 11-byte boot-sector label. Format-Volume writes
        # the root-directory label Windows shows and leaves this field as "NO NAME".
        $letter = ([string]$DriveLetter).Trim().TrimEnd(':')
        if (-not $letter) { return }
        $padded = (($Label.ToUpperInvariant()) + (' ' * 11)).Substring(0, 11)
        $lab = [System.Text.Encoding]::ASCII.GetBytes($padded)
        $fs = $null
        try {
            $fs = [System.IO.File]::Open("\\.\$letter`:", 'Open', 'ReadWrite', 'ReadWrite')
            $sector = New-Object byte[] 512
            if ($fs.Read($sector, 0, 512) -ne 512) { return }
            if ([BitConverter]::ToUInt16($sector, 510) -ne 0xAA55) { return }
            $bk = [BitConverter]::ToUInt16($sector, 50)
            [Array]::Copy($lab, 0, $sector, 71, 11)
            $fs.Position = 0
            $fs.Write($sector, 0, 512)
            if ($bk -gt 0 -and $bk -lt 64) {
                $bkBuf = New-Object byte[] 512
                $fs.Position = [int64]$bk * 512
                if ($fs.Read($bkBuf, 0, 512) -eq 512 -and [BitConverter]::ToUInt16($bkBuf, 510) -eq 0xAA55) {
                    [Array]::Copy($lab, 0, $bkBuf, 71, 11)
                    $fs.Position = [int64]$bk * 512
                    $fs.Write($bkBuf, 0, 512)
                }
            }
            $fs.Flush()
        } catch {
            J @{ event='log'; disk=$DiskNumber; message=("FAT32 boot-sector label stamp failed on {0}: {1}" -f $letter, $_.Exception.Message) }
        } finally {
            if ($fs) { $fs.Dispose() }
        }
    }
    function J {
        param([hashtable]$Data)
        $Data | ConvertTo-Json -Compress -Depth 3 | Write-Output
    }
    function JPhase   { param([string]$P) J @{ event='phase'; disk=$DiskNumber; phase=$P } }
    function JProgress{ param([string]$P, [int]$Pct) J @{ event='progress'; disk=$DiskNumber; phase=$P; pct=$Pct } }

    # Job runspaces cannot see script-scope Assert-LwUpdateLoopCopy. Size-only
    # check here; AST parse already ran on the main thread against ContentRoot.
    function Assert-LoopCopyLocal {
        param([string]$Src, [string]$Dst)
        if ([string]::IsNullOrWhiteSpace($Src) -or [string]::IsNullOrWhiteSpace($Dst)) { return }
        if (-not (Test-Path -LiteralPath $Dst)) {
            throw "FATAL: Invoke-WindowsUpdateLoop.ps1 missing after overlay copy: '$Dst'"
        }
        $srcLen = [int64](Get-Item -LiteralPath $Src).Length
        $dstLen = [int64](Get-Item -LiteralPath $Dst).Length
        if ($srcLen -ne $dstLen) {
            throw ("FATAL: Invoke-WindowsUpdateLoop.ps1 truncated during overlay copy ({0} -> {1} bytes): '{2}'." -f $srcLen, $dstLen, $Dst)
        }
        if ($dstLen -lt 900000) {
            throw ("FATAL: Invoke-WindowsUpdateLoop.ps1 on stick is truncated ({0} bytes): '{1}'." -f $dstLen, $Dst)
        }
    }

    # Job runspaces cannot see script-scope Copy-LwRepoEdgeInstaller on the parent.
    function Copy-LwRepoEdgeInstaller {
        param([Parameter(Mandatory)][string]$DestRoot)
        try {
            $toolsDir = $EdgeToolsDir
            if ([string]::IsNullOrWhiteSpace($toolsDir) -and $ContentRoot) {
                $toolsDir = Join-Path ([IO.Path]::GetFullPath((Join-Path $ContentRoot '..\..'))) 'tools'
            }
            if ([string]::IsNullOrWhiteSpace($toolsDir) -or -not (Test-Path -LiteralPath $toolsDir)) { return }
            $files = @(Get-ChildItem -LiteralPath $toolsDir -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -match '\.(exe|msi)$' -and $_.Name -match '(?i)edge' })
            if ($files.Count -eq 0) { return }
            $edgeRoot = Join-Path $DestRoot 'FirstBase\WUPayload\Edge'
            $archDirs = @(
                $edgeRoot
                (Join-Path $edgeRoot 'AMD64')
                (Join-Path $edgeRoot 'ARM64')
            )
            foreach ($d in $archDirs) {
                if (-not (Test-Path -LiteralPath $d)) {
                    New-Item -ItemType Directory -Force -Path $d | Out-Null
                }
            }
            foreach ($f in $files) {
                foreach ($d in $archDirs) {
                    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $d $f.Name) -Force -ErrorAction SilentlyContinue
                }
                J @{ event='log'; disk=$DiskNumber; message=("payload: staged local Edge installer {0} ({1} bytes) under FirstBase\WUPayload\Edge" -f $f.Name, $f.Length) }
            }
        } catch {
            J @{ event='log'; disk=$DiskNumber; message=("payload: Edge installer copy skipped: {0}" -f $_.Exception.Message) }
        }
    }

    # Job runspaces cannot see script-scope Copy-LwPeBrailleFont on the parent.
    function Copy-LwPeBrailleFont {
        param(
            [string]$OverlayRoot = '',
            [string]$WimFontsDir = ''
        )
        $srcList = New-Object System.Collections.Generic.List[string]
        if ($ContentRoot) {
            [void]$srcList.Add((Join-Path $ContentRoot 'Deploy\Fonts\cascadiamono.ttf'))
        }
        if ($env:WINDIR) {
            foreach ($n in @('cascadiamono.ttf', 'CascadiaMono.ttf', 'CascadiaMonoPL.ttf')) {
                [void]$srcList.Add((Join-Path $env:WINDIR ('Fonts\' + $n)))
            }
        }
        $src = $null
        foreach ($c in $srcList) {
            if ($c -and (Test-Path -LiteralPath $c)) { $src = $c; break }
        }
        if (-not $src) {
            J @{ event='log'; disk=$DiskNumber; message='WinPE Braille font: cascadiamono.ttf not found in payload Deploy\Fonts or Windows\Fonts (wolf may show as ?)' }
            return
        }
        if ($OverlayRoot) {
            $dstDir = Join-Path $OverlayRoot 'FirstBase\Deploy\Fonts'
            New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
            Copy-Item -LiteralPath $src -Destination (Join-Path $dstDir 'cascadiamono.ttf') -Force
            J @{ event='log'; disk=$DiskNumber; message=("WinPE Braille font staged to overlay: {0}" -f (Join-Path $dstDir 'cascadiamono.ttf')) }
        }
        if ($WimFontsDir) {
            New-Item -ItemType Directory -Force -Path $WimFontsDir | Out-Null
            Copy-Item -LiteralPath $src -Destination (Join-Path $WimFontsDir 'cascadiamono.ttf') -Force
            J @{ event='log'; disk=$DiskNumber; message=("WinPE Braille font staged into boot.wim Fonts: {0}" -f (Join-Path $WimFontsDir 'cascadiamono.ttf')) }
        }
    }

    function Copy-LwWinPeUiOverlay {
        param([string]$OverlayRoot = '')
        if (-not $OverlayRoot) { return }
        foreach ($arch in @('AMD64', 'ARM64')) {
            $src = ''
            if ($WinPeUiCacheRoot) {
                $cand = Join-Path $WinPeUiCacheRoot $arch
                if (Test-Path -LiteralPath (Join-Path $cand 'LoneWolf.WinPeUi.exe')) { $src = $cand }
            }
            if (-not $src -and $ContentRoot) {
                $cand = Join-Path $ContentRoot ("Deploy\WinPeUi\{0}" -f $arch)
                if (Test-Path -LiteralPath (Join-Path $cand 'LoneWolf.WinPeUi.exe')) { $src = $cand }
            }
            if (-not $src) { continue }
            $dst = Join-Path $OverlayRoot ("FirstBase\Deploy\WinPeUi\{0}" -f $arch)
            New-Item -ItemType Directory -Force -Path $dst | Out-Null
            Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force -ErrorAction SilentlyContinue
            J @{ event='log'; disk=$DiskNumber; message=("WinPeUi staged: {0}" -f $dst) }
        }
    }

    function Reset-LwUsbLogFolder {
        param([string]$VolRoot, [switch]$ClearContents)
        if ([string]::IsNullOrWhiteSpace($VolRoot)) { return }
        $vol = $VolRoot.TrimEnd('\') + '\'
        $logDir = Join-Path $vol 'FirstBase-Logs'
        if ($ClearContents -and (Test-Path -LiteralPath $logDir)) {
            & attrib.exe -H -S -R $logDir 2>&1 | Out-Null
            Get-ChildItem -LiteralPath $logDir -Force -ErrorAction SilentlyContinue |
                Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        }
        if (-not (Test-Path -LiteralPath $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }
        & attrib.exe -H -S $logDir 2>&1 | Out-Null
    }

    function Write-LwUsbExplorerChrome {
        param([string]$VolRoot, [string]$IcoSrc)
        if ([string]::IsNullOrWhiteSpace($VolRoot)) { return }
        $vol = $VolRoot.TrimEnd('\') + '\'
        $infPath = Join-Path $vol 'autorun.inf'
        $fbDir = Join-Path $vol 'FirstBase'
        $icoPath = Join-Path $fbDir 'FirstBase.ico'
        $rootIco = Join-Path $vol 'FirstBase.ico'
        # Leftover from older sticks that placed FirstBase.ico at volume root.
        if (Test-Path -LiteralPath $rootIco) {
            & attrib.exe -H -S -R $rootIco 2>&1 | Out-Null
            Remove-Item -LiteralPath $rootIco -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path -LiteralPath $infPath) {
            & attrib.exe -H -S -R $infPath 2>&1 | Out-Null
        }
        if (-not (Test-Path -LiteralPath $fbDir)) {
            New-Item -ItemType Directory -Path $fbDir -Force | Out-Null
        }
        if (Test-Path -LiteralPath $icoPath) {
            & attrib.exe -H -S -R $icoPath 2>&1 | Out-Null
        }
        if (-not [string]::IsNullOrWhiteSpace($IcoSrc) -and (Test-Path -LiteralPath $IcoSrc)) {
            Copy-Item -LiteralPath $IcoSrc -Destination $icoPath -Force
        }
        # Icon + no AutoRun execute verbs. ASCII/CRLF. Do not fight the volume label.
        # autorun.inf must stay at volume root; the ico lives under FirstBase\.
        [System.IO.File]::WriteAllText($infPath, "[autorun]`r`nicon=FirstBase\FirstBase.ico`r`n", [System.Text.Encoding]::ASCII)
        if (Test-Path -LiteralPath $fbDir) {
            & attrib.exe +H +S $fbDir /D 2>&1 | Out-Null
        }
        if (Test-Path -LiteralPath $infPath) {
            & attrib.exe +H +S $infPath 2>&1 | Out-Null
        }
        $im = Join-Path $vol 'fb-im.cmd'
        if (Test-Path -LiteralPath $im) {
            & attrib.exe -H -S $im 2>&1 | Out-Null
        }
        $logDir = Join-Path $vol 'FirstBase-Logs'
        if (-not (Test-Path -LiteralPath $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }
        & attrib.exe -H -S $logDir 2>&1 | Out-Null
    }

    # Human-facing workflow label for log/throw messages. The ISO-mode direct-from-ISO boot
    # copy path is SHARED by LoneWolf / WIN-INSTALL / QUICK-INSTALL, so messages must reflect
    # the ACTUAL workflow instead of hardcoding 'WIN-INSTALL'.
    $wfLabel = if ($QuickInstall) { 'QUICK-INSTALL' } elseif ($NoPayload) { 'WIN-INSTALL' } else { 'LoneWolf' }

    # Job runspaces cannot see script-scope Get-LwRemovableBootEfiName / Repair-LwEspBootLoaders.
    function Get-LwRemovableBootEfiName {
        param([string]$WorkflowType)
        if ([string]$WorkflowType -match 'ARM') { return 'bootaa64.efi' }
        return 'bootx64.efi'
    }
    function Get-LwEfiArchTag {
        param([string]$WorkflowType)
        if ([string]$WorkflowType -match 'ARM') { return 'ARM64' }
        return 'AMD64'
    }
    function Get-LwEfiFolderListing {
        param([string]$Dir)
        if (-not (Test-Path -LiteralPath $Dir)) { return '(missing)' }
        $names = @(Get-ChildItem -LiteralPath $Dir -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
        if ($names.Count -eq 0) { return '(empty)' }
        return ($names -join ', ')
    }
    function Repair-LwEspBootLoaders {
        param([string]$EspRoot, [string]$WorkflowType)
        $efiName = Get-LwRemovableBootEfiName -WorkflowType $WorkflowType
        $bootmgfw = Join-Path $EspRoot 'efi\microsoft\boot\bootmgfw.efi'
        $removable = Join-Path $EspRoot ('efi\boot\' + $efiName)
        $synthFrom = $null
        if (-not (Test-Path -LiteralPath $bootmgfw) -and (Test-Path -LiteralPath $removable)) {
            New-Item -ItemType Directory -Force -Path (Split-Path $bootmgfw -Parent) -ErrorAction SilentlyContinue | Out-Null
            Copy-Item -LiteralPath $removable -Destination $bootmgfw -Force
            $synthFrom = $efiName
        }
        if (-not (Test-Path -LiteralPath $removable) -and (Test-Path -LiteralPath $bootmgfw)) {
            New-Item -ItemType Directory -Force -Path (Split-Path $removable -Parent) -ErrorAction SilentlyContinue | Out-Null
            Copy-Item -LiteralPath $bootmgfw -Destination $removable -Force
        }
        return $synthFrom
    }
    function Get-LwEspBootmgfwMissingMessage {
        param(
            [string]$Prefix,
            [string]$EspRoot,
            [string]$WorkflowType,
            [string]$IsoHint = ''
        )
        $arch = Get-LwEfiArchTag -WorkflowType $WorkflowType
        $efiName = Get-LwRemovableBootEfiName -WorkflowType $WorkflowType
        $isoBit = ''
        if (-not [string]::IsNullOrWhiteSpace($IsoHint)) { $isoBit = " ISO='$IsoHint'." }
        $espBoot = Get-LwEfiFolderListing -Dir (Join-Path $EspRoot 'efi\boot')
        $espMs = Get-LwEfiFolderListing -Dir (Join-Path $EspRoot 'efi\microsoft\boot')
        $isoExtra = ''
        if (-not [string]::IsNullOrWhiteSpace($IsoHint)) {
            $isoBoot = Get-LwEfiFolderListing -Dir (Join-Path $IsoHint 'efi\boot')
            $isoMs = Get-LwEfiFolderListing -Dir (Join-Path $IsoHint 'efi\microsoft\boot')
            $isoExtra = " ISO efi\boot: $isoBoot; ISO efi\microsoft\boot: $isoMs."
        }
        return ("{0} ({1}): efi\microsoft\boot\bootmgfw.efi missing and efi\boot\{2} unavailable to synthesise it.{3} ESP efi\boot: {4}; ESP efi\microsoft\boot: {5}.{6}" -f $Prefix, $arch, $efiName, $isoBit, $espBoot, $espMs, $isoExtra)
    }

    # DISM allows only ONE read-write mount per WIM file at a time. This job runspace
    # cannot call script-scope functions, so duplicate the mount-race helpers locally
    # (see Test-WimMounted / Clear-StaleWimMount at script scope for the full rationale).
    function Test-WimMountedLocal {
        param([string]$WimPath)
        try {
            Import-Module -Name Dism -ErrorAction SilentlyContinue
            $fullWimPath = [System.IO.Path]::GetFullPath($WimPath)
            return @(Get-WindowsImage -Mounted -ErrorAction SilentlyContinue | Where-Object {
                $_.ImagePath -and ([System.IO.Path]::GetFullPath($_.ImagePath) -ieq $fullWimPath)
            })
        } catch {
            return @()
        }
    }
    function Clear-StaleWimMountLocal {
        param([string]$WimPath)
        $stale = @(Test-WimMountedLocal -WimPath $WimPath)
        foreach ($m in $stale) {
            & dism.exe /Unmount-Image /MountDir:"$($m.MountPath)" /Discard 2>&1 | Out-Null
        }
        if ($stale.Count -gt 0) {
            & dism.exe /Cleanup-Mountpoints 2>&1 | Out-Null
        }
        return $stale.Count
    }

    # Single layout only: install.wim is almost always > 4 GB and CANNOT live on FAT32.
    # The split body now lives in the SHARED helper lib (lib\Split-LWImage.ps1,
    # Split-LWImageForFat32), dot-sourced into this job runspace above. Both the
    # on-the-fly fallback below and the pre-split producer (Stage-PreSplitImage.ps1)
    # call that one function, so a build's fallback output is byte-identical to a
    # staged set (same Get-LWFat32SplitPlan span, same /CheckIntegrity, same
    # ESD-export path, same install*.swm naming). Images above 3800 MB keep
    # /FileSize:3800. Images from 512 MiB through that cap use a span just over
    # half the image so DISM writes at least two SWM chunks. The deploy side
    # (TechInstall.cmd / Invoke-FirstBaseDismApply.ps1) already applies from
    # install*.swm via SWMFile when install.wim is absent. An image under 512 MiB
    # is copied as one file.
    #
    # Thin local wrapper preserving the previous call-site signature (-Disk) while
    # adapting the shared helper's plain-string $Emit into this worker's J log events.
    function Invoke-LWSplitForFat32 {
        param([string]$SourceSourcesDir, [string]$DestSourcesDir, [int]$Disk, [string]$ProgressPhase = 'wim-split')
        Split-LWImageForFat32 -SourceSourcesDir $SourceSourcesDir -DestSourcesDir $DestSourcesDir `
            -Emit { param($m) J @{ event='log'; disk=$Disk; message=$m } } `
            -Progress { param($p) JProgress $ProgressPhase $p }
    }

    try {
        Import-Module Storage -ErrorAction Stop

        $espRoot  = $null
        $dataRoot = $null
        $driveHttpMediaOnVolume = $false

        if ($OverlayOnly) {
            # -- Overlay-only: find existing partitions by label ---------------
            JPhase 'overlay-update'

            $parts = @(Get-Partition -DiskNumber $DiskNumber -ErrorAction SilentlyContinue)
            foreach ($p in $parts) {
                try {
                    $v = $p | Get-Volume -ErrorAction SilentlyContinue
                    if ($v -and $v.DriveLetter) {
                        # -eq is case-insensitive in PowerShell, so 'LoneWolf' matches the
                        # FAT32 uppercase readback 'LONEWOLF'. Legacy labels are still accepted.
                        if ($v.FileSystemLabel -eq $DataVolumeLabel -or $v.FileSystemLabel -eq 'LoneWolf' -or $v.FileSystemLabel -eq 'Project LoneWolf' -or $v.FileSystemLabel -eq 'WINSETUP' -or $v.FileSystemLabel -eq 'WINDOWS' -or $v.FileSystemLabel -match '^\d{4}-\d{2}-\d{2}$') { $dataRoot = $v.DriveLetter + ':\' }
                        if ($v.FileSystemLabel -eq 'FB_ESP')   { $espRoot  = $v.DriveLetter + ':\' }
                    }
                } catch { }
            }

            if (-not $dataRoot) {
                throw "No '$DataVolumeLabel' or 'WINSETUP' partition found on disk $DiskNumber  -  cannot apply overlay-only update"
            }

        } else {
            # -- Full build: partition + format + DISM -------------------------
            JPhase 'partitioning'

            $disk = Get-Disk -Number $DiskNumber -ErrorAction Stop
            # KEEP IN SYNC: Get-UsbDisks.ps1 Add-DiskToList already skips IsSystem.
            # GATE: destage happy path is USB-enumerated disks (IsSystem/IsBoot false).
            # CLEANUP: this refuse is in-function defense-in-depth so a mis-passed number
            # cannot wipe the Windows disk even if USB listing is bypassed.
            # SEAL: not a FirstBase seal path - USB imaging only.
            $osDiskRefuse = $false
            try {
                if ($disk.PSObject.Properties['IsSystem'] -and $disk.IsSystem -eq $true) { $osDiskRefuse = $true }
                if ($disk.PSObject.Properties['IsBoot'] -and $disk.IsBoot -eq $true) { $osDiskRefuse = $true }
            } catch {}
            try {
                foreach ($p in @(Get-Partition -DiskNumber $DiskNumber -ErrorAction SilentlyContinue)) {
                    if (-not $p) { continue }
                    if ($p.PSObject.Properties['IsSystem'] -and $p.IsSystem) { $osDiskRefuse = $true }
                    if ($p.PSObject.Properties['IsBoot'] -and $p.IsBoot) { $osDiskRefuse = $true }
                }
            } catch {}
            try {
                $sysLetter = ([string]$env:SystemDrive).TrimEnd(':', '\')
                if ($sysLetter) {
                    $sysPart = Get-Partition -DriveLetter $sysLetter -ErrorAction SilentlyContinue
                    if ($sysPart -and ([int]$sysPart.DiskNumber -eq [int]$DiskNumber)) { $osDiskRefuse = $true }
                }
            } catch {}
            if ($osDiskRefuse) {
                throw ("Refusing Clear-Disk on disk {0} - it is a system/boot/Windows disk. Destage only wipes USB disks from Get-UsbDisks." -f $DiskNumber)
            }
            $disk | Clear-Disk -RemoveData -Confirm:$false -ErrorAction Stop
            $disk | Set-Disk -PartitionStyle GPT -ErrorAction Stop
            $disk = Get-Disk -Number $DiskNumber -ErrorAction Stop

            if ($Layout -eq 'Single') {
                # Single layout (LoneWolf default): ONE FAT32 Microsoft Basic Data partition
                # (GPT type {ebd0a0a2-...}, deliberately NOT the ESP GUID {c12a7328-...}).
                # Boot files + install media share this single volume. Because the USB carries
                # no ESP-GUID partition, only the internal disk's ESP exists at force-boot time,
                # so bcdedit {fwbootmgr} resolves cleanly instead of failing with "multiple
                # indistinguishable devices". FAT32 is mandatory: UEFI firmware can only load
                # the boot loaders from a FAT volume. install.wim is split into install.swm to
                # satisfy the FAT32 4 GB per-file limit (see Split-LWInstallImageForFat32).
                #
                # Single and Split now share ONE label 'LoneWolf' (8 chars, FAT32-legal).
                # FAT32 stores labels uppercase so it reads back as 'LONEWOLF'; all
                # detection (fb-dump.ps1, Get-UsbDisks.ps1, overlay-only below) is
                # case-insensitive, so the stored case does not matter.
                $fat32Label = $DataVolumeLabel
                J @{ event='log'; disk=$DiskNumber; message='partitioning: Single layout - one FAT32 Basic-Data volume (no ESP GUID); force-boot safe' }
                $data = $disk | New-Partition -UseMaximumSize `
                    -GptType '{ebd0a0a2-b9e5-4433-87c0-68b6b72699c7}' `
                    -AssignDriveLetter -ErrorAction Stop
                try {
                    $data | Format-Volume -FileSystem FAT32 -NewFileSystemLabel $fat32Label -Confirm:$false | Out-Null
                } catch {
                    $dl = ($data | Get-Volume -ErrorAction SilentlyContinue).DriveLetter
                    if ($dl) {
                        & cmd /c "format $dl`: /FS:FAT32 /Q /V:$fat32Label /Y" | Out-Null
                        if ($LASTEXITCODE -ne 0) { throw "FAT32 format failed on drive $dl (single-volume layout)" }
                    } else {
                        throw "FAT32 Format-Volume failed and no drive letter available for cmd /c format fallback: $($_.Exception.Message)"
                    }
                }
                $lwFatLetter = ($data | Get-Volume -ErrorAction SilentlyContinue).DriveLetter
                if ($lwFatLetter) { Set-LwFat32BpbLabel -DriveLetter $lwFatLetter -Label $fat32Label }
                # The single volume serves as BOTH boot volume and data volume. Aliasing $esp to
                # $data lets every downstream ESP/data step operate on the one volume unchanged.
                $esp      = $data
                $espRoot  = ($data | Get-Volume).DriveLetter + ':\'
                $dataRoot = $espRoot
            } else {
                # ESP partition (FAT32, 1GB default or measured)
                $esp = $disk | New-Partition -Size $EspPartitionBytes `
                    -GptType '{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}' -AssignDriveLetter -ErrorAction Stop
                try {
                    $esp | Format-Volume -FileSystem FAT32 -NewFileSystemLabel 'FB_ESP' -Confirm:$false | Out-Null
                } catch {
                    $el = ($esp | Get-Volume).DriveLetter
                    & cmd /c "format $el`: /FS:FAT32 /Q /V:FB_ESP /Y" | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw "FAT32 format failed on drive $el" }
                }
                $espFatLetter = ($esp | Get-Volume -ErrorAction SilentlyContinue).DriveLetter
                if ($espFatLetter) { Set-LwFat32BpbLabel -DriveLetter $espFatLetter -Label 'FB_ESP' }

                # Data partition (NTFS, Microsoft Basic Data GPT type so Windows always assigns a
                # drive letter and never marks the partition Inaccessible.  Without -GptType the
                # Storage stack can silently choose a non-standard GUID on some Windows builds.)
                $data = $disk | New-Partition -UseMaximumSize `
                    -GptType '{ebd0a0a2-b9e5-4433-87c0-68b6b72699c7}' `
                    -AssignDriveLetter -ErrorAction Stop
                try {
                    $data | Format-Volume -FileSystem NTFS -NewFileSystemLabel $DataVolumeLabel -Confirm:$false | Out-Null
                } catch {
                    $dl = ($data | Get-Volume -ErrorAction SilentlyContinue).DriveLetter
                    if ($dl) {
                        & cmd /c "format $dl`: /FS:NTFS /Q /V:$DataVolumeLabel /Y" | Out-Null
                        if ($LASTEXITCODE -ne 0) { throw "NTFS format failed on drive $dl (Format-Volume and cmd /c format fallback both failed)" }
                    } else {
                        throw "NTFS Format-Volume failed and no drive letter available for cmd /c format fallback: $($_.Exception.Message)"
                    }
                }

                $espRoot  = ($esp  | Get-Volume).DriveLetter + ':\'
                $dataRoot = ($data | Get-Volume).DriveLetter + ':\'
            }

            # Wait for volumes to become accessible
            foreach ($volRoot in (@($espRoot, $dataRoot) | Select-Object -Unique)) {
                for ($w = 0; $w -lt 30; $w++) {
                    if (Test-Path -LiteralPath $volRoot) { break }
                    Start-Sleep -Seconds 1
                }
            }

            $driveHttpMediaOnVolume = $false
            if ($DriveHttpDirect -and -not $OverlayOnly) {
                if (-not [string]::IsNullOrWhiteSpace($DriveHttpLibPath) -and (Test-Path -LiteralPath $DriveHttpLibPath)) {
                    . $DriveHttpLibPath
                }
                $folderId = $DriveHttpFolderId
                if ([string]::IsNullOrWhiteSpace($folderId)) {
                    throw 'drive-http: DriveHttpFolderId is missing'
                }
                J @{ event='log'; disk=$DiskNumber; message='drive-http: downloading Image Ready package from Google Drive to USB volume' }
                # Forward Node JSON on the job pipeline (Write-Output). Console.Out from
                # Start-Job is not captured by Receive-Job, so real drive-http errors were lost.
                Invoke-LwDriveHttpMediaToVolume -DiskNumber $DiskNumber -DestRoot $dataRoot -FolderId $folderId `
                    -Arch $WorkflowType -Edition $WindowsEdition -OnJsonLine {
                    param($line)
                    $t = [string]$line
                    if ($t.TrimStart().StartsWith('{')) { Write-Output $t }
                }
                if (Get-Command -Name Move-LwUsbMediaRootArtifacts -ErrorAction SilentlyContinue) {
                    Move-LwUsbMediaRootArtifacts -VolRoot $dataRoot
                }
                $IsoDrive = $dataRoot.TrimEnd('\')
                $driveHttpMediaOnVolume = $true
                if ($Layout -eq 'Single') {
                    $dataSourcesHttp = Join-Path $dataRoot 'sources'
                    $psOnUsbHttp = @(Get-ChildItem -LiteralPath $dataSourcesHttp -File -ErrorAction SilentlyContinue |
                        Where-Object { $_.Name -match '^install(\d*)\.(swm|wim|esd)$' })
                    if ($psOnUsbHttp.Count -eq 0) {
                        throw 'drive-http: no install*.swm / install.wim on USB after Drive download'
                    }
                    JPhase 'wim-presplit'
                    JProgress 'wim-presplit' 100
                    J @{ event='log'; disk=$DiskNumber; message=("wim-presplit: install image on USB from Drive HTTP ({0} file(s))" -f $psOnUsbHttp.Count) }
                }
            }

            # ESP copy: ISO mode (LoneWolf / WIN-INSTALL / Architecture B) copies boot files
            # directly from the mounted ISO per disk. WIM mode pre-populates from ESP cache.
            JPhase 'esp-copy'
            if ($driveHttpMediaOnVolume) {
                # Single-volume package already on the stick — verify boot loaders only.
                JProgress 'esp-copy' 0
                $synthHttp = Repair-LwEspBootLoaders -EspRoot $espRoot -WorkflowType $WorkflowType
                if ($synthHttp) {
                    J @{ event='log'; disk=$DiskNumber; message=("esp-copy: synthesised efi\microsoft\boot\bootmgfw.efi from efi\boot\{0} (Drive HTTP package)" -f $synthHttp) }
                }
                $bootWimHttp = Join-Path $espRoot 'sources\boot.wim'
                if (-not (Test-Path -LiteralPath $bootWimHttp)) {
                    throw 'drive-http: sources\boot.wim missing on USB after Drive package download'
                }
                try { Set-ItemProperty -LiteralPath $bootWimHttp -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue } catch { }
                $bootmgfwHttp = Join-Path $espRoot 'efi\microsoft\boot\bootmgfw.efi'
                if (-not (Test-Path -LiteralPath $bootmgfwHttp)) {
                    throw (Get-LwEspBootmgfwMissingMessage -Prefix 'drive-http ESP' -EspRoot $espRoot -WorkflowType $WorkflowType -IsoHint 'Google Drive package')
                }
                JProgress 'esp-copy' 100
                J @{ event='log'; disk=$DiskNumber; message='esp-copy: Drive HTTP package already on USB volume (boot.wim verified)' }
            } elseif (-not [string]::IsNullOrEmpty($IsoDrive)) {
                JProgress 'esp-copy' 0
                # ISO mode: copy boot files directly from mounted ISO to USB ESP. sources\boot.wim
                # (~600-700 MB) is the bulk; the root EFI/boot items are small. Report live byte
                # progress: copy the small root items first (coarse steps), then boot.wim via a
                # polled background robocopy (mirrors the wim-presplit fast-copy pattern).
                $isoItems = @(Get-ChildItem -LiteralPath $IsoDrive -Force -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -ine 'sources' -and -not ($_.Name -match '\.(wim|esd|swm)$') })

                $bootWimSrcW = if (-not [string]::IsNullOrWhiteSpace($BootInjectSourcesDir)) {
                    Join-Path $BootInjectSourcesDir 'boot.wim'
                } else {
                    Join-Path $IsoDrive 'sources\boot.wim'
                }
                if (-not (Test-Path -LiteralPath $bootWimSrcW)) {
                    throw "$wfLabel ESP copy: sources\boot.wim not found at '$bootWimSrcW'"
                }
                $bootWimBytes = (Get-Item -LiteralPath $bootWimSrcW).Length
                $rootBytes = ($isoItems | ForEach-Object {
                    if ($_.PSIsContainer) {
                        (Get-ChildItem -LiteralPath $_.FullName -Recurse -File -ErrorAction SilentlyContinue |
                            Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                    } else { $_.Length }
                } | Measure-Object -Sum -ErrorAction SilentlyContinue).Sum
                if (-not $rootBytes) { $rootBytes = 0 }
                $espTotalBytes = [math]::Max(1, [long]$rootBytes + [long]$bootWimBytes)

                # Small root EFI/boot items: copy sequentially, emitting coarse progress.
                $espCopied = 0
                foreach ($item in $isoItems) {
                    if ($item.PSIsContainer) {
                        Copy-Item -LiteralPath $item.FullName -Destination $espRoot -Recurse -Force -ErrorAction SilentlyContinue
                        $espCopied += (Get-ChildItem -LiteralPath $item.FullName -Recurse -File -ErrorAction SilentlyContinue |
                            Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                    } else {
                        Copy-Item -LiteralPath $item.FullName -Destination $espRoot -Force -ErrorAction SilentlyContinue
                        $espCopied += $item.Length
                    }
                    try { JProgress 'esp-copy' ([math]::Min(99, [int](100 * $espCopied / $espTotalBytes))) } catch { }
                }

                # sources\boot.wim (the bulk): background robocopy + byte-poll for live progress.
                $espSources = Join-Path $espRoot 'sources'
                New-Item -ItemType Directory -Force -Path $espSources | Out-Null
                $bootWimDstW = Join-Path $espSources 'boot.wim'
                $bootWimRoboSrc = if (-not [string]::IsNullOrWhiteSpace($BootInjectSourcesDir)) {
                    $BootInjectSourcesDir
                } else {
                    Join-Path $IsoDrive 'sources'
                }
                $espJob = Start-Job -ScriptBlock {
                    param($src, $dst)
                    & robocopy.exe $src $dst 'boot.wim' /R:2 /W:5 /NP /NJH /NJS | Out-Null
                    $LASTEXITCODE
                } -ArgumentList $bootWimRoboSrc, $espSources
                while ($espJob.State -eq 'Running') {
                    Start-Sleep -Seconds 1
                    try {
                        $dstNow = 0
                        if (Test-Path -LiteralPath $bootWimDstW) { $dstNow = (Get-Item -LiteralPath $bootWimDstW).Length }
                        $espDone = [long]$rootBytes + [long]$dstNow
                        if ($espDone -ge ($espTotalBytes * 0.99)) {
                            # Dest size looks complete but robocopy is still flushing write-back
                            # to the USB. Cap the reported pct low so the UI Finalizing fake bar
                            # has room to climb (do NOT emit 99 — that made the bar look done).
                            J @{ event='progress'; disk=$DiskNumber; phase='esp-copy'; pct=88; flushing=$true; label='Finalizing...' }
                        } else {
                            JProgress 'esp-copy' ([math]::Min(88, [int](100 * $espDone / $espTotalBytes)))
                        }
                    } catch { }
                }
                $espRc = Receive-Job -Job $espJob | Select-Object -Last 1
                Remove-Job -Job $espJob -Force
                if ($espRc -gt 7) {
                    throw "$wfLabel ESP copy: robocopy failed (exit $espRc) copying sources\boot.wim to ESP at '$bootWimDstW'"
                }
                if (-not (Test-Path -LiteralPath $bootWimDstW)) {
                    throw "$wfLabel ESP copy: failed to place sources\boot.wim on ESP at '$bootWimDstW'"
                }
                # ISO boot.wim is often ReadOnly; DISM /Commit fails without clearing it first.
                try { Set-ItemProperty -LiteralPath $bootWimDstW -Name IsReadOnly -Value $false -ErrorAction Stop } catch { }
                if (-not [string]::IsNullOrWhiteSpace($BootInjectSourcesDir)) {
                    $biSentDst = Join-Path $espSources 'boot.wim.lw-injected'
                    $biSentSrc = Join-Path $BootInjectSourcesDir 'boot.wim.lw-injected'
                    if (Test-Path -LiteralPath $biSentSrc) {
                        Copy-Item -LiteralPath $biSentSrc -Destination $biSentDst -Force -ErrorAction SilentlyContinue
                    }
                }
                # Synthesise efi\microsoft\boot\bootmgfw.efi from the arch removable loader if absent
                # (AMD64: bootx64.efi; ARM64: bootaa64.efi). Do not require bootx64.efi on ARM.
                $synthFromW = Repair-LwEspBootLoaders -EspRoot $espRoot -WorkflowType $WorkflowType
                if ($synthFromW) {
                    J @{ event='log'; disk=$DiskNumber; message=("esp-copy: synthesised efi\microsoft\boot\bootmgfw.efi from efi\boot\{0} ($wfLabel)" -f $synthFromW) }
                }
                $bootmgfwDstW = Join-Path $espRoot 'efi\microsoft\boot\bootmgfw.efi'
                if (-not (Test-Path -LiteralPath $bootmgfwDstW)) {
                    throw (Get-LwEspBootmgfwMissingMessage -Prefix "$wfLabel ESP copy" -EspRoot $espRoot -WorkflowType $WorkflowType -IsoHint $IsoDrive)
                }
                JProgress 'esp-copy' 100
                $bootSrcNote = if (-not [string]::IsNullOrWhiteSpace($BootInjectSourcesDir)) { 'BootInject' } else { 'ISO' }
                J @{ event='log'; disk=$DiskNumber; message="esp-copy: boot files copied to USB ESP ($bootSrcNote boot.wim, $wfLabel); boot.wim=$([math]::Round((Get-Item -LiteralPath $bootWimDstW).Length/1MB))MB" }
            } elseif (-not [string]::IsNullOrWhiteSpace($EspCache) -and (Test-Path -LiteralPath $EspCache)) {
                Copy-Item -Path (Join-Path $EspCache '*') -Destination $espRoot -Recurse -Force -ErrorAction SilentlyContinue
                # Safety net: synthesise bootmgfw after cache copy (staging often omits it)
                $synthFromC = Repair-LwEspBootLoaders -EspRoot $espRoot -WorkflowType $WorkflowType
                if ($synthFromC) {
                    J @{ event='log'; disk=$DiskNumber; message=("esp-copy: synthesised efi\microsoft\boot\bootmgfw.efi from efi\boot\{0} (cache path)" -f $synthFromC) }
                }
                $espBootWimAfter = Join-Path $espRoot 'sources\boot.wim'
                if (-not (Test-Path -LiteralPath $espBootWimAfter)) {
                    throw "ESP copy: sources\boot.wim missing on ESP after cache copy (espCache may be incomplete)"
                }
            } else {
                throw "ESP copy: no IsoDrive, Drive HTTP package, or EspCache available (EspCache='$EspCache')"
            }

            # Re-acquire data letter (USB controllers can re-enumerate)
            $dataRoot = ($data | Get-Volume).DriveLetter + ':\'

            # Data partition write
            # Drive HTTP: package already on the volume — do not fall through to WIM mount
            # (StagingWim is empty when ShareRoot is cleared; Split-Path '' throws empty Path).
            # ISO mode: robocopy all ISO contents to data partition (install.wim stays as a file).
            # WIM mode (preferred): robocopy from a shared read-only mount prepared on the main
            # thread — concurrent DISM /Mount-Image across Start-Jobs serializes / fails, so
            # parallel Phase 1 must share one mount and only parallelize the USB writes.
            # WIM mode (fallback): per-disk local copy + Mount-Image when no shared mount exists.
            if ($driveHttpMediaOnVolume) {
                J @{ event='log'; disk=$DiskNumber; message='data-copy: Drive HTTP package already on USB volume (skip ISO/WIM data write)' }
            } elseif (-not [string]::IsNullOrEmpty($IsoDrive)) {
                JPhase 'data-copy'
                JProgress 'data-copy' 0
                # The ISO source is a single network-backed mount shared by all parallel
                # per-disk workers over SMB, so transient hiccups are possible. Give
                # robocopy more tolerance (/R:2 /W:5) and capture a per-disk log so a
                # failure can name the offending file(s). Per-file/dir lines are kept in
                # the log (no /NFL /NDL) so the tail identifies exactly what failed.
                $rcLog = Join-Path $env:TEMP "LW-robocopy-disk$DiskNumber.log"

                $srcBytes = (Get-ChildItem -LiteralPath "$IsoDrive\" -Recurse -File -ErrorAction SilentlyContinue |
                    Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                if (-not $srcBytes -or $srcBytes -le 0) { $srcBytes = 1 }

                # Single layout writes to FAT32, which cannot hold a > 4 GB install.wim/esd.
                # Exclude install images from the bulk copy; install*.swm are placed by the
                # pre-split fast path (or on-the-fly split) immediately after.
                $robXf = if ($Layout -eq 'Single') {
                    @('install.wim', 'install.esd', 'install.swm', 'install*.swm')
                } else { @() }
                $robJob = Start-Job -ScriptBlock {
                    param($src, $dst, $log, $xf)
                    # Copy the ENTIRE media tree verbatim - INCLUDING the root \boot folder
                    # (boot.sdi, the stock BIOS \boot\BCD, fonts, resources). The stock UEFI
                    # BCD resolves the WinPE RAM disk via '{ramdiskoptions} ramdisksdipath
                    # \boot\boot.sdi', so \boot\boot.sdi MUST live on the volume or WinPE
                    # silently resets right after "WinPE initialized". Earlier builds excluded
                    # \boot (/XD) as "UEFI does not need BIOS boot files" - that dropped
                    # boot.sdi and is exactly what broke ISO-mode sticks. This now mirrors the
                    # proven Build-UsbStick.ps1, which robocopies the whole ISO and never
                    # rebuilds the BCD. Only the monolithic install.wim/.esd / install*.swm
                    # are excluded here (FAT32 4 GB limit) and re-added via wim-presplit.
                    $rcArgs = @($src, $dst, '/E', '/R:2', '/W:5', '/NP', '/NJH', '/NJS')
                    if ($xf -and @($xf).Count -gt 0) { $rcArgs += '/XF'; $rcArgs += @($xf) }
                    $rcArgs += "/LOG:$log"
                    & robocopy.exe @rcArgs
                    $LASTEXITCODE
                } -ArgumentList "$IsoDrive\", $dataRoot, $rcLog, $robXf

                while ($robJob.State -eq 'Running') {
                    Start-Sleep -Seconds 2
                    try {
                        $dstBytes = (Get-ChildItem -LiteralPath $dataRoot -Recurse -File -ErrorAction SilentlyContinue |
                            Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                        if ($dstBytes -and $srcBytes -gt 0) {
                            $pct = [math]::Min(99, [int](99 * $dstBytes / $srcBytes))
                            JProgress 'data-copy' $pct
                        }
                    } catch { }
                }

                $robOutput = Receive-Job -Job $robJob
                $rcExit    = $robOutput | Select-Object -Last 1
                Remove-Job -Job $robJob -Force

                # The per-disk robocopy log is a diagnostic aid only. Read its failure tail
                # (below) BEFORE deleting it, then guarantee removal in the finally so a
                # completed build never leaves LW-robocopy-disk<N>.log littering %TEMP%.
                try {
                    if ($rcExit -gt 7) {
                        $rcTail = ''
                        try {
                            if (Test-Path -LiteralPath $rcLog) {
                                $rcTail = ((Get-Content -LiteralPath $rcLog -Tail 40 -ErrorAction SilentlyContinue) -join "`n")
                            }
                        } catch { }
                        throw "robocopy failed (exit $rcExit) copying ISO contents to data partition $dataRoot; log: $rcLog`n--- robocopy log tail ---`n$rcTail"
                    }
                } finally {
                    Remove-Item -LiteralPath $rcLog -Force -ErrorAction SilentlyContinue
                }
                JProgress 'data-copy' 100

                # Single layout: place the install image on the FAT32 volume as install*.swm.
                # FAST PATH: when a matching, validated pre-split set was resolved on the main
                # thread (Get-LWPreSplitSet), robocopy the already-split install*.swm straight
                # from the share to the USB - no temp, no mount, no on-the-fly DISM split.
                # FALLBACK: no set (or mismatch/corruption) -> the exact on-the-fly split used
                # before this feature. Pre-split applies to ISO mode ONLY.
                if ($Layout -eq 'Single') {
                    $dataSources = Join-Path $dataRoot 'sources'
                    $skipPresplitCopy = $false
                    if ($driveHttpMediaOnVolume) {
                        $psOnUsb = @(Get-ChildItem -LiteralPath $dataSources -File -ErrorAction SilentlyContinue |
                            Where-Object { $_.Name -match '^install(\d*)\.(swm|wim|esd)$' })
                        if ($psOnUsb.Count -gt 0) {
                            JPhase 'wim-presplit'
                            JProgress 'wim-presplit' 100
                            J @{ event='log'; disk=$DiskNumber; message=("wim-presplit: install image already on USB from Drive HTTP ({0} file(s))" -f $psOnUsb.Count) }
                            $skipPresplitCopy = $true
                        }
                    }
                    # Stock Windows install image. ARM64 drivers go into boot.wim only.
                    $lwInstallSet = $PreSplitSetDir
                    $lwChunkSrc = $lwInstallSet
                    if (Get-Command -Name Get-LWPreSplitChunkDir -ErrorAction SilentlyContinue) {
                        $lwChunkSrc = Get-LWPreSplitChunkDir -SetDir $lwInstallSet
                    }
                    if (-not $skipPresplitCopy -and -not [string]::IsNullOrWhiteSpace($lwInstallSet) -and (Test-Path -LiteralPath $lwChunkSrc)) {
                        JPhase 'wim-presplit'
                        JProgress 'wim-presplit' 0
                        J @{ event='log'; disk=$DiskNumber; message="wim-presplit: copying pre-split install*.swm from staged set '$lwChunkSrc' (fast path - no on-the-fly split)" }
                        New-Item -ItemType Directory -Force -Path $dataSources -ErrorAction SilentlyContinue | Out-Null
                        # install*.swm is the normal set; install.wim/.esd cover the rare
                        # already-<=4 GB image the producer copied as-is (both FAT32-legal).
                        # Source byte total for the live copy-progress denominator.
                        $psSrcBytes = (Get-ChildItem -LiteralPath $lwChunkSrc -File -ErrorAction SilentlyContinue |
                            Where-Object { $_.Name -match '^install(\d*)\.(swm|wim|esd)$' } |
                            Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                        if (-not $psSrcBytes -or $psSrcBytes -le 0) { $psSrcBytes = 1 }
                        # Robocopy the set as a nested job with /MT:3 so the three .swm files
                        # copy in PARALLEL (multi-threaded), while the outer loop polls the
                        # growing destination bytes to emit live wim-presplit progress.
                        $psJob = Start-Job -ScriptBlock {
                            param($src, $dst)
                            & robocopy.exe $src $dst 'install*.swm' 'install.wim' 'install.esd' /MT:3 /R:2 /W:5 /NP /NJH /NJS
                            $LASTEXITCODE
                        } -ArgumentList $lwChunkSrc, $dataSources

                        while ($psJob.State -eq 'Running') {
                            Start-Sleep -Seconds 1
                            try {
                                $dstBytes = (Get-ChildItem -LiteralPath $dataSources -File -ErrorAction SilentlyContinue |
                                    Where-Object { $_.Name -match '^install(\d*)\.(swm|wim|esd)$' } |
                                    Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                                if (-not $dstBytes) { $dstBytes = 0 }
                                if ($dstBytes -ge ($psSrcBytes * 0.99)) {
                                    # Dest .swm sizes look complete but robocopy is still flushing
                                    # write-back to FAT32 USB (often many minutes). Emit Finalizing
                                    # at 88 — not 99 — so the UI fake bar can keep climbing.
                                    J @{ event='progress'; disk=$DiskNumber; phase='wim-presplit'; pct=88; flushing=$true; label='Finalizing...' }
                                } else {
                                    $pct = [math]::Min(88, [int](100 * $dstBytes / $psSrcBytes))
                                    JProgress 'wim-presplit' $pct
                                }
                            } catch { }
                        }

                        $psRc = Receive-Job -Job $psJob | Select-Object -Last 1
                        Remove-Job -Job $psJob -Force
                        if ($psRc -gt 7) {
                            throw "wim-presplit: robocopy failed (exit $psRc) copying pre-split set '$lwInstallSet' -> '$dataSources'"
                        }
                        $psChunks = @(Get-ChildItem -LiteralPath $dataSources -File -ErrorAction SilentlyContinue |
                            Where-Object { $_.Name -match '^install(\d*)\.(swm|wim|esd)$' })
                        if ($psChunks.Count -eq 0) {
                            throw "wim-presplit: no install image (install*.swm / install.wim / install.esd) landed on the FAT32 volume from '$lwInstallSet'"
                        }
                        JProgress 'wim-presplit' 100
                        J @{ event='log'; disk=$DiskNumber; message=("wim-presplit: staged {0} .swm chunk(s) copied - on-the-fly split skipped" -f $psChunks.Count) }
                    } elseif (-not $skipPresplitCopy) {
                        # Distinguish the two fallback causes so the log is unambiguous: an EMPTY
                        # set dir means the MAIN-THREAD detector (Get-LWPreSplitSet) found no valid,
                        # matching set - the authoritative reason is the disk 0 'presplit:' line. A
                        # NON-empty-but-unreadable dir means detection matched but this worker's
                        # runspace could not reach the share path (creds / SMB session).
                        $psMiss = if ([string]::IsNullOrWhiteSpace($PreSplitSetDir)) {
                            'no staged set resolved on the main thread (see the disk 0 "presplit:" line for the exact reason)'
                        } else {
                            "staged set was resolved but is not readable from this worker runspace: '$PreSplitSetDir'"
                        }
                        J @{ event='log'; disk=$DiskNumber; message="presplit: $psMiss - falling back to on-the-fly split" }
                        if ([string]::IsNullOrWhiteSpace($IsoDrive)) {
                            throw "presplit: on-the-fly split needs IsoDrive sources, but IsoDrive is empty"
                        }
                        JPhase 'wim-split'
                        Invoke-LWSplitForFat32 -SourceSourcesDir (Join-Path $IsoDrive 'sources') -DestSourcesDir $dataSources -Disk $DiskNumber
                    }
                }
                if ($dataRoot -and (Get-Command -Name Move-LwUsbMediaRootArtifacts -ErrorAction SilentlyContinue)) {
                    Move-LwUsbMediaRootArtifacts -VolRoot $dataRoot
                }
            } elseif (-not [string]::IsNullOrWhiteSpace($SharedWimMount)) {
                # Shared mount path — parallel-safe (read-only mount, concurrent robocopy OK)
                JPhase 'dism'
                JProgress 'dism' 0
                if (-not (Test-Path -LiteralPath $SharedWimMount)) {
                    throw "Shared WIM mount path not found: $SharedWimMount"
                }
                J @{ event='log'; disk=$DiskNumber; message="wim-shared: robocopy from shared mount $SharedWimMount -> $dataRoot" }

                $srcBytes = (Get-ChildItem -LiteralPath $SharedWimMount -Recurse -File -ErrorAction SilentlyContinue |
                    Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                if (-not $srcBytes -or $srcBytes -le 0) { $srcBytes = 1 }

                $robXf = if ($Layout -eq 'Single') {
                    @('install.wim', 'install.esd', 'install.swm', 'install*.swm')
                } else { @() }
                $robJob = Start-Job -ScriptBlock {
                    param($src, $dst, $xf)
                    $rcArgs = @($src, $dst, '/E', '/COPY:DAT', '/DCOPY:DAT', '/R:1', '/W:2', '/NP', '/NJH', '/NJS')
                    if ($xf -and @($xf).Count -gt 0) { $rcArgs += '/XF'; $rcArgs += @($xf) }
                    & robocopy.exe @rcArgs
                    $LASTEXITCODE
                } -ArgumentList "$SharedWimMount\", $dataRoot, $robXf

                while ($robJob.State -eq 'Running') {
                    Start-Sleep -Seconds 2
                    try {
                        $dstBytes = (Get-ChildItem -LiteralPath $dataRoot -Recurse -File -ErrorAction SilentlyContinue |
                            Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                        if ($dstBytes -and $srcBytes -gt 0) {
                            $pct = [math]::Min(98, [int](98 * $dstBytes / $srcBytes))
                            JProgress 'dism' $pct
                        }
                    } catch { }
                }

                $robOutput = Receive-Job -Job $robJob
                $robExit   = $robOutput | Select-Object -Last 1
                Remove-Job -Job $robJob -Force

                if ($robExit -ge 8) {
                    throw "robocopy failed (exit $robExit) copying shared WIM mount to data partition $dataRoot"
                }
                J @{ event='log'; disk=$DiskNumber; message="wim-shared: robocopy complete (exit $robExit)" }
                if ($Layout -eq 'Single') {
                    Invoke-LWSplitForFat32 -SourceSourcesDir (Join-Path $SharedWimMount 'sources') -DestSourcesDir (Join-Path $dataRoot 'sources') -Disk $DiskNumber -ProgressPhase 'dism'
                }
                JProgress 'dism' 100
            } elseif (-not [string]::IsNullOrWhiteSpace($StagingWim) -and (Test-Path -LiteralPath $StagingWim)) {
                # Fallback: per-disk WIM copy + mount (used only when shared mount prep failed)
                JPhase 'dism'
                JProgress 'dism' 0

                $wimWorkDir = Join-Path $env:TEMP ('LW-WimWork-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
                $localWim   = Join-Path $wimWorkDir 'staging.wim'
                $mountDir   = Join-Path $wimWorkDir 'mount'
                New-Item -ItemType Directory -Path $wimWorkDir -Force | Out-Null
                New-Item -ItemType Directory -Path $mountDir   -Force | Out-Null

                try {
                    # Prefer mounting the staging WIM DIRECTLY from its share path (read-only),
                    # skipping the full multi-GB copy to %TEMP% first. A read-only mount over
                    # SMB is safe here (no-ISO builds only). If the direct mount throws for any
                    # reason (share hiccup, driver refusing a UNC mount) fall back to the proven
                    # copy-to-temp-then-mount path so resilience is preserved. The mount dir
                    # stays under %TEMP% and the finally unmount+cleanup is unchanged either way.
                    $directMountOk = $false
                    try {
                        J @{ event='log'; disk=$DiskNumber; message="wim-mount: mounting staging WIM directly from share (read-only) -> $mountDir" }
                        $mountResult = & dism.exe /Mount-Image /ImageFile:"$StagingWim" /Index:1 /MountDir:"$mountDir" /ReadOnly 2>&1
                        if ($LASTEXITCODE -ne 0) {
                            throw "DISM /Mount-Image (direct share) failed (exit $LASTEXITCODE): $($mountResult -join '; ')"
                        }
                        $directMountOk = $true
                        J @{ event='log'; disk=$DiskNumber; message='wim-mount: direct share mount ready (no local copy)' }
                        JProgress 'dism' 10
                    } catch {
                        J @{ event='log'; disk=$DiskNumber; message="WARNING: direct share mount failed ($($_.Exception.Message)); falling back to copy-to-temp then mount" }
                        # Discard any partial mount before the fallback re-mounts the same dir.
                        & dism.exe /Unmount-Image /MountDir:"$mountDir" /Discard 2>&1 | Out-Null
                    }

                    if (-not $directMountOk) {
                        $wimParent = Split-Path -Parent $StagingWim
                        $wimLeaf = Split-Path -Leaf $StagingWim
                        if ([string]::IsNullOrWhiteSpace($wimParent) -or [string]::IsNullOrWhiteSpace($wimLeaf)) {
                            throw "WIM local copy: StagingWim path is invalid ('$StagingWim')"
                        }
                        J @{ event='log'; disk=$DiskNumber; message="wim-copy: copying WIM to local temp ($localWim)..." }
                        $copyResult = & robocopy.exe $wimParent $wimWorkDir $wimLeaf /R:1 /W:2 /NP /NJH /NJS /J 2>&1
                        if ($LASTEXITCODE -ge 8) {
                            throw "WIM local copy failed (exit $LASTEXITCODE): $($copyResult -join '; ')"
                        }
                        if ($wimLeaf -ne 'staging.wim') {
                            Rename-Item -LiteralPath (Join-Path $wimWorkDir $wimLeaf) -NewName 'staging.wim' -Force
                        }
                        J @{ event='log'; disk=$DiskNumber; message='wim-copy: local copy complete' }
                        JProgress 'dism' 5

                        J @{ event='log'; disk=$DiskNumber; message="wim-mount: mounting local WIM -> $mountDir (read-only)" }
                        $mountResult = & dism.exe /Mount-Image /ImageFile:"$localWim" /Index:1 /MountDir:"$mountDir" /ReadOnly 2>&1
                        if ($LASTEXITCODE -ne 0) {
                            throw "DISM /Mount-Image failed (exit $LASTEXITCODE): $($mountResult -join '; ')"
                        }
                        JProgress 'dism' 10
                    }
                    J @{ event='log'; disk=$DiskNumber; message='wim-mount: WIM mounted, starting robocopy to data partition...' }

                    $srcBytes = (Get-ChildItem -LiteralPath $mountDir -Recurse -File -ErrorAction SilentlyContinue |
                        Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                    if (-not $srcBytes -or $srcBytes -le 0) { $srcBytes = 1 }

                    $robXf = if ($Layout -eq 'Single') {
                        @('install.wim', 'install.esd', 'install.swm', 'install*.swm')
                    } else { @() }
                    $robJob = Start-Job -ScriptBlock {
                        param($src, $dst, $xf)
                        $rcArgs = @($src, $dst, '/E', '/COPY:DAT', '/DCOPY:DAT', '/R:1', '/W:2', '/NP', '/NJH', '/NJS')
                        if ($xf -and @($xf).Count -gt 0) { $rcArgs += '/XF'; $rcArgs += @($xf) }
                        & robocopy.exe @rcArgs
                        $LASTEXITCODE
                    } -ArgumentList "$mountDir\", $dataRoot, $robXf

                    while ($robJob.State -eq 'Running') {
                        Start-Sleep -Seconds 2
                        try {
                            $dstBytes = (Get-ChildItem -LiteralPath $dataRoot -Recurse -File -ErrorAction SilentlyContinue |
                                Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                            if ($dstBytes -and $srcBytes -gt 0) {
                                $pct = [math]::Min(98, 10 + [int](88 * $dstBytes / $srcBytes))
                                JProgress 'dism' $pct
                            }
                        } catch { }
                    }

                    $robOutput = Receive-Job -Job $robJob
                    $robExit   = $robOutput | Select-Object -Last 1
                    Remove-Job -Job $robJob -Force

                    if ($robExit -ge 8) {
                        throw "robocopy failed (exit $robExit) copying WIM contents to data partition $dataRoot"
                    }
                    J @{ event='log'; disk=$DiskNumber; message="wim-mount: robocopy complete (exit $robExit)" }
                    if ($Layout -eq 'Single') {
                        # Split from the mounted WIM before the finally block unmounts it.
                        Invoke-LWSplitForFat32 -SourceSourcesDir (Join-Path $mountDir 'sources') -DestSourcesDir (Join-Path $dataRoot 'sources') -Disk $DiskNumber -ProgressPhase 'dism'
                    }
                    JProgress 'dism' 100

                } finally {
                    J @{ event='log'; disk=$DiskNumber; message='wim-mount: unmounting WIM and cleaning up temp files' }
                    if (-not [string]::IsNullOrWhiteSpace($mountDir)) {
                        & dism.exe /Unmount-Image /MountDir:"$mountDir" /Discard 2>&1 | Out-Null
                    }
                    if (-not [string]::IsNullOrWhiteSpace($wimWorkDir)) {
                        Remove-Item -LiteralPath $wimWorkDir -Recurse -Force -ErrorAction SilentlyContinue
                    }
                }
            } else {
                throw ("No media source for data partition (IsoDrive='$IsoDrive' SharedWimMount='$SharedWimMount' StagingWim='$StagingWim' driveHttp=$driveHttpMediaOnVolume)")
            }

            # SetupConfig.ini on data partition
            try {
                $dataSourcesDir = Join-Path $dataRoot 'sources'
                if (Test-Path -LiteralPath $dataSourcesDir) {
                    @('[SetupConfig]','BitLocker=AlwaysSuspend','NoReboot','ShowOOBE=None',
                      'Quiet','BypassNRO=1','[Compat]','IgnoreWarning=1') |
                        Set-Content -LiteralPath (Join-Path $dataSourcesDir 'SetupConfig.ini') -Encoding ascii -Force
                }
            } catch {
                J @{ event='log'; disk=$DiskNumber; message="SetupConfig.ini write skipped (non-fatal): $($_.Exception.Message)" }
            }

            # Re-acquire both drive letters - USB controllers can re-enumerate during the long
            # DISM/robocopy data write, causing the original $espRoot to point to a stale letter.
            $espRoot  = ($esp  | Get-Volume).DriveLetter + ':\'
            $dataRoot = ($data | Get-Volume).DriveLetter + ':\'
            if ($driveHttpMediaOnVolume) {
                $IsoDrive = $dataRoot.TrimEnd('\')
            }

            # -- Populate ESP boot files from data partition (WIM mode) or ISO drive (ISO mode) ------
            # In WIM mode espCache contains only sources\SetupConfig.ini because Build-Cache excluded
            # the staging WIM and the staging dir had no other boot files.  DISM applied the full ISO
            # tree to the data partition, so copy boot files from there to make the ESP bootable.
            # In ISO mode the earlier ESP copy may have already placed boot.wim on the ESP; only
            # fall back to the mounted ISO drive if boot.wim is still missing.
            $skipDirs = @('System Volume Information', '$RECYCLE.BIN', '$Recycle.Bin', 'RECYCLER', 'FirstBase-UsbLogs', 'FirstBase-Logs', 'LW_LOGS')
            if ([string]::IsNullOrEmpty($IsoDrive)) {
                # WIM mode: populate ESP from data partition
                J @{ event='log'; disk=$DiskNumber; message='esp-populate: copying boot files from data partition to ESP (WIM mode)' }
                $espSourcesDir2 = Join-Path $espRoot 'sources'
                New-Item -ItemType Directory -Force -Path $espSourcesDir2 -ErrorAction SilentlyContinue | Out-Null

                foreach ($epItem in (Get-ChildItem -LiteralPath $dataRoot -Force -ErrorAction SilentlyContinue)) {
                    if ($epItem.Name -ieq 'sources') { continue }
                    if ($epItem.PSIsContainer -and $skipDirs -contains $epItem.Name) { continue }
                    if (-not $epItem.PSIsContainer -and $epItem.Name -match '\.(wim|esd|swm)$') { continue }
                    $epDst = Join-Path $espRoot $epItem.Name
                    if ($epItem.PSIsContainer) {
                        Copy-Item -LiteralPath $epItem.FullName -Destination $epDst -Recurse -Force -ErrorAction SilentlyContinue
                    } else {
                        Copy-Item -LiteralPath $epItem.FullName -Destination $epDst -Force -ErrorAction SilentlyContinue
                    }
                }
                # Only copy *.sdi from the data partition's sources\ - NOT boot.wim.
                # The injected boot.wim was already placed on the ESP from the ESP cache
                # (line ~649). Copying boot.wim from the data partition here would
                # overwrite it with the stock/uninjected copy that DISM restored, which
                # causes WinPE to boot into the Windows Setup language-selection screen.
                $dataSrcDir = Join-Path $dataRoot 'sources'
                if (Test-Path -LiteralPath $dataSrcDir) {
                    foreach ($f in (Get-ChildItem -LiteralPath $dataSrcDir -File -Force -ErrorAction SilentlyContinue)) {
                        if ($f.Name -match '\.sdi$') {
                            Copy-Item -LiteralPath $f.FullName -Destination $espSourcesDir2 -Force -ErrorAction SilentlyContinue
                        }
                    }
                }
                J @{ event='log'; disk=$DiskNumber; message='esp-populate: SDI boot files copied from data partition to ESP (boot.wim retained from ESP cache)' }
                # Synthesise bootmgfw after WIM-mode populate (staging often omits it)
                $synthFromP = Repair-LwEspBootLoaders -EspRoot $espRoot -WorkflowType $WorkflowType
                if ($synthFromP) {
                    J @{ event='log'; disk=$DiskNumber; message=("esp-populate: synthesised efi\microsoft\boot\bootmgfw.efi from efi\boot\{0} (WIM mode)" -f $synthFromP) }
                }
            } else {
                # ISO mode: fall back to ISO drive if boot.wim is missing from ESP
                $espBootWimCheck = Join-Path $espRoot 'sources\boot.wim'
                if (-not (Test-Path -LiteralPath $espBootWimCheck)) {
                    J @{ event='log'; disk=$DiskNumber; message='esp-populate: boot.wim missing from ESP; copying from ISO drive (ISO mode)' }
                    $espSourcesDir2 = Join-Path $espRoot 'sources'
                    New-Item -ItemType Directory -Force -Path $espSourcesDir2 -ErrorAction SilentlyContinue | Out-Null

                    foreach ($epItem in (Get-ChildItem -LiteralPath "$IsoDrive\" -Force -ErrorAction SilentlyContinue)) {
                        if ($epItem.Name -ieq 'sources') { continue }
                        if ($epItem.PSIsContainer -and $skipDirs -contains $epItem.Name) { continue }
                        if (-not $epItem.PSIsContainer -and $epItem.Name -match '\.(wim|esd|swm)$') { continue }
                        $epDst = Join-Path $espRoot $epItem.Name
                        if ($epItem.PSIsContainer) {
                            Copy-Item -LiteralPath $epItem.FullName -Destination $epDst -Recurse -Force -ErrorAction SilentlyContinue
                        } else {
                            Copy-Item -LiteralPath $epItem.FullName -Destination $epDst -Force -ErrorAction SilentlyContinue
                        }
                    }
                    $isoSrcDir = Join-Path $IsoDrive 'sources'
                    if (Test-Path -LiteralPath $isoSrcDir) {
                        foreach ($f in (Get-ChildItem -LiteralPath $isoSrcDir -File -Force -ErrorAction SilentlyContinue)) {
                            if ($f.Name -ieq 'boot.wim' -or $f.Name -match '\.sdi$') {
                                Copy-Item -LiteralPath $f.FullName -Destination $espSourcesDir2 -Force -ErrorAction SilentlyContinue
                            }
                        }
                    }
                    J @{ event='log'; disk=$DiskNumber; message='esp-populate: boot files copied from ISO drive to ESP' }
                }
            }

            # Full-build data/ESP populate complete — continue into WinPE/overlay/BCD below.
        }

        # ---------------------------------------------------------------------
        # Post-data steps (formerly Phase 2) — run in this job so Disk A can
        # inject WinPE while Disk B is still in DISM. Injects only THIS USB's
        # ESP sources\boot.wim (never a shared cache WIM).
        # ---------------------------------------------------------------------

        # Re-acquire partition roots — USB controllers can re-enumerate during
        # the long DISM/robocopy, causing cached drive letters to go stale.
        if (-not $OverlayOnly) {
            $espRoot  = $null
            $dataRoot = $null
            $parts    = @(Get-Partition -DiskNumber $DiskNumber -ErrorAction SilentlyContinue)
            foreach ($p in $parts) {
                try {
                    $v = $p | Get-Volume -ErrorAction SilentlyContinue
                    if ($v -and $v.DriveLetter) {
                        if ($p.GptType -eq '{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}') { $espRoot  = $v.DriveLetter + ':\' }
                        if ($p.GptType -eq '{ebd0a0a2-b9e5-4433-87c0-68b6b72699c7}') { $dataRoot = $v.DriveLetter + ':\' }
                    }
                } catch { }
            }
            if ($Layout -eq 'Single') {
                # Single layout has one FAT32 Basic-Data volume that is both boot and data.
                if (-not $dataRoot) {
                    throw "Could not locate the single FAT32 volume on disk $DiskNumber (dataRoot='$dataRoot')"
                }
                $espRoot = $dataRoot
            } elseif (-not $espRoot -or -not $dataRoot) {
                throw "Could not locate ESP or data partition on disk $DiskNumber (espRoot='$espRoot' dataRoot='$dataRoot')"
            }
        }

        # -- WinPE injection: per-USB ESP boot.wim only (parallel-safe) --------
        # Each job mounts a different path (E:\sources\boot.wim vs F:\...).
        # Do NOT inject the shared ESP cache here - that stays main-thread only.
        if (-not $OverlayOnly -and $espRoot) {
            JPhase 'winpe-inject'
            $espBootWim  = Join-Path $espRoot 'sources\boot.wim'
            # Drive HTTP: skip DISM only when the package carries a valid inject sentinel
            # (Keyes / Stage ISO Image Ready). Soft Image Ready without sentinel still injects.
            $_driveHttpAlreadyInjected = $false
            if ($driveHttpMediaOnVolume -and (Test-Path -LiteralPath $espBootWim)) {
                $_httpSent = Join-Path (Join-Path $espRoot 'sources') 'boot.wim.lw-injected'
                if ((Test-Path -LiteralPath $_httpSent) -and
                    (Get-Item -LiteralPath $_httpSent).LastWriteTime -ge (Get-Item -LiteralPath $espBootWim).LastWriteTime) {
                    $_driveHttpAlreadyInjected = $true
                }
            }
            if ($_driveHttpAlreadyInjected) {
                JProgress 'winpe-inject' 100
                J @{ event='log'; disk=$DiskNumber; message='startnet-inject: Drive HTTP package boot.wim already injected (sentinel OK; skipping per-disk DISM / WinPE-OCs)' }
            } else {
            # Prefer StartnetForInjection (ContentRoot\Deploy\WinPE-Startnet.cmd) so ISO /
            # direct-overlay builds work without a local OverlayCache stage. Fall back to
            # OverlayCache only when a WIM-mode EspCache build still populated it.
            $startnetSrc = if (-not [string]::IsNullOrWhiteSpace($StartnetForInjection) -and (Test-Path -LiteralPath $StartnetForInjection)) {
                $StartnetForInjection
            } elseif (-not [string]::IsNullOrWhiteSpace($OverlayCache) -and (Test-Path -LiteralPath (Join-Path $OverlayCache 'Deploy\WinPE-Startnet.cmd'))) {
                Join-Path $OverlayCache 'Deploy\WinPE-Startnet.cmd'
            } else {
                Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd'
            }

            if (-not (Test-Path -LiteralPath $espBootWim)) {
                J @{ event='log'; disk=$DiskNumber; message='startnet-inject: boot.wim not found on ESP - WinPE will NOT auto-launch TechInstall.cmd' }
            } elseif (-not (Test-Path -LiteralPath $startnetSrc)) {
                J @{ event='log'; disk=$DiskNumber; message="startnet-inject: WinPE-Startnet.cmd not found at '$startnetSrc' - WinPE will NOT auto-launch TechInstall.cmd" }
            } else {
                try { Set-ItemProperty -LiteralPath $espBootWim -Name IsReadOnly -Value $false -ErrorAction Stop } catch { }

                $_skipPeInject = $false
                $_espSentinel = if (-not [string]::IsNullOrEmpty($IsoDrive)) {
                    Join-Path (Join-Path $espRoot 'sources') 'boot.wim.lw-injected'
                } elseif (-not [string]::IsNullOrWhiteSpace($EspCache)) {
                    Join-Path $EspCache 'sources\boot.wim.lw-injected'
                } else {
                    Join-Path (Join-Path $espRoot 'sources') 'boot.wim.lw-injected'
                }
                if ((Test-Path -LiteralPath $_espSentinel) -and (Test-Path -LiteralPath $startnetSrc)) {
                    $_sentHash = (Get-Content -LiteralPath $_espSentinel -Raw -ErrorAction SilentlyContinue).Trim()
                    $_uiFolder = if ($snapdragonWorkflow -or ($WorkflowType -match '(?i)ARM64')) { 'ARM64' } else { 'AMD64' }
                    $_uiExe = ''
                    if ($WinPeUiCacheRoot) {
                        $_uiExe = Join-Path $WinPeUiCacheRoot ("{0}\LoneWolf.WinPeUi.exe" -f $_uiFolder)
                    }
                    if (-not $_uiExe -or -not (Test-Path -LiteralPath $_uiExe)) {
                        $_uiExe = Join-Path $ContentRoot ("Deploy\WinPeUi\{0}\LoneWolf.WinPeUi.exe" -f $_uiFolder)
                    }
                    $_curHash  = if (Get-Command -Name Get-LwBootWimInjectSentinel -ErrorAction SilentlyContinue) {
                        Get-LwBootWimInjectSentinel -StartnetPath $startnetSrc -DriverDir $Arm64UsbDriverDir -WinPeUiExePath $_uiExe
                    } else {
                        (Get-FileHash -LiteralPath $startnetSrc -Algorithm SHA256 -ErrorAction SilentlyContinue).Hash
                    }
                    $_bootForAge = Join-Path (Join-Path $espRoot 'sources') 'boot.wim'
                    $_sentAgeOk = $true
                    if ((Test-Path -LiteralPath $_bootForAge) -and (Test-Path -LiteralPath $_espSentinel)) {
                        $_sentAgeOk = (Get-Item -LiteralPath $_espSentinel).LastWriteTime -ge (Get-Item -LiteralPath $_bootForAge).LastWriteTime
                    }
                    if ($_sentHash -and $_curHash -and $_sentHash -eq $_curHash -and $_sentAgeOk) {
                        $skipNote = if ([string]::IsNullOrEmpty($IsoDrive)) { 'cache sentinel' } else { 'BootInject sentinel on ESP' }
                        J @{ event='log'; disk=$DiskNumber; message=("startnet-inject: boot.wim pre-injected ({0}) - skipping per-disk DISM injection" -f $skipNote) }
                        $_skipPeInject = $true
                    }
                } elseif (-not [string]::IsNullOrEmpty($IsoDrive)) {
                    J @{ event='log'; disk=$DiskNumber; message='startnet-inject: ISO boot.wim requires per-disk DISM injection' }
                }

                if (-not $_skipPeInject) {
                    foreach ($peIdx in 1, 2) {
                        $peMountDir       = Join-Path $env:TEMP "LWPEMount_${DiskNumber}_${peIdx}"
                        $peIsMounted      = $false
                        $_peWinjBase      = if ($peIdx -eq 1) { 0 } else { 50 }
                        $_peWinjInitPct   = if ($peIdx -eq 1) { 5 } else { 52 }
                        $_peWinjCommitPct = if ($peIdx -eq 1) { 50 } else { 95 }
                        $_peWinjOcStep    = 0
                        try {
                            New-Item -ItemType Directory -Force -Path $peMountDir | Out-Null
                            JProgress 'winpe-inject' $_peWinjInitPct
                            J @{ event='log'; disk=$DiskNumber; message="startnet-inject: mounting boot.wim index $peIdx at $peMountDir ..." }

                            # Defensively discard any mount already registered against this
                            # boot.wim (this run's or a leftover from an earlier crashed build)
                            # before mounting - DISM permits only one read-write mount per WIM.
                            Clear-StaleWimMountLocal -WimPath $espBootWim | Out-Null

                            # Retry with backoff: mounting a different index of the same WIM
                            # right after another index was unmounted can transiently fail with
                            # 0xc1420127 ("already mounted for read/write access") if DISM's
                            # mount registry has not caught up yet.
                            $__mountAttempt = 0
                            $__mountMax     = 3
                            do {
                                $__mountAttempt++
                                $mOut = & dism.exe /Mount-Image /ImageFile:"$espBootWim" /Index:$peIdx /MountDir:"$peMountDir" 2>&1
                                if ($LASTEXITCODE -eq 0) { break }
                                if ($__mountAttempt -ge $__mountMax) {
                                    throw "DISM /Mount-Image (index $peIdx) failed (exit $LASTEXITCODE): $($mOut -join ' | ')"
                                }
                                J @{ event='log'; disk=$DiskNumber; message="startnet-inject: /Mount-Image (index $peIdx) attempt $__mountAttempt failed (exit $LASTEXITCODE) - clearing stale mounts and retrying in 2s ..." }
                                Clear-StaleWimMountLocal -WimPath $espBootWim | Out-Null
                                Start-Sleep -Seconds 2
                            } while ($__mountAttempt -lt $__mountMax)
                            $peIsMounted = $true

                            $sysCmdTarget = Join-Path $peMountDir 'Windows\System32\startnet.cmd'
                            Copy-Item -LiteralPath $startnetSrc -Destination $sysCmdTarget -Force
                            J @{ event='log'; disk=$DiskNumber; message="startnet-inject: startnet.cmd written (index $peIdx) ..." }

                            # Inject the UEFI pre-flight helper alongside startnet.cmd (mirrors
                            # Build-UsbStick.ps1 Invoke-TiPatchBootWim). startnet.cmd looks for it at
                            # X:\Windows\System32\Invoke-FbUefiPreflight.ps1; without this copy the
                            # pre-flight (Secure Boot / RAID) check is silently skipped at boot.
                            # Source from ContentRoot\Deploy (NOT $startnetSrc): the overlay cache's
                            # Deploy\ copy set does not include Invoke-FbUefiPreflight.ps1, but the
                            # bundled payload (ContentRoot) always does.
                            $pePreflightSrc = Join-Path $ContentRoot 'Deploy\Invoke-FbUefiPreflight.ps1'
                            if (Test-Path -LiteralPath $pePreflightSrc) {
                                Copy-Item -LiteralPath $pePreflightSrc -Destination (Join-Path $peMountDir 'Windows\System32\Invoke-FbUefiPreflight.ps1') -Force
                                J @{ event='log'; disk=$DiskNumber; message="startnet-inject: Invoke-FbUefiPreflight.ps1 written (index $peIdx) ..." }
                            } else {
                                J @{ event='log'; disk=$DiskNumber; message="startnet-inject: Invoke-FbUefiPreflight.ps1 not found at '$pePreflightSrc' (index $peIdx) - preflight will be skipped at boot" }
                            }
                            $pePnpSrc = Join-Path $ContentRoot 'Deploy\Get-FbUsbPnp.ps1'
                            if (Test-Path -LiteralPath $pePnpSrc) {
                                Copy-Item -LiteralPath $pePnpSrc -Destination (Join-Path $peMountDir 'Windows\System32\Get-FbUsbPnp.ps1') -Force
                                J @{ event='log'; disk=$DiskNumber; message="startnet-inject: Get-FbUsbPnp.ps1 written (index $peIdx) ..." }
                            }

                            $peWinpeshlPath = Join-Path $peMountDir 'Windows\System32\winpeshl.ini'
                            Set-ItemProperty -LiteralPath $peWinpeshlPath -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
                            [System.IO.File]::WriteAllText($peWinpeshlPath, "[LaunchApps]`r`ncmd.exe, /k X:\Windows\System32\startnet.cmd`r`n", [System.Text.Encoding]::ASCII)
                            J @{ event='log'; disk=$DiskNumber; message="startnet-inject: winpeshl.ini set to launch startnet.cmd (index $peIdx, setup.exe suppressed) ..." }

                            # WinPE PowerShell OCs: STRICT dependency order, base cab
                            # immediately followed by its en-us language cab. All 8 cabs
                            # are REQUIRED - PowerShell in WinPE cannot start without the
                            # matching _en-us language resources. Any missing cab or any
                            # /Add-Package failure is FATAL for this disk (re-thrown below
                            # so the disk is marked failed) rather than silently shipping a
                            # broken / PowerShell-less WinPE.
                            if (-not ($WpeOcStaging -and (Test-Path -LiteralPath $WpeOcStaging))) {
                                throw "FATAL: WinPE-OCs not found at '$WpeOcStaging' - cannot add PowerShell to WinPE (disk $DiskNumber). Stage the WinPE OC cabs in the per-architecture subfolder on the share."
                            }
                            $peOcGroups = @(
                                @{ base = 'WinPE-WMI.cab';        lang = 'WinPE-WMI_en-us.cab' },
                                @{ base = 'WinPE-NetFx.cab';      lang = 'WinPE-NetFx_en-us.cab' },
                                @{ base = 'WinPE-Scripting.cab';  lang = 'WinPE-Scripting_en-us.cab' },
                                @{ base = 'WinPE-PowerShell.cab'; lang = 'WinPE-PowerShell_en-us.cab' })
                            foreach ($peOc in $peOcGroups) {
                                foreach ($pkg in @($peOc.base, $peOc.lang)) {
                                    $cabFile = Join-Path $WpeOcStaging $pkg
                                    if (-not (Test-Path -LiteralPath $cabFile)) { $cabFile = Join-Path (Join-Path $WpeOcStaging 'en-us') $pkg }
                                    if (-not (Test-Path -LiteralPath $cabFile)) {
                                        throw "FATAL: required WinPE OC cab '$pkg' missing under '$WpeOcStaging' (disk $DiskNumber). OPERATOR ACTION: copy it into the arch subfolder '$WpeOcStaging' and re-run a Full Rebuild."
                                    }
                                    J @{ event='log'; disk=$DiskNumber; message="startnet-inject: adding $pkg to boot.wim index $peIdx (disk $DiskNumber) ..." }
                                    $peAddOut = & dism.exe /Image:"$peMountDir" /Add-Package /PackagePath:"$cabFile" 2>&1
                                    $peAddCode = $LASTEXITCODE
                                    if ($peAddCode -ne 0) {
                                        $peAddText = (($peAddOut | ForEach-Object { "$_" }) -join ' | ')
                                        if ($peAddText -match '(?i)already (installed|present)|0x800f080c|not applicable|0x800f081e|0x800f0816') {
                                            J @{ event='log'; disk=$DiskNumber; message="startnet-inject: $pkg already present or not applicable on index $peIdx (DISM $peAddCode) - continuing" }
                                        } else {
                                            throw "FATAL: startnet-inject: $pkg /Add-Package failed (exit $peAddCode) on boot.wim index $peIdx (disk $DiskNumber): $peAddText"
                                        }
                                    }
                                }
                                $_peWinjOcStep += 10
                                JProgress 'winpe-inject' ($_peWinjBase + $_peWinjOcStep)
                            }

                            $peShellCheck = Join-Path $peMountDir 'Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
                            if (-not (Test-Path -LiteralPath $peShellCheck)) {
                                throw "FATAL: powershell.exe NOT present in boot.wim index $peIdx after adding WinPE OCs (disk $DiskNumber) - refusing to ship a PowerShell-less WinPE"
                            }
                            J @{ event='log'; disk=$DiskNumber; message="startnet-inject: PowerShell verified present in WinPE (index $peIdx, disk $DiskNumber)" }

                            # Job runspace: flat-copy arch-matched WinPeUi into boot.wim (X:\FirstBase\WinPeUi).
                            $peUiFolder = if ($snapdragonWorkflow -or ($WorkflowType -match '(?i)ARM64')) { 'ARM64' } else { 'AMD64' }
                            $peWinPeUiSrc = ''
                            if ($WinPeUiCacheRoot) {
                                $peWinPeUiSrc = Join-Path $WinPeUiCacheRoot $peUiFolder
                            }
                            if (-not $peWinPeUiSrc -or -not (Test-Path -LiteralPath (Join-Path $peWinPeUiSrc 'LoneWolf.WinPeUi.exe'))) {
                                $peWinPeUiSrc = Join-Path $ContentRoot ("Deploy\WinPeUi\{0}" -f $peUiFolder)
                            }
                            $peUiExe = Join-Path $peWinPeUiSrc 'LoneWolf.WinPeUi.exe'
                            if (Test-Path -LiteralPath $peUiExe) {
                                $peUiDst = Join-Path $peMountDir 'FirstBase\WinPeUi'
                                if (Test-Path -LiteralPath $peUiDst) { Remove-Item -LiteralPath $peUiDst -Recurse -Force -ErrorAction SilentlyContinue }
                                New-Item -ItemType Directory -Force -Path $peUiDst | Out-Null
                                Copy-Item -Path (Join-Path $peWinPeUiSrc '*') -Destination $peUiDst -Recurse -Force
                                J @{ event='log'; disk=$DiskNumber; message=("startnet-inject: WinPeUi boot inject: staged -> {0}" -f $peUiDst) }
                            } else {
                                J @{ event='log'; disk=$DiskNumber; message=("startnet-inject: WinPeUi boot inject: source missing '{0}' (run npm run winpe-ui:publish or pass -WinPeUiZipBaseUrl) - splash stays USB-only" -f $peWinPeUiSrc) }
                            }

                            if ($snapdragonWorkflow) {
                                if ([string]::IsNullOrWhiteSpace($Arm64UsbDriverDir)) {
                                    throw "FATAL: ARM64 boot.wim index $peIdx has no ARM64 driver folder (disk $DiskNumber)"
                                }
                                J @{ event='log'; disk=$DiskNumber; message="startnet-inject: adding ARM64 drivers to boot.wim index $peIdx from $Arm64UsbDriverDir" }
                                Add-LwArm64DriversToMountedImage -MountDir $peMountDir -DriverRoot $Arm64UsbDriverDir -Log {
                                    param($m)
                                    J @{ event='log'; disk=$DiskNumber; message=$m }
                                } -Progress {
                                    param($p)
                                    $lo = $_peWinjBase + 40
                                    $hi = [math]::Max($lo, $_peWinjCommitPct - 1)
                                    JProgress 'winpe-inject' ($lo + [int](($hi - $lo) * ([math]::Min(100, $p) / 100.0)))
                                }
                            }

                            J @{ event='log'; disk=$DiskNumber; message="startnet-inject: committing boot.wim index $peIdx (disk $DiskNumber) ..." }
                            $uOut = & dism.exe /Unmount-Image /MountDir:"$peMountDir" /Commit 2>&1
                            if ($LASTEXITCODE -ne 0) {
                                throw "DISM /Unmount-Image /Commit (index $peIdx) failed (exit $LASTEXITCODE): $($uOut -join ' | ')"
                            }
                            $peIsMounted = $false
                            # /Unmount-Image can report success before the WIMMount filter
                            # driver has actually released its lock on the file. Poll
                            # (read-only, up to ~5s) so the next index's /Mount-Image does not
                            # race the driver and fail with 0xc1420127.
                            $__unmountWaitTries = 0
                            while ($__unmountWaitTries -lt 10 -and (Test-WimMountedLocal -WimPath $espBootWim).Count -gt 0) {
                                Start-Sleep -Milliseconds 500
                                $__unmountWaitTries++
                            }
                            J @{ event='log'; disk=$DiskNumber; message="startnet-inject: boot.wim index $peIdx committed - WinPE will auto-launch TechInstall.cmd (disk $DiskNumber)" }
                            JProgress 'winpe-inject' $_peWinjCommitPct
                        } catch {
                            $__peMsg = $_.Exception.Message
                            if ($__peMsg -like 'FATAL:*' -or -not [string]::IsNullOrEmpty($IsoDrive)) {
                                # Mandatory dependency failure, or ISO mode where stock boot.wim was
                                # just placed on the ESP — any injection failure must abort this disk.
                                J @{ event='log'; disk=$DiskNumber; message="ERROR: startnet-inject FAILED (index $peIdx) - $__peMsg" }
                                if ($peIsMounted) {
                                    & dism.exe /Unmount-Image /MountDir:"$peMountDir" /Discard 2>&1 | Out-Null
                                    $peIsMounted = $false
                                }
                                Remove-Item -LiteralPath $peMountDir -Recurse -Force -ErrorAction SilentlyContinue
                                throw
                            }
                            J @{ event='log'; disk=$DiskNumber; message="WARNING: startnet-inject FAILED (index $peIdx) - $__peMsg" }
                            J @{ event='log'; disk=$DiskNumber; message='WARNING: WinPE may NOT auto-launch TechInstall.cmd; USB boots to PE command prompt' }
                        } finally {
                            if ($peIsMounted) {
                                J @{ event='log'; disk=$DiskNumber; message="startnet-inject: discarding uncommitted WIM mount (index $peIdx, cleanup) ..." }
                                & dism.exe /Unmount-Image /MountDir:"$peMountDir" /Discard 2>&1 | Out-Null
                            }
                            Remove-Item -LiteralPath $peMountDir -Recurse -Force -ErrorAction SilentlyContinue
                        }
                    }
                }
                J @{ event='log'; disk=$DiskNumber; message='startnet-inject: complete' }
                JProgress 'winpe-inject' 100
            }
            } # end else (not driveHttpMediaOnVolume)
        }

        # -- Overlay copy (both full and overlay-only modes) -------------------
        # USB-bound overlay goes DIRECT to the stick from ContentRoot (or from a
        # pre-built OverlayCache when a non-ISO EspCache build still populated one).
        # No local temp stage of overlay files for ISO / PreferIso / OverlayOnly.
        if (-not $OverlayOnly) { JPhase 'overlay' }
        # In Single layout $espRoot and $dataRoot are the SAME volume - dedupe so the
        # overlay is not copied (and the layout marker not written) twice onto one volume.
        $overlayPartRoots = @($espRoot, $dataRoot) | Where-Object { $_ } | Select-Object -Unique

        $useOverlayCache = (-not [string]::IsNullOrWhiteSpace($OverlayCache)) -and
            (Test-Path -LiteralPath $OverlayCache) -and
            (@(Get-ChildItem -LiteralPath $OverlayCache -Force -ErrorAction SilentlyContinue).Count -gt 0)

        foreach ($partRoot in $overlayPartRoots) {
            # Quick Update / destage: wipe prior USB logs, keep a visible empty FirstBase-Logs.
            # Full rebuild is already blank after format; this still creates the folder.
            Reset-LwUsbLogFolder -VolRoot $partRoot -ClearContents:$OverlayOnly
            if ($OverlayOnly) {
                # Prior sticks hide FirstBase (+H +S). Unlock before copy so
                # Quick Update can replace TechInstall.cmd; chrome re-hides after.
                Unlock-LwUsbOverlayForCopy -PartRoot $partRoot
            }
            $ovProfile = Get-LwUsbOverlayProfile -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload ([bool]$NoPayload)
            if ($useOverlayCache) {
                foreach ($item in (Get-ChildItem -LiteralPath $OverlayCache -Force -ErrorAction SilentlyContinue)) {
                    $dst = Join-Path $partRoot $item.Name
                    if ($item.PSIsContainer) {
                        if (-not (Test-Path -LiteralPath $dst)) {
                            New-Item -ItemType Directory -Path $dst -Force | Out-Null
                        }
                        Copy-Item -Path (Join-Path $item.FullName '*') -Destination $dst -Recurse -Force
                    } else {
                        Copy-Item -LiteralPath $item.FullName -Destination $dst -Force
                    }
                }
                if (-not $NoPayload) {
                    $tiDst = Join-Path $partRoot $ovProfile.TechInstallDest
                    if (-not (Test-Path -LiteralPath $tiDst)) {
                        $null = Copy-LwOverlayPayloadFile -Source (Join-Path $ContentRoot $ovProfile.TechInstallSource) -Destination $tiDst
                    }
                    Assert-LwUpdatesOverlayTechInstall -PartRoot $partRoot -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload $false
                }
                if ($stageWuPayload) {
                    Copy-LwRepoEdgeInstaller -DestRoot $partRoot
                    # Quick Update has no OverlayCache Edge stage; Full Rebuild may have
                    # already cached Edge — re-run ContentRoot/download so the stick gets it.
                    if (Get-Command -Name Copy-LwEdgeOfflineInstaller -ErrorAction SilentlyContinue) {
                        $null = Copy-LwEdgeOfflineInstaller -WuPayloadRoot (Join-Path $partRoot 'FirstBase\WUPayload') -Arch $WorkflowType -ContentRoot $ContentRoot -EdgeShareRoot ''
                    }
                    $loopSrc = Join-Path $OverlayCache 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1'
                    if (-not (Test-Path -LiteralPath $loopSrc)) { $loopSrc = Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1' }
                    Assert-LoopCopyLocal -Src $loopSrc -Dst (Join-Path $partRoot 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1')
                }
            } else {
                # Direct ContentRoot → USB (deprecated local overlay temp stage).
                if (-not $NoPayload) {
                    New-Item -ItemType Directory -Force -Path (Join-Path $partRoot 'FirstBase\Deploy'), (Join-Path $partRoot 'FirstBase\Policy'), (Join-Path $partRoot 'FirstBase\Scripts'), (Join-Path $partRoot 'FirstBase\WUPayload'), (Join-Path $partRoot 'FirstBase\WUPayload\Tools') | Out-Null
                    $overlayMap = @(
                        @{ Src = (Join-Path $ContentRoot $ovProfile.TechInstallSource);                 Dst = $ovProfile.TechInstallDest },
                        @{ Src = (Join-Path $ContentRoot 'Deploy\disksetup.cmd');                         Dst = 'FirstBase\Deploy\disksetup.cmd' },
                        @{ Src = (Join-Path $ContentRoot 'Deploy\Invoke-FirstBaseRaidProbe.ps1');         Dst = 'FirstBase\Deploy\Invoke-FirstBaseRaidProbe.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd');                    Dst = 'FirstBase\Deploy\WinPE-Startnet.cmd' },
                        @{ Src = (Join-Path $ContentRoot 'Deploy\Show-DeployBanner.ps1');                 Dst = 'FirstBase\Deploy\Show-DeployBanner.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Deploy\Invoke-FbDeployUi.ps1');                 Dst = 'FirstBase\Deploy\Invoke-FbDeployUi.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'Deploy\Launch-FbWinPeUiEarly.cmd');             Dst = 'FirstBase\Deploy\Launch-FbWinPeUiEarly.cmd' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1');                   Dst = 'FirstBase\Deploy\FirstBaseBuildIdentity.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'Scripts\Invoke-FirstBaseDismApply.ps1');        Dst = 'FirstBase\Scripts\Invoke-FirstBaseDismApply.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\Remove-FbProvisionedBloat.ps1');        Dst = 'FirstBase\Scripts\Remove-FbProvisionedBloat.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Scripts\LayoutModification.json');              Dst = 'FirstBase\Scripts\LayoutModification.json' },
                        @{ Src = (Join-Path $ContentRoot (Get-LwUsbOverlayUnattendSource -QuickInstall ([bool]$QuickInstall))); Dst = 'FirstBase\Autounattend.xml' },
                        @{ Src = (Join-Path $ContentRoot (Get-LwUsbOverlayUnattendSource -QuickInstall ([bool]$QuickInstall))); Dst = 'FirstBase\Policy\Autounattend.xml' },
                        @{ Src = (Join-Path $ContentRoot 'SetupComplete.cmd');                            Dst = 'FirstBase\WUPayload\SetupComplete.cmd' },
                        @{ Src = (Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1');                 Dst = 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'Tools\fb-dump.ps1');                             Dst = 'FirstBase\WUPayload\Tools\fb-dump.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'Tools\fb-im.cmd');                               Dst = 'fb-im.cmd' },
                        @{ Src = (Join-Path $ContentRoot 'Tools\fb-im.ps1');                               Dst = 'FirstBase\WUPayload\Tools\fb-im.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseDebugHotkeyWatcher.ps1');              Dst = 'FirstBase\WUPayload\FirstBaseDebugHotkeyWatcher.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseDeferredOobeSound.ps1');               Dst = 'FirstBase\WUPayload\FirstBaseDeferredOobeSound.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseHandoffSplash.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseHandoffSplash.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseOobeDeferredSoundBootstrap.ps1');      Dst = 'FirstBase\WUPayload\FirstBaseOobeDeferredSoundBootstrap.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseOobeOperatorFinalize.ps1');            Dst = 'FirstBase\WUPayload\FirstBaseOobeOperatorFinalize.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseOpenSettingsAndFinish.ps1');           Dst = 'FirstBase\WUPayload\FirstBaseOpenSettingsAndFinish.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseHardwareCheck.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseHardwareCheck.ps1' },
            @{ Src = (Join-Path $ContentRoot 'Install-FbMicrosoftEdge.ps1');                  Dst = 'FirstBase\WUPayload\Install-FbMicrosoftEdge.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBasePostSysprepOobeSoundArm.ps1');         Dst = 'FirstBase\WUPayload\FirstBasePostSysprepOobeSoundArm.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseShowSplash.ps1');                      Dst = 'FirstBase\WUPayload\FirstBaseShowSplash.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashSingleInstance.ps1');            Dst = 'FirstBase\WUPayload\FirstBaseSplashSingleInstance.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashWatcher.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseSplashWatcher.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseVersion.cmd');                         Dst = 'FirstBase\WUPayload\FirstBaseVersion.cmd' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseVersion.ps1');                         Dst = 'FirstBase\WUPayload\FirstBaseVersion.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1');                   Dst = 'FirstBase\WUPayload\FirstBaseBuildIdentity.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBaseWuEngine.ps1');                        Dst = 'FirstBase\WUPayload\FirstBaseWuEngine.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'Show-UpdateProgress.ps1');                      Dst = 'FirstBase\WUPayload\Show-UpdateProgress.ps1' },
            @{ Src = (Join-Path $ContentRoot 'FirstBaseSplashTechMenu.ps1');                  Dst = 'FirstBase\WUPayload\FirstBaseSplashTechMenu.ps1' },
                        @{ Src = (Join-Path $ContentRoot 'Tools\seal_command.txt');                       Dst = 'FirstBase\WUPayload\Tools\seal_command.txt' },
                        @{ Src = (Join-Path $ContentRoot 'FirstBase.ico');                                Dst = 'FirstBase\FirstBase.ico' },
                        @{ Src = (Join-Path $ContentRoot 'Deploy\Fonts\cascadiamono.ttf');                 Dst = 'FirstBase\Deploy\Fonts\cascadiamono.ttf' }
                    )
                    if (-not $stageWuPayload) {
                        $overlayMap = @($overlayMap | Where-Object { -not (Test-LwUpdatePayloadOverlayDest -Destination $_.Dst) })
                    }
                    if ($QuickInstall) {
                        $overlayMap = @($overlayMap | Where-Object { -not (Test-LwQuickInstallSkipDeployOverlayDest -Destination $_.Dst) })
                    }
                    foreach ($o in $overlayMap) {
                        $dstPath = Join-Path $partRoot $o.Dst
                        $copied = Copy-LwOverlayPayloadFile -Source $o.Src -Destination $dstPath
                        if (-not $copied -and $o.Dst -eq $ovProfile.TechInstallDest) {
                            throw ("FATAL: {0} updates overlay did not stage {1} from '{2}'." -f $ovProfile.Arch, $ovProfile.TechInstallDest, $o.Src)
                        }
                    }
                    Assert-LwUpdatesOverlayTechInstall -PartRoot $partRoot -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload $false
                    if ($stageWuPayload) {
                        Copy-LwRepoEdgeInstaller -DestRoot $partRoot
                        Assert-LoopCopyLocal -Src (Join-Path $ContentRoot 'Invoke-WindowsUpdateLoop.ps1') -Dst (Join-Path $partRoot 'FirstBase\WUPayload\Invoke-WindowsUpdateLoop.ps1')
                    }
                    $scriptsSrc = Join-Path $ContentRoot 'Scripts'
                    if (Test-Path -LiteralPath $scriptsSrc) {
                        $scriptsDst = Join-Path $partRoot 'FirstBase\Scripts'
                        New-Item -ItemType Directory -Path $scriptsDst -Force | Out-Null
                        Copy-Item -Path (Join-Path $scriptsSrc '*') -Destination $scriptsDst -Recurse -Force -ErrorAction SilentlyContinue
                    }
                    if ($stageWuPayload) {
                        # OverlayOnly / ISO direct path: stage Edge from payload (or download).
                        # Copy-LwEdgeOfflineInstaller is in LwUsbOverlay.ps1 (dotted into this job).
                        $wuDst = Join-Path $partRoot 'FirstBase\WUPayload'
                        if (Get-Command -Name Copy-LwEdgeOfflineInstaller -ErrorAction SilentlyContinue) {
                            $null = Copy-LwEdgeOfflineInstaller -WuPayloadRoot $wuDst -Arch $WorkflowType -ContentRoot $ContentRoot -EdgeShareRoot ''
                        } else {
                            $edgePs1 = Join-Path $ContentRoot 'Install-FbMicrosoftEdge.ps1'
                            if ((Test-Path -LiteralPath $edgePs1) -and (Test-Path -LiteralPath $wuDst)) {
                                Copy-Item -LiteralPath $edgePs1 -Destination (Join-Path $wuDst 'Install-FbMicrosoftEdge.ps1') -Force -ErrorAction SilentlyContinue
                            }
                            $edgeSrc = Join-Path $ContentRoot 'Edge'
                            if ((Test-Path -LiteralPath $edgeSrc) -and (Test-Path -LiteralPath $wuDst)) {
                                $edgeDst = Join-Path $wuDst 'Edge'
                                if (-not (Test-Path -LiteralPath $edgeDst)) { New-Item -ItemType Directory -Path $edgeDst -Force | Out-Null }
                                Copy-Item -Path (Join-Path $edgeSrc '*') -Destination $edgeDst -Recurse -Force -ErrorAction SilentlyContinue
                            }
                        }
                    }
                } else {
                    # WIN-INSTALL only. Quick Install uses the install boot map above, without the update payload.
                    New-Item -ItemType Directory -Force -Path (Join-Path $partRoot 'FirstBase\Policy'), (Join-Path $partRoot 'FirstBase\Deploy'), (Join-Path $partRoot 'FirstBase\WUPayload\Tools') | Out-Null
                    $autounattendInstallSrc = Join-Path $ContentRoot 'Policy\autounattend-install.xml'
                    $autounattendSrc = if (Test-Path -LiteralPath $autounattendInstallSrc) { $autounattendInstallSrc } else { Join-Path $ContentRoot 'Policy\autounattend.xml' }
                    if (Test-Path -LiteralPath $autounattendSrc) {
                        Copy-Item -LiteralPath $autounattendSrc -Destination (Join-Path $partRoot 'FirstBase\Autounattend.xml') -Force
                        Copy-Item -LiteralPath $autounattendSrc -Destination (Join-Path $partRoot 'FirstBase\Policy\Autounattend.xml') -Force
                    }
                    $techInstallInstallSrc = Join-Path $ContentRoot 'Deploy\TechInstall-Install.cmd'
                    if (-not (Copy-LwOverlayPayloadFile -Source $techInstallInstallSrc -Destination (Join-Path $partRoot 'FirstBase\Deploy\TechInstall.cmd'))) {
                        throw ("FATAL: {0} WIN-INSTALL overlay missing Deploy\TechInstall-Install.cmd." -f $ovProfile.Arch)
                    }
                    $winpeStartnetSrc = Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd'
                    if (Test-Path -LiteralPath $winpeStartnetSrc) {
                        Copy-Item -LiteralPath $winpeStartnetSrc -Destination (Join-Path $partRoot 'FirstBase\Deploy\WinPE-Startnet.cmd') -Force
                    }
                    $bannerSrc = Join-Path $ContentRoot 'Deploy\Show-DeployBanner.ps1'
                    if (Test-Path -LiteralPath $bannerSrc) {
                        Copy-Item -LiteralPath $bannerSrc -Destination (Join-Path $partRoot 'FirstBase\Deploy\Show-DeployBanner.ps1') -Force
                    }
                    $deployUiSrc = Join-Path $ContentRoot 'Deploy\Invoke-FbDeployUi.ps1'
                    if (Test-Path -LiteralPath $deployUiSrc) {
                        Copy-Item -LiteralPath $deployUiSrc -Destination (Join-Path $partRoot 'FirstBase\Deploy\Invoke-FbDeployUi.ps1') -Force
                    }
                    $earlyUiSrc = Join-Path $ContentRoot 'Deploy\Launch-FbWinPeUiEarly.cmd'
                    if (Test-Path -LiteralPath $earlyUiSrc) {
                        Copy-Item -LiteralPath $earlyUiSrc -Destination (Join-Path $partRoot 'FirstBase\Deploy\Launch-FbWinPeUiEarly.cmd') -Force
                    }
                    $identitySrc = Join-Path $ContentRoot 'FirstBaseBuildIdentity.ps1'
                    if (Test-Path -LiteralPath $identitySrc) {
                        Copy-Item -LiteralPath $identitySrc -Destination (Join-Path $partRoot 'FirstBase\Deploy\FirstBaseBuildIdentity.ps1') -Force
                    }
                    $disksetupSrc = Join-Path $ContentRoot 'Deploy\disksetup.cmd'
                    if (Test-Path -LiteralPath $disksetupSrc) {
                        Copy-Item -LiteralPath $disksetupSrc -Destination (Join-Path $partRoot 'FirstBase\Deploy\disksetup.cmd') -Force
                    }
                    $dismApplySrc = Join-Path $ContentRoot 'Scripts\Invoke-FirstBaseDismApply.ps1'
                    if (Test-Path -LiteralPath $dismApplySrc) {
                        New-Item -ItemType Directory -Force -Path (Join-Path $partRoot 'FirstBase\Scripts') | Out-Null
                        Copy-Item -LiteralPath $dismApplySrc -Destination (Join-Path $partRoot 'FirstBase\Scripts\Invoke-FirstBaseDismApply.ps1') -Force
                    }
                    $bloatSrc = Join-Path $ContentRoot 'Scripts\Remove-FbProvisionedBloat.ps1'
                    if (Test-Path -LiteralPath $bloatSrc) {
                        New-Item -ItemType Directory -Force -Path (Join-Path $partRoot 'FirstBase\Scripts') | Out-Null
                        Copy-Item -LiteralPath $bloatSrc -Destination (Join-Path $partRoot 'FirstBase\Scripts\Remove-FbProvisionedBloat.ps1') -Force
                    }
                    $layoutSrc = Join-Path $ContentRoot 'Scripts\LayoutModification.json'
                    if (Test-Path -LiteralPath $layoutSrc) {
                        New-Item -ItemType Directory -Force -Path (Join-Path $partRoot 'FirstBase\Scripts') | Out-Null
                        Copy-Item -LiteralPath $layoutSrc -Destination (Join-Path $partRoot 'FirstBase\Scripts\LayoutModification.json') -Force
                    }
                    # fb-im front-end: cmd launcher stays at volume ROOT; PS backend + fb-dump backend under FirstBase\WUPayload\Tools\.
                    $imCmdSrc = Join-Path $ContentRoot 'Tools\fb-im.cmd'
                    if (Test-Path -LiteralPath $imCmdSrc) {
                        Copy-Item -LiteralPath $imCmdSrc -Destination (Join-Path $partRoot 'fb-im.cmd') -Force
                    }
                    $imPs1Src = Join-Path $ContentRoot 'Tools\fb-im.ps1'
                    if (Test-Path -LiteralPath $imPs1Src) {
                        Copy-Item -LiteralPath $imPs1Src -Destination (Join-Path $partRoot 'FirstBase\WUPayload\Tools\fb-im.ps1') -Force
                    }
                    $dumpPs1Src = Join-Path $ContentRoot 'Tools\fb-dump.ps1'
                    if (Test-Path -LiteralPath $dumpPs1Src) {
                        Copy-Item -LiteralPath $dumpPs1Src -Destination (Join-Path $partRoot 'FirstBase\WUPayload\Tools\fb-dump.ps1') -Force
                    }
                    $icoSrc = Join-Path $ContentRoot 'FirstBase.ico'
                    if (Test-Path -LiteralPath $icoSrc) {
                        Copy-Item -LiteralPath $icoSrc -Destination (Join-Path $partRoot 'FirstBase\FirstBase.ico') -Force
                    }
                    Copy-LwPeBrailleFont -OverlayRoot $partRoot
                }
                Copy-LwWinPeUiOverlay -OverlayRoot $partRoot
                J @{ event='log'; disk=$DiskNumber; message='overlay: copied deploy files directly from ContentRoot to USB (no local overlay temp stage)' }
            }
            if ($QuickInstall) {
                Assert-LwQuickInstallUnattend -PartRoot $partRoot
                Remove-LwQuickInstallStartnetFromDeploy -PartRoot $partRoot
            }
            if (-not $stageWuPayload -and -not $NoPayload) {
                Remove-LwStagedWindowsUpdatePayload -PartRoot $partRoot
            }
            $logDir = Join-Path $partRoot 'FirstBase-Logs'
            if (-not (Test-Path -LiteralPath $logDir)) {
                New-Item -ItemType Directory -Path $logDir -Force | Out-Null
            }
            @("Layout=$Layout",'Builder=Invoke-LoneWolfBuild.ps1') |
                Set-Content -LiteralPath (Join-Path $logDir 'FirstBase-Layout.txt') -Encoding ascii -Force
            Write-LwUsbExplorerChrome -VolRoot $partRoot -IcoSrc (Join-Path $ContentRoot 'FirstBase.ico')
        }

        # Packaged production / packaged Destage: never leave a destage marker on the stick
        # (Quick Update copy does not delete extra files, so a prior npm start destage would linger).
        if (-not $DevBuild) {
            foreach ($partRoot in $overlayPartRoots) {
                foreach ($rel in @('FirstBase\WUPayload\.dev-build', 'FirstBase\.dev-build', '.dev-build')) {
                    $marker = Join-Path $partRoot $rel
                    if (Test-Path -LiteralPath $marker) {
                        Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
                    }
                }
            }
        }

        # -- Hide Windows install media at volume root; hide FirstBase; keep fb-im.cmd visible --
        if ($dataRoot) {
            try {
                if (Get-Command -Name Move-LwUsbMediaRootArtifacts -ErrorAction SilentlyContinue) {
                    Move-LwUsbMediaRootArtifacts -VolRoot $dataRoot
                }
                $chromeProfile = Get-LwUsbOverlayProfile -WorkflowType $WorkflowType -QuickInstall ([bool]$QuickInstall) -NoPayload ([bool]$NoPayload)
                foreach ($bootItem in $chromeProfile.HiddenRootItems) {
                    $bootPath = Join-Path $dataRoot $bootItem
                    if (Test-Path -LiteralPath $bootPath) {
                        & attrib.exe +H +S $bootPath /D /S 2>&1 | Out-Null
                    }
                }
                Write-LwUsbExplorerChrome -VolRoot $dataRoot -IcoSrc (Join-Path $ContentRoot 'FirstBase.ico')
                J @{ event='log'; disk=$DiskNumber; message='hid boot/media artifacts (+H +S); hid FirstBase (+H +S); staged autorun.inf icon; left fb-im.cmd visible' }
            } catch {
                J @{ event='log'; disk=$DiskNumber; message="WARNING: Could not set boot/media artifact attributes: $($_.Exception.Message)" }
            }
        }

        # -- Ensure bootmgfw.efi + arch removable loader exist before BCD rebuild --
        if (-not $OverlayOnly -and $espRoot) {
            $synthFromBcd = Repair-LwEspBootLoaders -EspRoot $espRoot -WorkflowType $WorkflowType
            if ($synthFromBcd) {
                J @{ event='log'; disk=$DiskNumber; message=("bcd-prep: synthesised efi\microsoft\boot\bootmgfw.efi from efi\boot\{0}" -f $synthFromBcd) }
            }
            $p2Bootmgfw = Join-Path $espRoot 'efi\microsoft\boot\bootmgfw.efi'
            if (-not (Test-Path -LiteralPath $p2Bootmgfw)) {
                throw (Get-LwEspBootmgfwMissingMessage -Prefix 'bcd-prep' -EspRoot $espRoot -WorkflowType $WorkflowType -IsoHint $IsoDrive)
            }
            $p2BootWim = Join-Path $espRoot 'sources\boot.wim'
            if (-not (Test-Path -LiteralPath $p2BootWim)) {
                throw "sources\boot.wim missing on ESP (USB will fail with missing winload.efi / 0xc0000098)"
            }
            $p2BootSdi = Join-Path $espRoot 'boot\boot.sdi'
            if (-not (Test-Path -LiteralPath $p2BootSdi)) {
                throw "boot\boot.sdi missing on ESP (ramdisk boot will fail)"
            }

            # -- Secure Boot invariant: signed loaders must be present + unmodified -----
            # Secure Boot validates the loader SIGNATURE, not the partition GPT type, so a
            # Single-layout FAT32 Basic-Data volume boots under Secure Boot as long as the
            # Microsoft-signed loaders copied verbatim from the ISO are present:
            #   AMD64: \EFI\Boot\bootx64.efi     - removable-media fallback (REQUIRED)
            #   ARM64: \EFI\Boot\bootaa64.efi    - removable-media fallback (REQUIRED)
            #   both:  \EFI\Microsoft\Boot\bootmgfw.efi - Windows Boot Manager (verified above)
            # These are copied byte-for-byte from the mounted ISO by the esp-copy phase and
            # are never re-generated or re-signed here. A missing arch loader means firmware
            # cannot find a loader on removable media and the USB will not boot at all under
            # Secure Boot, so fail the build loudly rather than shipping unbootable media.
            $p2FallbackName = Get-LwRemovableBootEfiName -WorkflowType $WorkflowType
            $p2FallbackEfi = Join-Path $espRoot ('EFI\Boot\' + $p2FallbackName)
            if (-not (Test-Path -LiteralPath $p2FallbackEfi)) {
                $p2Arch = Get-LwEfiArchTag -WorkflowType $WorkflowType
                throw ("SECURE BOOT ({0}): removable-media loader \EFI\Boot\{1} missing on volume {2} - USB will not boot under Secure Boot. Aborting (do NOT ship this media). efi\boot: {3}" -f $p2Arch, $p2FallbackName, $espRoot, (Get-LwEfiFolderListing -Dir (Join-Path $espRoot 'efi\boot')))
            }
            $p2FallbackSize   = (Get-Item -LiteralPath $p2FallbackEfi).Length
            $p2BootmgfwSize   = (Get-Item -LiteralPath $p2Bootmgfw).Length
            J @{ event='log'; disk=$DiskNumber; message=("secure-boot: signed loaders verified present - \EFI\Boot\{0} ({1} bytes), \EFI\Microsoft\Boot\bootmgfw.efi ({2} bytes); copied verbatim from ISO (Secure Boot preserved)" -f $p2FallbackName, $p2FallbackSize, $p2BootmgfwSize) }
        }

        # -- Quick Update: replace install*.swm when Image Ready is newer (same family) --
        $lcuDidRefresh = $false
        $refreshedLcuKb = ''
        $refreshedOsBuild = ''
        $refreshedImageVersion = ''
        $refreshedImageDate = ''
        if ($OverlayOnly -and $dataRoot) {
            $stickLcuKb = ''
            $stickOsBuild = ''
            $stickImageVersion = ''
            try {
                $stickStampPath = Join-Path $dataRoot 'FirstBase\LW_VERSION.json'
                if (Test-Path -LiteralPath $stickStampPath) {
                    $stickStamp = Get-Content -Raw -LiteralPath $stickStampPath | ConvertFrom-Json
                    if ($stickStamp.installLcuKb) { $stickLcuKb = [string]$stickStamp.installLcuKb }
                    if ($stickStamp.osBuild) { $stickOsBuild = [string]$stickStamp.osBuild }
                    if ($stickStamp.imageVersion) { $stickImageVersion = [string]$stickStamp.imageVersion }
                }
            } catch { }
            $refreshSet = [string]$LcuRefreshSetDir
            if ([string]::IsNullOrWhiteSpace($refreshSet) -and -not [string]::IsNullOrWhiteSpace($PreSplitSetDir)) {
                $refreshSet = [string]$PreSplitSetDir
            }
            $refreshKb = [string]$InstallLcuKb
            $refreshBuild = [string]$OsBuild
            $refreshIv = [string]$LcuImageVersion
            if ([string]::IsNullOrWhiteSpace($refreshIv) -and -not [string]::IsNullOrWhiteSpace($refreshSet)) {
                try { $refreshIv = [string](Split-Path -Leaf $refreshSet) } catch { }
            }
            $lcuBehind = $false
            if (Get-Command -Name Test-LwInstallLcuBehind -ErrorAction SilentlyContinue) {
                $lcuBehind = [bool](Test-LwInstallLcuBehind -StickKb $stickLcuKb -StickBuild $stickOsBuild -CurrentKb $refreshKb -CurrentBuild $refreshBuild)
            }
            $imageBehind = $false
            if (-not [string]::IsNullOrWhiteSpace($stickImageVersion) -and -not [string]::IsNullOrWhiteSpace($refreshIv) -and
                $stickImageVersion -ne $refreshIv) {
                $imageBehind = $true
            }
            $behind = $lcuBehind -or $imageBehind
            if ($behind -and [string]::IsNullOrWhiteSpace($refreshSet) -and
                -not [string]::IsNullOrWhiteSpace($DriveHttpLibPath) -and
                (Test-Path -LiteralPath $DriveHttpLibPath) -and
                -not (Get-Command -Name Invoke-LwDriveHttpMediaToVolume -ErrorAction SilentlyContinue)) {
                . $DriveHttpLibPath
            }
            if ($behind -and [string]::IsNullOrWhiteSpace($refreshSet) -and
                -not [string]::IsNullOrWhiteSpace($DriveHttpFolderId) -and
                (Get-Command -Name Invoke-LwDriveHttpMediaToVolume -ErrorAction SilentlyContinue)) {
                $dl = Join-Path $env:TEMP ('LW-LcuStick-' + $DiskNumber)
                try {
                    J @{ event='log'; disk=$DiskNumber; message='Refreshing install image: downloading Image Ready from Drive' }
                    Invoke-LwDriveHttpMediaToVolume -DiskNumber $DiskNumber -DestRoot $dl -FolderId $DriveHttpFolderId `
                        -Arch $WorkflowType -Edition $WindowsEdition
                    if (Test-Path -LiteralPath (Join-Path $dl 'sources\install.swm')) { $refreshSet = $dl }
                } catch {
                    J @{ event='log'; disk=$DiskNumber; message=("Refreshing install image: Drive download skipped ({0})" -f $_.Exception.Message) }
                }
            }
            if ($behind -and -not [string]::IsNullOrWhiteSpace($refreshSet)) {
                JPhase 'install-refresh'
                J @{ event='progress'; disk=$DiskNumber; phase='install-refresh'; pct=10; message='Refreshing install image...' }
                Copy-LwInstallSwmSetToVolume -SetDir $refreshSet -VolumeRoot $dataRoot -Log {
                    param($m)
                    J @{ event='log'; disk=$DiskNumber; message=$m }
                }
                $lcuDidRefresh = $true
                $refreshedLcuKb = $refreshKb
                $refreshedOsBuild = $refreshBuild
                if (-not [string]::IsNullOrWhiteSpace($refreshIv)) { $refreshedImageVersion = $refreshIv }
                elseif ($refreshSet) {
                    try { $refreshedImageVersion = [string](Split-Path -Leaf $refreshSet) } catch { }
                }
                if (-not [string]::IsNullOrWhiteSpace($LcuImageBuildDate)) { $refreshedImageDate = [string]$LcuImageBuildDate }
                J @{ event='progress'; disk=$DiskNumber; phase='install-refresh'; pct=100; message='Refreshing install image...' }
                JPhase 'overlay-update'
            } elseif ($behind) {
                J @{ event='log'; disk=$DiskNumber; message='Refreshing install image: Image Ready is newer but no install*.swm set was found locally or on Drive' }
            }
        }

        # -- BCD: ship the ISO's own stock BCDs verbatim; NEVER rebuild or edit -----
        # HISTORY: 5.0.28 hand-authored a WinPE BCD from scratch (bcdedit /createstore
        # + /set calls); 5.0.29 tweaked the {bootmgr} device (locate -> boot); 5.0.30
        # copied the stock ISO BCD but still ran two 'bcdedit /store' tweaks (timeout 0
        # / displaybootmenu no) on it and kept a hand-authored fallback. ALL of that is
        # removed here.
        #
        # The proven reference builder (Windows_Installation\FirstBase Image Creation\
        # Builder\Build-UsbStick.ps1) NEVER touches the BCD: it robocopies the whole ISO
        # - including \efi\microsoft\boot\BCD (UEFI), \boot\BCD (BIOS) and \boot\boot.sdi
        # - and ships those stores byte-for-byte. The full-ISO copy above (no \boot
        # exclusion) now lands both stock BCDs + boot.sdi on the volume, so WinPE boots
        # exactly as stock removable install media does: {bootmgr} has NO device element
        # (firmware-provided load device), the loader is 'ramdisk=[boot]\sources\boot.wim,
        # {ramdiskoptions}', and [boot] resolves to the USB it was loaded from. That is
        # safe on a machine that already has Windows (no 'locate', no explicit partition)
        # and carries every element 25H2 winload requires. We only VERIFY the stock UEFI
        # store is present and fail loudly if not - we do NOT mutate it.
        if (-not $OverlayOnly -and $espRoot) {
            $uefiBcd = Join-Path $espRoot 'EFI\Microsoft\Boot\BCD'
            if (-not (Test-Path -LiteralPath $uefiBcd) -or ((Get-Item -LiteralPath $uefiBcd -ErrorAction SilentlyContinue).Length -le 0)) {
                throw "Stock UEFI BCD missing/empty at '$uefiBcd' after media copy - refusing to ship unbootable media. The ISO's \EFI\Microsoft\Boot\BCD must be copied verbatim (mirror Build-UsbStick.ps1); do NOT hand-author a store."
            }
            $biosBcd  = Join-Path $espRoot 'boot\BCD'
            $biosNote = if (Test-Path -LiteralPath $biosBcd) { 'BIOS \boot\BCD present' } else { 'BIOS \boot\BCD absent (UEFI-only boot unaffected)' }
            J @{ event='log'; disk=$DiskNumber; message=("bcd: shipping stock ISO BCD verbatim - NO bcdedit (mirrors Build-UsbStick.ps1); UEFI \EFI\Microsoft\Boot\BCD OK, {0}; ramdisk resolves via [boot]\sources\boot.wim + \boot\boot.sdi" -f $biosNote) }
        }

        # -- LoneWolf version stamp under FirstBase\ on data partition ---------
        if ($dataRoot) {
            try {
                $firstBaseDir = Join-Path $dataRoot 'FirstBase'
                if (-not (Test-Path -LiteralPath $firstBaseDir)) { New-Item -ItemType Directory -Force -Path $firstBaseDir | Out-Null }
                $stampImageDate = $ImageBuildDate
                $stampImageVersion = $ImageVersion
                if ([string]::IsNullOrWhiteSpace($stampImageVersion) -and -not [string]::IsNullOrWhiteSpace($PreSplitSetDir)) {
                    try { $stampImageVersion = [string](Split-Path -Leaf $PreSplitSetDir) } catch { }
                }
                $stampWf = [string]$WorkflowType
                if ($QuickInstall -and $stampWf -notmatch '^QUICK-INSTALL-') {
                    $stampWf = 'QUICK-INSTALL-' + $stampWf
                }
                $stampArch = 'AMD64'
                if ($stampWf -match 'ARM') { $stampArch = 'ARM64' }
                $stampArchLabel = if ($stampArch -eq 'ARM64') { 'Snapdragon' } else { 'Intel/AMD' }
                if ($OverlayOnly) {
                    try {
                        $existingStampPath = Join-Path $dataRoot 'FirstBase\LW_VERSION.json'
                        if (Test-Path -LiteralPath $existingStampPath) {
                            $existingStamp = Get-Content -Raw -LiteralPath $existingStampPath | ConvertFrom-Json
                            # Preserve stick image identity (never blank from empty remote).
                            if ($existingStamp.imageBuildDate) { $stampImageDate = [string]$existingStamp.imageBuildDate }
                            elseif ($existingStamp.wimBuildDate) { $stampImageDate = [string]$existingStamp.wimBuildDate }
                            if ($existingStamp.imageVersion) { $stampImageVersion = [string]$existingStamp.imageVersion }
                            if ($existingStamp.workflowType) { $stampWf = [string]$existingStamp.workflowType }
                            if ($existingStamp.arch) { $stampArch = [string]$existingStamp.arch }
                            if ($existingStamp.archLabel) { $stampArchLabel = [string]$existingStamp.archLabel }
                            if ($existingStamp.windowsEdition) { $WindowsEdition = [string]$existingStamp.windowsEdition }
                            elseif ($existingStamp.edition) { $WindowsEdition = [string]$existingStamp.edition }
                            if (-not $lcuDidRefresh) {
                                if ($existingStamp.installLcuKb) { $refreshedLcuKb = [string]$existingStamp.installLcuKb }
                                if ($existingStamp.osBuild) { $refreshedOsBuild = [string]$existingStamp.osBuild }
                            }
                            # Same image on stick and staging: adopt canonical imageBuildDate
                            # (heals UUP LastWrite 2024-04-01 without replacing the image).
                            if ($lcuDidRefresh) {
                                if ($refreshedImageVersion) { $stampImageVersion = [string]$refreshedImageVersion }
                                if ($refreshedImageDate) { $stampImageDate = [string]$refreshedImageDate }
                            } elseif ($stampImageVersion -and $ImageVersion -and
                                ([string]$stampImageVersion -eq [string]$ImageVersion) -and
                                -not [string]::IsNullOrWhiteSpace($ImageBuildDate)) {
                                $stampImageDate = [string]$ImageBuildDate
                            }
                        }
                    } catch { }
                }
                # Folder stamp fills imageBuildDate when missing; heal LastWrite traps via
                # Get-LWCanonicalImageBuildDateYmd when the helper is available.
                if ([string]::IsNullOrWhiteSpace($stampImageDate) -and $stampImageVersion) {
                    if (Get-Command -Name Get-LWCanonicalImageBuildDateYmd -ErrorAction SilentlyContinue) {
                        $stampImageDate = [string](Get-LWCanonicalImageBuildDateYmd -ImageVersion $stampImageVersion)
                    } elseif ($stampImageVersion -match '(\d{8})T\d{6}Z$') {
                        $d = $Matches[1]
                        $stampImageDate = ('{0}-{1}-{2}' -f $d.Substring(0, 4), $d.Substring(4, 2), $d.Substring(6, 2))
                    }
                }
                # Slim LW_VERSION.json: rewrite every destage (full or Quick Update).
                # Quick Update preserves imageVersion / imageBuildDate / windowsEdition above.
                # Pretty-print so techs can read the stick stamp without minifying.
                $payloadVer = if ($ScriptVersion) { [string]$ScriptVersion } else { [string]$StagingVersion }
                $stampPath = Join-Path $dataRoot 'FirstBase\LW_VERSION.json'
                $stamp = [ordered]@{
                    version        = $payloadVer
                    payloadVersion = $payloadVer
                    workflowType   = $stampWf
                    arch           = $stampArch
                    archLabel      = $stampArchLabel
                    windowsEdition = $(if ($WindowsEdition) { $WindowsEdition } else { 'Pro' })
                }
                if ($stampImageVersion) { $stamp.imageVersion = [string]$stampImageVersion }
                if ($stampImageDate) { $stamp.imageBuildDate = [string]$stampImageDate }
                $stampLcu = if ($lcuDidRefresh -and $InstallLcuKb) { [string]$InstallLcuKb } elseif ($refreshedLcuKb) { [string]$refreshedLcuKb } elseif (-not $OverlayOnly -and $InstallLcuKb) { [string]$InstallLcuKb } else { '' }
                $stampOs = if ($lcuDidRefresh -and $OsBuild) { [string]$OsBuild } elseif ($refreshedOsBuild) { [string]$refreshedOsBuild } elseif (-not $OverlayOnly -and $OsBuild) { [string]$OsBuild } else { '' }
                if ($stampLcu) { $stamp.installLcuKb = $stampLcu }
                if ($stampOs) { $stamp.osBuild = $stampOs }
                if ($DevBuild) {
                    $stamp.destage = $true
                    $stamp.channel = 'destage'
                    if ($DestageSkipWu) { $stamp.destageSkipWu = $true }
                }
                $stamp.builtAt = (Get-Date -Format 'o')
                if (Test-Path -LiteralPath $stampPath) {
                    Remove-Item -LiteralPath $stampPath -Force -ErrorAction SilentlyContinue
                }
                ($stamp | ConvertTo-Json -Depth 6) | Out-File -FilePath $stampPath -Encoding utf8 -Force
            } catch { }
        }

        J @{ event='done'; disk=$DiskNumber; success=$true }

    } catch {
        $msg = $_.Exception.Message
        J @{ event='error'; disk=$DiskNumber; message=$msg }
        J @{ event='done';  disk=$DiskNumber; success=$false; message=$msg }
        throw
    }
}

# --- Main execution -----------------------------------------------------------
try {
    # Shared WIM mount state (cleaned up in finally; init early so finally is always safe)
    $sharedWimWorkDir = ''
    $sharedWimMount   = ''
    $arm64InstallWorkDir = ''

    # Emit init event so the UI knows exactly what the script received
    Emit @{
        event        = 'init'
        shareRoot    = $ShareRoot
        stagingRoot  = $StagingRoot
        contentRoot  = $ContentRoot
        workflowType = $WorkflowType
        windowsEdition = $winEdition
        diskNumbers  = @($requestedDisks)
        isoMode      = $false
        sequential   = [bool]$Sequential
    }

    # Self-heal: dismount any share ISO a prior cancelled/crashed run left mounted before
    # we mount our own. Covers both full builds and the -PreCacheOnly path (shared flow).
    Invoke-LwIsoSweep

    if (-not [string]::IsNullOrWhiteSpace($ExportStagedBootWimSetDir) -or
        -not [string]::IsNullOrWhiteSpace($ExportStagedBootWimRoot)) {
        $exportLabel = if (-not [string]::IsNullOrWhiteSpace($ExportStagedBootWimSetDir)) {
            $ExportStagedBootWimSetDir
        } else {
            $ExportStagedBootWimRoot
        }
        EmitLog -Disk 0 -Msg "drive-staging: exporting injected boot.wim to '$exportLabel'"
        $arm64UsbDriverDir = ''
        if ($wfUpper -eq 'ARM64') {
            # Local UUP often has an empty WinPE-Drivers folder; Resolve falls back to HQ, then Drive HTTPS.
            $arm64UsbDriverDir = [string](Resolve-LwArm64DriverDirForBuild -ShareRoot $ShareRoot -Log {
                param($m) EmitLog -Disk 0 -Msg $m
            })
            if ([string]::IsNullOrWhiteSpace($arm64UsbDriverDir)) {
                Emit @{
                    event   = 'error'
                    disk    = -1
                    message = "FATAL: ARM64 Image Ready staging requires WinPE-Drivers with .inf packages (ShareRoot '$ShareRoot', HQ, and Google Drive). Empty local placeholders are ignored."
                }
                exit 1
            }
            EmitLog -Disk 0 -Msg "drive-staging: ARM64 WinPE drivers from '$arm64UsbDriverDir' (injected into boot.wim indexes 1 and 2)"
        }
        $startnetSrc = Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd'
        if ([string]::IsNullOrWhiteSpace($ContentRoot) -or -not (Test-Path -LiteralPath $startnetSrc)) {
            Emit @{
                event   = 'error'
                disk    = -1
                message = "drive-staging: WinPE-Startnet.cmd not found at '$startnetSrc'. Pass -AppResourcesPath to the LoneWolf src (or packaged resources) folder that contains payload\Deploy\."
            }
            exit 1
        }
        $isoItem = $null
        if (-not [string]::IsNullOrWhiteSpace($StagingIsoPath) -and (Test-Path -LiteralPath $StagingIsoPath)) {
            $isoItem = Get-Item -LiteralPath $StagingIsoPath
        } elseif (Get-Command -Name Find-LWWindowsIso -ErrorAction SilentlyContinue) {
            $isoItem = Find-LWWindowsIso -StagingRoot $isoSearchStaging -IsoRoot $IsoRoot -Arch $wfUpper -Edition $winEdition
        }
        if (-not $isoItem) {
            Emit @{ event = 'error'; disk = -1; message = "drive-staging: no source ISO for $wfUpper $winEdition under '$IsoRoot'" }
            exit 1
        }
        $exportCache = Join-Path $env:TEMP ('LWBootExport_' + [guid]::NewGuid().ToString('N').Substring(0, 8))
        $espCache = Join-Path $exportCache 'esp'
        $overlayCache = Join-Path $exportCache 'overlay'
        $useFolderSource = [bool]$isoItem.PSIsContainer
        $isoDrive = ''
        if ($useFolderSource) {
            $isoDrive = $isoItem.FullName.TrimEnd('\') + '\'
            $folderBootWim = Join-Path $isoDrive 'sources\boot.wim'
            if (-not (Test-Path -LiteralPath $folderBootWim)) {
                Emit @{ event = 'error'; disk = -1; message = "drive-staging: SourceDir '$($isoItem.FullName)' has no sources\boot.wim" }
                exit 1
            }
            EmitLog -Disk 0 -Msg "drive-staging: using media folder '$($isoItem.FullName)' (no ISO mount)"
        } else {
            $isoDiskImage = Mount-DiskImage -ImagePath $isoItem.FullName -PassThru -ErrorAction Stop
            Add-LwMountedIso -Path $isoItem.FullName
            $isoVol = ($isoDiskImage | Get-Volume | Where-Object { $_.DriveLetter }).DriveLetter
            if (-not $isoVol) { throw 'drive-staging: mounted ISO has no drive letter' }
            $isoDrive = "$isoVol`:\"
        }
        Build-IsoCache -IsoDrive $isoDrive
        $bootWimPath = Join-Path $espCache 'sources\boot.wim'
        # Image Ready export OC order: explicit → HQ → Drive HTTPS → local ADK.
        # Populate an arch-bearing base before Resolve-WpeOcArchRoot so ADK is last resort.
        $wpeOcBase = $WpeOcSource
        $hasOcBase = {
            param($root)
            if ([string]::IsNullOrWhiteSpace($root)) { return $false }
            if ((Get-Command -Name Test-LwWpeOcRootHasArch -ErrorAction SilentlyContinue) -and
                (Test-LwWpeOcRootHasArch $root)) { return $true }
            $ak = if ($wfUpper -match '(?i)ARM64') { 'ARM64' } else { 'AMD64' }
            return (Test-Path -LiteralPath (Join-Path $root $ak))
        }
        if (-not (& $hasOcBase $wpeOcBase)) {
            if (Get-Command -Name Resolve-LwWpeOcRoot -ErrorAction SilentlyContinue) {
                $hqShare = if (Get-Command -Name Get-LwHqShareRoot -ErrorAction SilentlyContinue) {
                    [string](Get-LwHqShareRoot)
                } else { '' }
                $hqOc = Resolve-LwWpeOcRoot -ShareRoot $hqShare -LocalOcRoot ''
                if (& $hasOcBase $hqOc) { $wpeOcBase = $hqOc }
            }
        }
        if (-not (& $hasOcBase $wpeOcBase)) {
            $driveOcParent = Get-LwDriveHttpSupportDestRoot -ShareRoot $ShareRoot
            if (Get-Command -Name Ensure-LwDriveHttpWpeOcRoot -ErrorAction SilentlyContinue) {
                $fetched = Ensure-LwDriveHttpWpeOcRoot -DestRoot $driveOcParent -Arch $wfUpper -Log {
                    param($m) EmitLog -Disk 0 -Msg $m
                }
                if (& $hasOcBase $fetched) { $wpeOcBase = $fetched }
            }
        }
        $wpeOcStaging = Resolve-WpeOcArchRoot -BaseRoot $wpeOcBase -Arch $wfUpper
        EmitLog -Disk 0 -Msg "drive-staging: WinPE-OCs for $wfUpper -> '$wpeOcStaging'"
        if ([string]::IsNullOrWhiteSpace($wpeOcStaging) -or -not (Test-Path -LiteralPath $wpeOcStaging)) {
            Emit @{
                event   = 'error'
                disk    = -1
                message = "FATAL: WinPE-OCs\$wfUpper not found at '$wpeOcStaging'. Reach HQ, the public Drive WinPE-OCs folder, or install the ADK WinPE optional components."
            }
            exit 1
        }
        $winPeUiSrcForInject = Resolve-LwWinPeUiPublishDir -ContentRootPath $ContentRoot -Arch $wfUpper
        $winPeUiExeForSentinel = Join-Path $winPeUiSrcForInject 'LoneWolf.WinPeUi.exe'
        Invoke-StartnetInjection -BootWimPath $bootWimPath -StartnetCmdPath $startnetSrc -WpeOcPath $wpeOcStaging -Arm64UsbDriverDir $arm64UsbDriverDir -WinPeUiSrcDir $winPeUiSrcForInject
        # Image Ready packages must carry boot.wim.lw-injected so USB Rebuild can skip
        # per-disk DISM. Invoke-StartnetInjection does not write the sentinel itself.
        $espSentinel = Join-Path $espCache 'sources\boot.wim.lw-injected'
        $injectedHash = if (Get-Command -Name Get-LwBootWimInjectSentinel -ErrorAction SilentlyContinue) {
            Get-LwBootWimInjectSentinel -StartnetPath $startnetSrc -DriverDir $arm64UsbDriverDir -WinPeUiExePath $winPeUiExeForSentinel
        } else {
            (Get-FileHash -LiteralPath $startnetSrc -Algorithm SHA256 -ErrorAction SilentlyContinue).Hash
        }
        if ([string]::IsNullOrWhiteSpace($injectedHash)) {
            Emit @{
                event   = 'error'
                disk    = -1
                message = 'drive-staging: FATAL - could not compute boot.wim inject sentinel hash after DISM inject.'
            }
            exit 1
        }
        Set-Content -LiteralPath $espSentinel -Value $injectedHash -Encoding ascii -Force
        $destSources = ''
        if (-not [string]::IsNullOrWhiteSpace($ExportStagedBootWimSetDir)) {
            $destSources = Join-Path $ExportStagedBootWimSetDir 'sources'
        } else {
            $editionFolder = $winEdition.ToLowerInvariant()
            $destRoot = Join-Path $ExportStagedBootWimRoot (Join-Path $wfUpper $editionFolder)
            $destSources = Join-Path $destRoot 'sources'
        }
        New-Item -ItemType Directory -Force -Path $destSources | Out-Null
        Copy-Item -LiteralPath $bootWimPath -Destination (Join-Path $destSources 'boot.wim') -Force
        Copy-Item -LiteralPath $espSentinel -Destination (Join-Path $destSources 'boot.wim.lw-injected') -Force
        if (-not $useFolderSource) {
            try { Dismount-DiskImage -ImagePath $isoItem.FullName -ErrorAction SilentlyContinue | Out-Null } catch { }
            Remove-LwMountedIso -Path $isoItem.FullName
        }
        if ((Get-Command -Name Test-LwPreSplitBootInjected -ErrorAction SilentlyContinue) -and
            -not [string]::IsNullOrWhiteSpace($ExportStagedBootWimSetDir) -and
            -not (Test-LwPreSplitBootInjected -SetDir $ExportStagedBootWimSetDir)) {
            Emit @{
                event   = 'error'
                disk    = -1
                message = ("drive-staging: FATAL - Image Ready set at '{0}' missing valid sources\boot.wim.lw-injected after export." -f $ExportStagedBootWimSetDir)
            }
            exit 1
        }
        Invoke-LwTempOrphanSweep -Reason 'boot-export' -IncludeCache
        EmitLog -Disk 0 -Msg ("drive-staging: injected boot.wim + sentinel exported to {0}" -f $destSources)
        Emit @{ event = 'done'; disk = 0; success = $true; message = 'boot.wim export complete (injected + sentinel)' }
        exit 0
    }

    if ($OverlayOnly) {
        EmitLog -Disk 0 -Msg 'overlay-only: Quick Update uses the launcher payload (GitHub or local src). The deployment share is not required.'
        if ([string]::IsNullOrWhiteSpace($ContentRoot) -or -not (Test-Path -LiteralPath $ContentRoot)) {
            Emit @{ event='error'; disk=-1; message="Quick Update payload was not found at '$ContentRoot'. Update the launcher from GitHub, then try again." }
            exit 1
        }
    } elseif ($DriveHttpDirect) {
        EmitLog -Disk 0 -Msg 'destage media (googleDrive HTTP direct): Image Ready package streams to USB (boot.wim already injected when staged)'
    } elseif ($DestageMedia -or $resolvedMediaSource) {
        $msLog = if ($DestageMedia -or $resolvedMediaSource -eq 'local') { 'local' } else { $resolvedMediaSource }
        EmitLog -Disk 0 -Msg "destage media ($msLog): ISO '$IsoRoot'; PreSplit '$PreSplitRoot'"
        if ($ShareRoot -match '^(?i)https?://') {
            EmitLog -Disk 0 -Msg 'destage: Drive folder URL is not ShareRoot; using local UUP ISO fallback if needed'
        } elseif ($ShareRoot -match '^\\\\') {
            $shareHost = 'WIN-HQ5JDEACV3S'
            if ($ShareRoot -match '^\\\\([^\\]+)\\') { $shareHost = $Matches[1] }
            try { Connect-Share -ShareHost $shareHost -User $ShareUser -Pass $SharePassword -ProbePath $ShareRoot } catch {
                EmitLog -Disk 0 -Msg ("destage: share connect skipped: {0}" -f $_.Exception.Message)
            }
        }
        if (-not [string]::IsNullOrWhiteSpace($ShareRoot) -and (Test-Path -LiteralPath $ShareRoot)) {
            EmitLog -Disk 0 -Msg "destage: share reachable $ShareRoot"
        } elseif (-not [string]::IsNullOrWhiteSpace($ShareRoot)) {
            EmitLog -Disk 0 -Msg "destage: share not reachable ($ShareRoot); Rebuild will use local UUP ISO/PreSplit if present"
        }
        if (-not [string]::IsNullOrWhiteSpace($LocalProjectRoot) -and -not (Test-Path -LiteralPath $LocalProjectRoot)) {
            Emit @{ event='error'; disk=-1; message="Local build mode: LocalProjectRoot not found: $LocalProjectRoot" }
            exit 1
        }
    } elseif ([string]::IsNullOrWhiteSpace($LocalProjectRoot)) {
        if ($ShareRoot -match '^(?i)https?://') {
            Emit @{ event='error'; disk=-1; message='A Google Drive folder URL is not a Windows filesystem ShareRoot. Use local UUP or the HQ UNC share.' }
            exit 1
        }
        if ($ShareRoot -match '^\\\\') {
            $shareHost = 'WIN-HQ5JDEACV3S'
            if ($ShareRoot -match '^\\\\([^\\]+)\\') { $shareHost = $Matches[1] }
            Connect-Share -ShareHost $shareHost -User $ShareUser -Pass $SharePassword -ProbePath $ShareRoot
        }
        if (-not (Test-Path -LiteralPath $ShareRoot)) {
            Emit @{ event='error'; disk=-1; message="Cannot reach share: $ShareRoot" }
            exit 1
        }
    } else {
        Emit @{ event='log'; disk=-1; message="Local build mode: using $LocalProjectRoot (share auth skipped)" }
        if (-not (Test-Path -LiteralPath $LocalProjectRoot)) {
            Emit @{ event='error'; disk=-1; message="Local build mode: LocalProjectRoot not found: $LocalProjectRoot" }
            exit 1
        }
    }

    # Payload/product version for LW_VERSION.json: bundled or -ScriptVersion. Never share VERSION.json.
    $stagingVersion = if ($ScriptVersion) { [string]$ScriptVersion } else { 'unknown' }
    try {
        $bundledVer = Join-Path $PSScriptRoot 'VERSION.json'
        if (($stagingVersion -eq 'unknown' -or [string]::IsNullOrWhiteSpace($stagingVersion)) -and (Test-Path -LiteralPath $bundledVer)) {
            $verJson = Get-Content -Raw -LiteralPath $bundledVer | ConvertFrom-Json
            if ($verJson.payloadVersion) { $stagingVersion = [string]$verJson.payloadVersion }
            elseif ($verJson.version) { $stagingVersion = [string]$verJson.version }
        }
    } catch { }
    if ([string]::IsNullOrWhiteSpace($stagingVersion)) { $stagingVersion = 'unknown' }

    # Primary layout: Staging\AMD64\AMD64.wim
    # $ArchRoot and $StagingWim already set at top of script.
    # Fallback: old layout Staging\Windows *($wfUpper).wim
    if (-not $OverlayOnly -and -not [string]::IsNullOrWhiteSpace($StagingWim) -and
        -not (Test-Path -LiteralPath $StagingWim) -and
        -not [string]::IsNullOrWhiteSpace($StagingRoot)) {
        $oldWimFiles = @(Get-ChildItem -LiteralPath $StagingRoot -File -Filter "*.wim" -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like "Windows *($wfUpper).wim" } |
            Sort-Object LastWriteTime -Descending)
        if ($oldWimFiles.Count -gt 0) { $StagingWim = $oldWimFiles[0].FullName }
    }
    $StagingWindowsDir = $ArchRoot

    # -- Media source: Google Drive Image Ready package OR ISO -----------------
    # googleDrive Image Ready packages are a full ISO tree under PreSplit\<set>\
    # (boot/efi/sources\install*.swm + injected sources\boot.wim). Prefer that
    # folder as the "ISO drive" — no Mount-DiskImage, no ISO file required.
    $isoItem    = $null
    $useIsoMode = $false
    $isoDriveLetter = ''
    $driveMediaPackageDir = ''
    $wantMediaPkgSource = ($resolvedMediaSource -eq 'googleDrive' -or $resolvedMediaSource -eq 'share')

    if (-not $OverlayOnly -and $DriveHttpDirect) {
        $useIsoMode = $true
        Emit @{
            event          = 'iso-mode'
            disk           = 0
            isoFile        = 'Google Drive (HTTPS direct)'
            windowsEdition = $winEdition
            mediaPackage   = $true
            message        = 'Google Drive Image Ready package will download to the USB volume during build'
        }
        EmitLog -Disk 0 -Msg 'googleDrive: Drive HTTP direct to USB enabled (public folder over HTTPS)'
        # Prefer packages that already carry injected boot.wim (skip per-disk DISM).
        # Keep $WpeOcSource for inject fallback when the package has no sentinel.
        $script:DriveHttpSupportRoot = ''
    }

    if (-not $OverlayOnly -and -not $DriveHttpDirect -and $wantMediaPkgSource -and
        -not [string]::IsNullOrWhiteSpace($PreSplitRoot) -and
        (Get-Command -Name Get-LWPreSplitCandidateDirs -ErrorAction SilentlyContinue) -and
        (Get-Command -Name Test-LwPreSplitMediaPackage -ErrorAction SilentlyContinue)) {
        $pkgCands = @(Get-LWPreSplitCandidateDirs -PreSplitRoot $PreSplitRoot -Arch $wfUpper -Edition $winEdition)
        foreach ($setDir in $pkgCands) {
            if (-not (Test-LwPreSplitMediaPackage -SetDir $setDir)) { continue }
            $injected = $false
            if (Get-Command -Name Test-LwPreSplitBootInjected -ErrorAction SilentlyContinue) {
                $injected = [bool](Test-LwPreSplitBootInjected -SetDir $setDir)
            }
            if ($injected) {
                $driveMediaPackageDir = $setDir
                break
            }
            if (-not $driveMediaPackageDir) { $driveMediaPackageDir = $setDir }
        }
        if ($driveMediaPackageDir) {
            $useIsoMode = $true
            $isoDriveLetter = ($driveMediaPackageDir.TrimEnd('\') + '\')
            $pkgLeaf = Split-Path -Leaf $driveMediaPackageDir
            $pkgInjected = (Get-Command -Name Test-LwPreSplitBootInjected -ErrorAction SilentlyContinue) -and
                (Test-LwPreSplitBootInjected -SetDir $driveMediaPackageDir)
            $pkgLabel = if ($resolvedMediaSource -eq 'share') { 'HQ share' } else { 'Google Drive' }
            $isoReason = if ($pkgInjected) {
                "$pkgLabel Image Ready package '$pkgLeaf' (copy to USB; skip ISO mount; boot.wim already injected)"
            } else {
                "$pkgLabel media package '$pkgLeaf' (copy to USB; skip ISO mount; WinPE inject on stick)"
            }
            Emit @{
                event           = 'iso-mode'
                disk            = 0
                isoFile         = $pkgLeaf
                windowsEdition  = $winEdition
                mediaPackage    = $true
                message         = $isoReason
            }
            EmitLog -Disk 0 -Msg ("{0}: using PreSplit media package at '{1}' (no ISO mount)" -f $resolvedMediaSource, $isoDriveLetter)
        }
    }

    # ISO is the default source when no Image Ready package is available (not for Drive HTTP direct).
    # Home never falls back to a Pro ISO or a SKU-unaware staged WIM.
    if (-not $OverlayOnly -and -not $useIsoMode -and -not $DriveHttpDirect) {
        if (Get-Command -Name Find-LWWindowsIso -ErrorAction SilentlyContinue) {
            $isoFind = @{ StagingRoot = $isoSearchStaging; IsoRoot = $IsoRoot; Arch = $wfUpper; Edition = $winEdition }
            $isoItem = Find-LWWindowsIso @isoFind
        }
        if ($isoItem) {
            if ($DestageMedia) {
                EmitLog -Disk 0 -Msg "destage: using local UUP ISO '$($isoItem.FullName)'; PreSplit '$PreSplitRoot'"
            }
            $useIsoMode = $true
            $isoReason  = if ($ForceIsoMode) {
                'ForceIsoMode: skipping WIM, mounting ISO directly'
            } elseif ($PreferIso) {
                "LoneWolf: auto-selected newest $winEdition ISO '$($isoItem.Name)' (ignoring staged WIM)"
            } elseif ($NoPayload) {
                "WIN-INSTALL: preferring $winEdition ISO over staged WIM (Architecture B)"
            } elseif ($QuickInstall) {
                "QUICK-INSTALL: preferring $winEdition ISO over staged WIM (Architecture B)"
            } else {
                "Auto-selected newest $winEdition ISO '$($isoItem.Name)' (ISO is the default build source)"
            }
            Emit @{ event='iso-mode'; disk=0; isoFile=$isoItem.Name; windowsEdition=$winEdition; message=$isoReason }
        } elseif ($winEdition -eq 'Home') {
            $isoHint = $IsoRoot
            if ($DestageMedia -and $IsoFallbackRoot) { $isoHint = "$IsoRoot (fallback $IsoFallbackRoot)" }
            $msg = if ($resolvedMediaSource -eq 'googleDrive') {
                "No Image Ready PreSplit package and no Windows Home ISO for $wfUpper under '$PreSplitRoot' / '$isoHint'."
            } elseif (Get-Command -Name Get-LWMissingHomeIsoMessage -ErrorAction SilentlyContinue) {
                Get-LWMissingHomeIsoMessage -Arch $wfUpper -IsoHomeDir $isoHint
            } else {
                "No Windows Home ISO for $wfUpper in $isoHint. Place a *($wfUpper)*.iso with home in the name under ISO\ (do not use the Pro image)."
            }
            Emit @{ event='error'; disk=-1; message=$msg }
            exit 1
        } else {
            $isoGlob = "*($wfUpper)*.iso"
            $isoHint = $IsoRoot
            if ($DestageMedia -and $IsoFallbackRoot) { $isoHint = "$IsoRoot (fallback $IsoFallbackRoot)" }
            Emit @{ event='log'; disk=-1; message="WARNING: no matching $winEdition $isoGlob found in $isoHint (name must include pro; legacy ISO\Pro still read) - falling back to a staged WIM if one is present" }
        }
    }

    if (-not $useIsoMode -and -not $OverlayOnly -and
        ([string]::IsNullOrWhiteSpace($StagingWim) -or -not (Test-Path -LiteralPath $StagingWim))) {
        $msg = if ($resolvedMediaSource -eq 'googleDrive') {
            "No Image Ready PreSplit package under '$PreSplitRoot' and no $winEdition ISO / WIM. Sync the Drive folder (full ISO tree + install*.swm + sources\boot.wim) or Stage ISO."
        } else {
            "No WIM at $StagingWim and no $winEdition ISO in $IsoRoot (or legacy ISO\$winEdition) - drop an ISO named *$($winEdition.ToLower())*($wfUpper)*.iso into Staging\ISO\"
        }
        Emit @{ event='error'; disk=-1; message=$msg }
        exit 1
    }

    # -- Mount ISO once when needed (skipped for Google Drive media packages) --
    $isoDiskImage = $null
    if ($useIsoMode -and [string]::IsNullOrEmpty($isoDriveLetter) -and
        $resolvedMediaSource -eq 'googleDrive' -and -not $OverlayOnly -and $null -ne $isoItem) {
        # Legacy: ISO present on Drive alongside PreSplit — prefer matching package when valid.
        $pkgSet = Get-LWPreSplitSet -Iso $isoItem -PreSplitRoot $PreSplitRoot -Arch $wfUpper -Edition $winEdition -VerifyHash:$VerifyPreSplitHash
        if ($pkgSet -and (Get-Command -Name Test-LwPreSplitMediaPackage -ErrorAction SilentlyContinue) -and
            (Test-LwPreSplitMediaPackage -SetDir $pkgSet)) {
            $isoDriveLetter = ($pkgSet.TrimEnd('\') + '\')
            $driveMediaPackageDir = $pkgSet
            EmitLog -Disk 0 -Msg "googleDrive: using staged PreSplit media package at '$isoDriveLetter' (skip ISO mount)"
        }
    }
    if ($useIsoMode -and [string]::IsNullOrEmpty($isoDriveLetter) -and -not $DriveHttpDirect) {
        if ($null -eq $isoItem) {
            Emit @{ event='error'; disk=-1; message='ISO mode selected but no ISO file and no media package path was resolved' }
            exit 1
        }
        try {
            # Mount the ISO DIRECTLY from its UNC/share path - no local copy or cache.
            $isoSizeGb = [math]::Round($isoItem.Length / 1GB, 1)
            EmitLog -Disk 0 -Msg "iso-mount: mounting '$($isoItem.Name)' directly from share ($isoSizeGb GB) - no local copy..."
            $isoDiskImage = Mount-DiskImage -ImagePath $isoItem.FullName -PassThru -ErrorAction Stop
            Add-LwMountedIso -Path $isoItem.FullName
            for ($retryIdx = 0; $retryIdx -lt 3 -and [string]::IsNullOrEmpty($isoDriveLetter); $retryIdx++) {
                if ($retryIdx -gt 0) { Start-Sleep -Seconds 1 }
                $isoVol = $isoDiskImage | Get-Volume -ErrorAction SilentlyContinue
                if ($isoVol -and $isoVol.DriveLetter) {
                    $isoDriveLetter = $isoVol.DriveLetter + ':'
                }
            }
            if ([string]::IsNullOrEmpty($isoDriveLetter)) {
                Emit @{ event='error'; disk=-1; message="Failed to get drive letter for mounted ISO '$($isoItem.Name)' after 3 attempts" }
                exit 1
            }
            EmitLog -Disk 0 -Msg "ISO mounted at $isoDriveLetter : $($isoItem.Name)"
        } catch {
            Emit @{ event='error'; disk=-1; message="Failed to mount ISO directly from share path '$($isoItem.FullName)': $($_.Exception.Message)" }
            exit 1
        }
    }

    $arm64UsbDriverDir = ''
    $arm64InstallImageDir = ''
    $snapdragonBuild = $false
    if (Get-Command -Name Test-LwSnapdragonWorkflow -ErrorAction SilentlyContinue) {
        $snapdragonBuild = [bool](Test-LwSnapdragonWorkflow -WorkflowType $WorkflowType)
    }
    if ($snapdragonBuild -and -not $OverlayOnly -and -not $DriveHttpDirect) {
        if (-not (Get-Command -Name Resolve-LwArm64DriverDir -ErrorAction SilentlyContinue)) {
            throw 'FATAL: ARM64 driver helper is not loaded (lib\Add-LwArm64Drivers.ps1).'
        }
        $arm64UsbDriverDir = [string](Resolve-LwArm64DriverDirForBuild -ShareRoot $ShareRoot -Log {
            param($m) EmitLog -Disk 0 -Msg $m
        })
        if ([string]::IsNullOrWhiteSpace($arm64UsbDriverDir)) {
            $hintRoot = if (-not [string]::IsNullOrWhiteSpace($ShareRoot)) {
                Join-Path $ShareRoot 'WinPE-Drivers'
            } else {
                'WinPE-Drivers'
            }
            throw ("FATAL: ARM64 build requires driver packages under '{0}' (HQ or Google Drive when local is empty)." -f $hintRoot)
        }
        EmitLog -Disk 0 -Msg "ARM64 drivers: $arm64UsbDriverDir (injected into boot.wim only; the Windows install image stays stock)"
    } elseif ($snapdragonBuild -and -not $OverlayOnly -and $DriveHttpDirect) {
        EmitLog -Disk 0 -Msg 'ARM64 drivers: Drive HTTP package boot.wim already includes injected drivers (no WinPE-Drivers download)'
    } elseif (-not $OverlayOnly) {
        EmitLog -Disk 0 -Msg "ARM64 driver inject skipped for $wfUpper (Intel/AMD and Quick Install Intel/AMD do not get ARM64 drivers)"
    }
    if ($stageWuPayload) {
        EmitLog -Disk 0 -Msg 'Windows Updates: staging Windows Update payload (WUPayload, Edge installer, update loop)'
    } elseif ($QuickInstall -and $snapdragonBuild) {
        $qiDriverNote = if ($OverlayOnly) { '' } else { ' ARM64 drivers are injected into WinPE only.' }
        EmitLog -Disk 0 -Msg ("Snapdragon Quick Install: skipping Windows Update payload (no WUPayload, Edge installer, or offline update servicing).{0}" -f $qiDriverNote)
    } elseif ($QuickInstall) {
        EmitLog -Disk 0 -Msg 'Quick Install Intel/AMD: skipping Windows Update payload (no WUPayload, Edge installer, or offline update servicing). ARM64 drivers are not injected.'
    }

    # Measure ESP size for dynamic partition sizing
    $espCacheBytes = 0
    try {
        if ($useIsoMode -and -not [string]::IsNullOrWhiteSpace($isoDriveLetter)) {
            $espCacheBytes = (Get-ChildItem -LiteralPath "$isoDriveLetter\" -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -notmatch '\\sources\\install\.(wim|esd|swm)$' } |
                Measure-Object -Property Length -Sum).Sum
        } elseif (-not [string]::IsNullOrWhiteSpace($StagingWindowsDir) -and (Test-Path -LiteralPath $StagingWindowsDir)) {
            # Exclude install images AND the staged arch WIM (e.g. AMD64.wim) from ESP size estimate
            # Mirror Build-Cache logic: sources\ contributes only boot.wim + *.sdi to the ESP.
            $espCacheBytes = (Get-ChildItem -LiteralPath $StagingWindowsDir -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -notmatch '^install\.(wim|esd|swm)$' -and
                               $_.Name -notmatch '^(AMD64|ARM64)\.(wim|esd|swm)$' -and
                               ($_.FullName -notmatch '\\sources\\' -or $_.Name -ieq 'boot.wim' -or $_.Name -match '\.sdi$') } |
                Measure-Object -Property Length -Sum).Sum
        }
    } catch { $espCacheBytes = 0 }
    if (-not $espCacheBytes -or $espCacheBytes -le 0) { $espCacheBytes = 1GB }

    $espHeadroom = [math]::Max(384MB, [long]($espCacheBytes * 0.20))
    $espPartitionBytes = [long]([math]::Ceiling(($espCacheBytes + $espHeadroom) / 512MB) * 512MB)

    # Both WIN-INSTALL (-NoPayload) and full builds inject the same WinPE-Startnet.cmd into boot.wim.
    # Architecture B: startnet -> wpeinit -> finds Deploy\TechInstall.cmd on data partition ->
    #   TechInstall.cmd (= TechInstall-Install.cmd for WIN-INSTALL) -> disksetup.cmd + DISM apply + bcdboot + shutdown.
    # The autounattend.xml on the data partition is an offline unattend only (no DiskConfiguration/ImageInstall).
    $noPayloadStartnetTempPath = ''
    $startnetForInjection = if (-not [string]::IsNullOrWhiteSpace($ContentRoot)) {
        Join-Path $ContentRoot 'Deploy\WinPE-Startnet.cmd'
    } else {
        ''
    }

    $bootInjectSourcesDirForWorker = ''
    if ($DriveHttpDirect) {
        EmitLog -Disk 0 -Msg 'googleDrive: HTTP direct - BootInject scan skipped (injected boot.wim comes with the USB package download)'
    } elseif ($wantMediaPkgSource -and -not [string]::IsNullOrWhiteSpace($driveMediaPackageDir)) {
        $pkgSources = Join-Path $driveMediaPackageDir 'sources'
        $pkgBootWim = Join-Path $pkgSources 'boot.wim'
        if ((Test-Path -LiteralPath $pkgBootWim) -and
            (Get-Command -Name Test-LwPreSplitBootInjected -ErrorAction SilentlyContinue) -and
            (Test-LwPreSplitBootInjected -SetDir $driveMediaPackageDir)) {
            $script:LwBootInjectSourcesDir = $pkgSources
            $bootInjectSourcesDirForWorker = $pkgSources
            EmitLog -Disk 0 -Msg ("{0}: package sources\boot.wim already injected at '{1}' (copy to ESP; skip DISM inject)" -f $resolvedMediaSource, $pkgSources)
        } else {
            EmitLog -Disk 0 -Msg ("{0}: package boot.wim at '{1}' will receive per-disk DISM inject if sentinel missing/stale" -f $resolvedMediaSource, $pkgSources)
        }
    } elseif ($wantMediaPkgSource -and $script:DestageMediaLayout -and
        -not [string]::IsNullOrWhiteSpace($script:DestageMediaLayout.BootInjectRoot)) {
        $biCandidate = Resolve-LwBootInjectSourcesDir -BootInjectRoot $script:DestageMediaLayout.BootInjectRoot -Arch $wfUpper -Edition $winEdition
        $winPeUiExeForBi = Join-Path (Resolve-LwWinPeUiPublishDir -ContentRootPath $ContentRoot -Arch $wfUpper) 'LoneWolf.WinPeUi.exe'
        if ($biCandidate -and (Test-LwBootInjectSentinelCurrent -SourcesDir $biCandidate -StartnetPath $startnetForInjection -DriverDir $arm64UsbDriverDir -WinPeUiExePath $winPeUiExeForBi)) {
            $script:LwBootInjectSourcesDir = $biCandidate
            $bootInjectSourcesDirForWorker = $biCandidate
            EmitLog -Disk 0 -Msg ("{0}: BootInject boot.wim ready at '{1}' (prefer copy; skip DISM inject when sentinel matches)" -f $resolvedMediaSource, $biCandidate)
        } elseif ($biCandidate) {
            EmitLog -Disk 0 -Msg ("{0}: BootInject at '{1}' sentinel mismatch or stale - using package/ISO boot.wim with per-disk DISM inject" -f $resolvedMediaSource, $biCandidate)
        } else {
            EmitLog -Disk 0 -Msg ("{0}: BootInject boot.wim not found for {1} {2} - using package/ISO boot.wim with per-disk DISM inject" -f $resolvedMediaSource, $wfUpper, $winEdition)
        }
    }

    # Build cache (full build needs ESP template for non-ISO WIM path only).
    # ISO / PreferIso / OverlayOnly: USB-bound content goes DIRECT to the stick
    # (ISO→ESP, ISO→data, ContentRoot→overlay) — no LWCache / EspCache / overlay temp.
    # LocalProjectRoot mode uses the same path as network-share mode once $isoDriveLetter
    # / $StagingWim are resolved.
    if ($OverlayOnly) {
        # Overlay-only: worker copies deploy files straight from ContentRoot to existing USB.
        EmitLog -Disk 0 -Msg 'overlay-only: skipping CacheRoot - overlay copies directly from ContentRoot to USB'
        $CacheRoot = ''
        $userProvidedCache = $false
        $espCache = ''
        $overlayCache = ''
    } elseif ($DriveHttpDirect) {
        # HTTP direct: media + boot files land on the stick; never Build-Cache / EspCache.
        # Per-disk inject is skipped only when the downloaded package carries a valid sentinel.
        EmitLog -Disk 0 -Msg 'drive-http: skipping local ESP/overlay cache - package downloads onto USB (no LWCache staging)'
        $CacheRoot = ''
        $userProvidedCache = $false
        $espCache = ''
        $overlayCache = ''
    } elseif (-not [string]::IsNullOrEmpty($isoDriveLetter) -and
              -not [string]::IsNullOrWhiteSpace($bootInjectSourcesDirForWorker)) {
        # Image Ready / ISO folder already has injected boot.wim + sentinel — copy only.
        EmitLog -Disk 0 -Msg 'ISO/media package: pre-injected boot.wim ready - skipping EspCache and per-disk DISM'
        $CacheRoot = ''
        $userProvidedCache = $false
        $espCache = ''
        $overlayCache = ''
    } elseif (-not [string]::IsNullOrEmpty($isoDriveLetter)) {
        # Media package or ISO folder without inject sentinel: inject ONCE into EspCache,
        # then workers copy the template (multi-stick does not redo DISM per disk).
        EmitLog -Disk 0 -Msg 'ISO/media package: no inject sentinel - building EspCache and injecting boot.wim once for all sticks'
        if (-not $userProvidedCache -or [string]::IsNullOrWhiteSpace($CacheRoot)) {
            $CacheRoot = Join-Path $env:TEMP ('LWCache_' + [guid]::NewGuid().ToString('N').Substring(0, 8))
            $userProvidedCache = $false
        }
        $espCache     = Join-Path $CacheRoot 'esp'
        $overlayCache = Join-Path $CacheRoot 'overlay'
        Build-IsoCache -IsoDrive "$isoDriveLetter\"
        $startnetSrc  = $startnetForInjection
        $bootWimPath  = Join-Path $espCache 'sources\boot.wim'
        $wpeOcStaging = Resolve-WpeOcArchRootForInject -PreferredRoot $WpeOcSource -Arch $wfUpper -Log {
            param($m) EmitLog -Disk 0 -Msg $m
        }
        EmitLog -Disk 0 -Msg "startnet inject: resolved WinPE-OCs source for $wfUpper -> '$wpeOcStaging'"
        $winPeUiSrcForInject = Resolve-LwWinPeUiPublishDir -ContentRootPath $ContentRoot -Arch $wfUpper
        $winPeUiExeForSentinel = Join-Path $winPeUiSrcForInject 'LoneWolf.WinPeUi.exe'
        Invoke-StartnetInjection -BootWimPath $bootWimPath -StartnetCmdPath $startnetSrc -WpeOcPath $wpeOcStaging -Arm64UsbDriverDir $arm64UsbDriverDir -WinPeUiSrcDir $winPeUiSrcForInject
        $espSentinel = Join-Path $espCache 'sources\boot.wim.lw-injected'
        $injectedHash = if (Get-Command -Name Get-LwBootWimInjectSentinel -ErrorAction SilentlyContinue) {
            Get-LwBootWimInjectSentinel -StartnetPath $startnetSrc -DriverDir $arm64UsbDriverDir -WinPeUiExePath $winPeUiExeForSentinel
        } else {
            (Get-FileHash -LiteralPath $startnetSrc -Algorithm SHA256 -ErrorAction SilentlyContinue).Hash
        }
        if ($injectedHash) {
            Set-Content -LiteralPath $espSentinel -Value $injectedHash -Encoding ascii -Force -ErrorAction SilentlyContinue
        }
        $script:LwBootInjectSourcesDir = Join-Path $espCache 'sources'
        $bootInjectSourcesDirForWorker = $script:LwBootInjectSourcesDir
        EmitLog -Disk 0 -Msg ("ISO/media package: EspCache inject complete at '{0}' - workers copy template and skip per-disk DISM" -f $bootInjectSourcesDirForWorker)
    } else {
        # Non-ISO staged-WIM / MEDIA-CREATOR: EspCache holds the injected boot.wim template
        # so each USB gets a fast copy instead of per-disk DISM inject. Allocate CacheRoot
        # now (deferred from script top so ISO builds never create LWCache_* litter).
        if (-not $userProvidedCache -or [string]::IsNullOrWhiteSpace($CacheRoot)) {
            $CacheRoot = Join-Path $env:TEMP ('LWCache_' + [guid]::NewGuid().ToString('N').Substring(0, 8))
            $userProvidedCache = $false
        }
        $espCache     = Join-Path $CacheRoot 'esp'
        $overlayCache = Join-Path $CacheRoot 'overlay'

        # Freshness check: if boot.wim was written within the last 4 hours the ESP
        # cache (including the startnet-injected boot.wim) is still valid.  Skip the
        # expensive Build-Cache / Build-IsoCache + Invoke-StartnetInjection step.
        # This only activates when -CacheRoot points to a persistent folder; the
        # default GUID-based temp path is always fresh and always rebuilds.
        # Also require bootmgfw.efi — a cache that has boot.wim but missing bootmgfw
        # (common when staging ISO omitted it and a prior run skipped synthesis) must
        # not be treated as fresh; that produces USB boot 0xc0000098 / missing winload.efi.
        $espBootWim   = Join-Path $espCache 'sources\boot.wim'
        $espBootmgfw  = Join-Path $espCache 'efi\microsoft\boot\bootmgfw.efi'
        $cacheAge     = if (Test-Path -LiteralPath $espBootWim) {
            (Get-Date) - (Get-Item -LiteralPath $espBootWim).LastWriteTime
        } else { $null }
        $cacheIsFresh = $cacheAge -and $cacheAge.TotalHours -lt 4 -and (Test-Path -LiteralPath $espBootmgfw)

        if (-not $cacheIsFresh) {
            if ($useIsoMode) {
                Build-IsoCache -IsoDrive "$isoDriveLetter\"
            } else {
                Build-Cache -StagingWindowsDir $StagingWindowsDir -StagingWim $StagingWim
            }

            $startnetSrc  = $startnetForInjection   # Both modes: Deploy\WinPE-Startnet.cmd from ContentRoot
            $bootWimPath  = Join-Path $espCache 'sources\boot.wim'
            # WinPE-OCs: HQ → Drive HTTPS → ADK (same as per-disk Full Rebuild inject).
            $wpeOcStaging = Resolve-WpeOcArchRootForInject -PreferredRoot $WpeOcSource -Arch $wfUpper -Log {
                param($m) EmitLog -Disk 0 -Msg $m
            }
            EmitLog -Disk 0 -Msg "startnet inject: resolved WinPE-OCs source for $wfUpper -> '$wpeOcStaging'"
            $espSentinel  = Join-Path $espCache 'sources\boot.wim.lw-injected'
            $winPeUiSrcForInject = Resolve-LwWinPeUiPublishDir -ContentRootPath $ContentRoot -Arch $wfUpper
            $winPeUiExeForSentinel = Join-Path $winPeUiSrcForInject 'LoneWolf.WinPeUi.exe'

            # Skip the 8-15 minute DISM injection when boot.wim was pre-injected
            # by _inject-boot-wim.ps1 and the sentinel hash matches the current
            # startnet + WinPeUi content (i.e. unchanged since the last cache build).
            $needsInjection = $true
            if ((Test-Path -LiteralPath $espSentinel) -and (Test-Path -LiteralPath $startnetSrc)) {
                $currentHash  = if (Get-Command -Name Get-LwBootWimInjectSentinel -ErrorAction SilentlyContinue) {
                    Get-LwBootWimInjectSentinel -StartnetPath $startnetSrc -DriverDir $arm64UsbDriverDir -WinPeUiExePath $winPeUiExeForSentinel
                } else {
                    (Get-FileHash -LiteralPath $startnetSrc -Algorithm SHA256).Hash
                }
                $sentinelHash = (Get-Content -LiteralPath $espSentinel -Raw).Trim()
                if ($currentHash -eq $sentinelHash) {
                    # Also verify the sentinel is not older than boot.wim - a sentinel that
                    # predates boot.wim means a new ISO refreshed boot.wim but left the stale
                    # sentinel behind, so injection was incorrectly skipped last build.
                    $bootWimAge  = (Get-Item -LiteralPath $bootWimPath).LastWriteTime
                    $sentinelAge = (Get-Item -LiteralPath $espSentinel).LastWriteTime
                    if ($sentinelAge -lt $bootWimAge) {
                        Write-Warning "startnet inject: sentinel predates boot.wim - re-injecting"
                    } else {
                        EmitLog -Disk 0 -Msg "startnet inject: boot.wim is pre-injected (sentinel matches) - skipping DISM injection"
                        $needsInjection = $false
                    }
                }
            }

            if ($needsInjection) {
                # Inject the custom WinPE startnet.cmd into boot.wim in the ESP cache so
                # that every USB written from this cache automatically launches TechInstall.cmd
                # when WinPE boots.
                Invoke-StartnetInjection -BootWimPath $bootWimPath -StartnetCmdPath $startnetSrc -WpeOcPath $wpeOcStaging -Arm64UsbDriverDir $arm64UsbDriverDir -WinPeUiSrcDir $winPeUiSrcForInject
                # Write sentinel to the ESP cache only so future builds can skip injection.
                # Do NOT write back to staging - the staging boot.wim is always stock and a
                # stale sentinel there would cause injection to be incorrectly skipped after
                # a new ISO refreshes boot.wim but leaves the old sentinel in place.
                $injectedHash = if (Get-Command -Name Get-LwBootWimInjectSentinel -ErrorAction SilentlyContinue) {
                    Get-LwBootWimInjectSentinel -StartnetPath $startnetSrc -DriverDir $arm64UsbDriverDir -WinPeUiExePath $winPeUiExeForSentinel
                } else {
                    (Get-FileHash -LiteralPath $startnetSrc -Algorithm SHA256 -ErrorAction SilentlyContinue).Hash
                }
                if ($injectedHash) {
                    Set-Content -LiteralPath $espSentinel -Value $injectedHash -Encoding ascii -Force -ErrorAction SilentlyContinue
                }
            } else {
                # Emit a log event whose message contains "startnet inject" + "complete"
                # so the builder.js UI updates the WinPE-injection status bar to done.
                EmitLog -Disk 0 -Msg "startnet inject: boot.wim pre-injection complete"
            }
        } else {
            # Cache age is fresh, but startnet / WinPeUi may still have changed — re-inject if sentinel mismatches.
            $bootWimPathFresh = Join-Path $espCache 'sources\boot.wim'
            $startnetSrcFresh = $startnetForInjection
            $espSentinelFresh = Join-Path $espCache 'sources\boot.wim.lw-injected'
            $winPeUiSrcFresh = Resolve-LwWinPeUiPublishDir -ContentRootPath $ContentRoot -Arch $wfUpper
            $winPeUiExeFresh = Join-Path $winPeUiSrcFresh 'LoneWolf.WinPeUi.exe'
            $freshHash = if (Get-Command -Name Get-LwBootWimInjectSentinel -ErrorAction SilentlyContinue) {
                Get-LwBootWimInjectSentinel -StartnetPath $startnetSrcFresh -DriverDir $arm64UsbDriverDir -WinPeUiExePath $winPeUiExeFresh
            } else { '' }
            $cachedFresh = if (Test-Path -LiteralPath $espSentinelFresh) { (Get-Content -LiteralPath $espSentinelFresh -Raw -ErrorAction SilentlyContinue).Trim() } else { '' }
            if ($freshHash -and $freshHash -ne $cachedFresh) {
                EmitLog -Disk 0 -Msg "esp-cache is fresh but inject sentinel changed - re-injecting startnet/WinPeUi"
                $wpeOcFresh = Resolve-WpeOcArchRootForInject -PreferredRoot $WpeOcSource -Arch $wfUpper -Log {
                    param($m) EmitLog -Disk 0 -Msg $m
                }
                Invoke-StartnetInjection -BootWimPath $bootWimPathFresh -StartnetCmdPath $startnetSrcFresh -WpeOcPath $wpeOcFresh -Arm64UsbDriverDir $arm64UsbDriverDir -WinPeUiSrcDir $winPeUiSrcFresh
                Set-Content -LiteralPath $espSentinelFresh -Value $freshHash -Encoding ascii -Force -ErrorAction SilentlyContinue
            } else {
                EmitLog -Disk 0 -Msg "esp-cache is fresh (age: $([math]::Round($cacheAge.TotalMinutes)) min) - skipping rebuild"
            }
        }
        # Overlay for WIM-mode sticks is applied direct from ContentRoot in the
        # per-disk worker (no USB-bound overlay temp stage). EspCache remains for the
        # injected boot.wim template only.
        $overlayCache = ''
    }

    if ($PreCacheOnly) {
        Emit @{ event='done'; disk=0; success=$true; message='Pre-cache complete' }
        exit 0
    }

    # Validate disk numbers
    $validDisks = @(Get-Disk -ErrorAction SilentlyContinue)
    $validNums  = $validDisks | Select-Object -ExpandProperty Number
    $badNums    = $requestedDisks | Where-Object { $_ -notin $validNums }
    if ($badNums.Count -gt 0) {
        Emit @{ event='error'; disk=-1; message="Disk(s) not found: $($badNums -join ', ')" }
        exit 1
    }

    # -------------------------------------------------------------------------
    # Shared WIM mount (WIM mode only) — one read-only DISM mount for all disks
    # -------------------------------------------------------------------------
    # Concurrent DISM /Mount-Image from parallel Start-Jobs serializes or fails.
    # Mount once on the main thread; Phase 1 jobs robocopy from the shared path.
    if (-not $OverlayOnly -and -not $useIsoMode -and [string]::IsNullOrEmpty($isoDriveLetter) -and
        -not [string]::IsNullOrEmpty($StagingWim) -and (Test-Path -LiteralPath $StagingWim)) {
        try {
            $sharedWimWorkDir = Join-Path $env:TEMP ('LW-WimShared-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
            $sharedLocalWim   = Join-Path $sharedWimWorkDir 'staging.wim'
            $sharedWimMount   = Join-Path $sharedWimWorkDir 'mount'
            New-Item -ItemType Directory -Path $sharedWimWorkDir -Force | Out-Null
            New-Item -ItemType Directory -Path $sharedWimMount   -Force | Out-Null

            # Prefer mounting the staging WIM DIRECTLY from its share path (read-only) so we
            # skip the full multi-GB copy to %TEMP% before the shared mount. If the direct
            # mount throws, fall back to the proven copy-to-temp-then-mount. Either way the
            # mount dir stays under %TEMP% and the outer catch + finally cleanup is unchanged.
            $sharedDirectOk = $false
            try {
                EmitLog -Disk 0 -Msg "wim-shared: mounting staging WIM directly from share (read-only) -> $sharedWimMount"
                $sharedMountOut = & dism.exe /Mount-Image /ImageFile:"$StagingWim" /Index:1 /MountDir:"$sharedWimMount" /ReadOnly 2>&1
                if ($LASTEXITCODE -ne 0) {
                    throw "Shared DISM /Mount-Image (direct share) failed (exit $LASTEXITCODE): $($sharedMountOut -join '; ')"
                }
                $sharedDirectOk = $true
                EmitLog -Disk 0 -Msg 'wim-shared: direct share mount ready (no local copy) — Phase 1 will run parallel robocopy to each USB'
            } catch {
                EmitLog -Disk 0 -Msg "wim-shared: direct share mount failed ($($_.Exception.Message)); falling back to copy-to-temp then mount"
                & dism.exe /Unmount-Image /MountDir:"$sharedWimMount" /Discard 2>&1 | Out-Null
            }

            if (-not $sharedDirectOk) {
                $sharedParent = Split-Path -Parent $StagingWim
                $sharedLeaf = Split-Path -Leaf $StagingWim
                if ([string]::IsNullOrWhiteSpace($sharedParent) -or [string]::IsNullOrWhiteSpace($sharedLeaf)) {
                    throw "Shared WIM local copy: StagingWim path is invalid ('$StagingWim')"
                }
                EmitLog -Disk 0 -Msg "wim-shared: copying WIM to local temp for shared mount ($sharedLocalWim)..."
                $sharedCopy = & robocopy.exe $sharedParent $sharedWimWorkDir $sharedLeaf /R:1 /W:2 /NP /NJH /NJS /J 2>&1
                if ($LASTEXITCODE -ge 8) {
                    throw "Shared WIM local copy failed (exit $LASTEXITCODE): $($sharedCopy -join '; ')"
                }
                if ($sharedLeaf -ne 'staging.wim') {
                    Rename-Item -LiteralPath (Join-Path $sharedWimWorkDir $sharedLeaf) -NewName 'staging.wim' -Force
                }

                EmitLog -Disk 0 -Msg "wim-shared: mounting read-only -> $sharedWimMount (all Phase 1 jobs will robocopy from here)"
                $sharedMountOut = & dism.exe /Mount-Image /ImageFile:"$sharedLocalWim" /Index:1 /MountDir:"$sharedWimMount" /ReadOnly 2>&1
                if ($LASTEXITCODE -ne 0) {
                    throw "Shared DISM /Mount-Image failed (exit $LASTEXITCODE): $($sharedMountOut -join '; ')"
                }
                EmitLog -Disk 0 -Msg 'wim-shared: mount ready — Phase 1 will run parallel robocopy to each USB'
            }
        } catch {
            EmitLog -Disk 0 -Msg "WARNING: shared WIM mount failed ($($_.Exception.Message)); falling back to per-disk mounts (may serialize)"
            if (-not [string]::IsNullOrEmpty($sharedWimMount)) {
                & dism.exe /Unmount-Image /MountDir:"$sharedWimMount" /Discard 2>&1 | Out-Null
            }
            if (-not [string]::IsNullOrEmpty($sharedWimWorkDir) -and (Test-Path -LiteralPath $sharedWimWorkDir)) {
                Remove-Item -LiteralPath $sharedWimWorkDir -Recurse -Force -ErrorAction SilentlyContinue
            }
            $sharedWimWorkDir = ''
            $sharedWimMount   = ''
        }
    }

    # -------------------------------------------------------------------------
    # Per-disk end-to-end jobs (true parallel across disks)
    # -------------------------------------------------------------------------
    # Each Start-Job runs wipe → ESP → DISM/data → WinPE inject (that USB's
    # boot.wim) → overlay → BCD → done. No global barrier between "Phase 1" and
    # "Phase 2": Disk A can inject WinPE while Disk B is still in DISM.
    # Shared staging WIM / ISO mounts stay on this thread until all jobs finish.
    $succeeded    = [System.Collections.Generic.List[int]]::new()
    $failed       = [System.Collections.Generic.List[int]]::new()
    $diskJobs     = @()
    # WinPE-OCs for per-disk inject: HQ → Drive HTTPS → ADK. Resolved on the main
    # thread (job runspace cannot call these helpers) and passed into each job.
    $wpeOcStaging = Resolve-WpeOcArchRootForInject -PreferredRoot $WpeOcSource -Arch $wfUpper -Log {
        param($m) EmitLog -Disk 0 -Msg $m
    }
    if ([string]::IsNullOrWhiteSpace($wpeOcStaging) -or -not (Test-Path -LiteralPath $wpeOcStaging)) {
        Emit @{
            event   = 'error'
            disk    = -1
            message = "FATAL: WinPE-OCs\$wfUpper not resolved (got '$wpeOcStaging'). Reach HQ, the public Drive WinPE-OCs folder, or install the ADK WinPE optional components."
        }
        exit 1
    }
    EmitLog -Disk 0 -Msg "WinPE-OCs for $wfUpper inject -> '$wpeOcStaging'"

    # Resolve the pre-split fast-copy set ONCE (ISO mode + Single layout only). '' when no
    # valid, matching staged set exists -> each disk job falls back to the on-the-fly split
    # (control flow + output byte-identical to before this feature). Never fatal.
    $PreSplitSetDir = ''
    if ($useIsoMode -and $Layout -eq 'Single' -and -not $OverlayOnly) {
        if (-not [string]::IsNullOrWhiteSpace($driveMediaPackageDir) -and
            (Get-Command -Name Test-LWPreSplitSet -ErrorAction SilentlyContinue)) {
            $pkgChk = Test-LWPreSplitSet -SetDir $driveMediaPackageDir -VerifyHash:$VerifyPreSplitHash
            if ($pkgChk.Valid) {
                $PreSplitSetDir = $driveMediaPackageDir
                EmitLog -Disk 0 -Msg "googleDrive: pre-split install*.swm will fast-copy from '$PreSplitSetDir'"
            } else {
                EmitLog -Disk 0 -Msg "googleDrive: media package set rejected for SWM fast-copy ($($pkgChk.Reason)) - worker may fall back to on-the-fly split"
            }
        } elseif ($null -ne $isoItem) {
            if ($DestageMedia) {
                EmitLog -Disk 0 -Msg "destage: resolving pre-split set under local UUP '$PreSplitRoot'"
            }
            $resolvedSet = Get-LWPreSplitSet -Iso $isoItem -PreSplitRoot $PreSplitRoot -Arch $wfUpper -Edition $winEdition -VerifyHash:$VerifyPreSplitHash
            if ($resolvedSet) { $PreSplitSetDir = $resolvedSet }
        }
    }

    # Windows image identity = PreSplit / Image Ready folder name (imageVersionId).
    # imageBuildDate is the calendar day from that stamp (legacy key for older readers).
    $imageVersion = ''
    if (-not [string]::IsNullOrWhiteSpace($PreSplitSetDir)) {
        try { $imageVersion = [string](Split-Path -Leaf $PreSplitSetDir) } catch { }
        try {
            $pkgManifest = Join-Path $PreSplitSetDir 'presplit-manifest.json'
            if (Test-Path -LiteralPath $pkgManifest) {
                $pmIv = Get-Content -Raw -LiteralPath $pkgManifest -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                if ($pmIv.PSObject.Properties['imageVersion'] -and $pmIv.imageVersion) {
                    $imageVersion = [string]$pmIv.imageVersion
                }
            }
        } catch { }
    } elseif ($isoItem -and (Get-Command -Name Get-LWImageVersionId -ErrorAction SilentlyContinue)) {
        try { $imageVersion = [string](Get-LWImageVersionId -Iso $isoItem -Edition $winEdition) } catch { }
    } elseif (-not [string]::IsNullOrWhiteSpace($driveMediaPackageDir)) {
        try { $imageVersion = [string](Split-Path -Leaf $driveMediaPackageDir) } catch { }
    }

    # Canonical imageBuildDate: remote version.json / set current / staging UTC day.
    # Never trust raw ISO LastWrite alone (UUP media often carries 2024-04-01).
    $imageBuildDate = ''
    $imageUpdatedUtc = ''
    $setDirForStamp = $(if (-not [string]::IsNullOrWhiteSpace($PreSplitSetDir)) { $PreSplitSetDir } else { $driveMediaPackageDir })
    if (-not [string]::IsNullOrWhiteSpace($PreSplitRoot) -and (Get-Command -Name Read-LWRemoteVersionSku -ErrorAction SilentlyContinue)) {
        try {
            $remoteSku = Read-LWRemoteVersionSku -PreSplitRoot $PreSplitRoot -Arch $wfUpper -Edition $winEdition
            if ($remoteSku) {
                if (-not $imageVersion -and $remoteSku.imageVersion) { $imageVersion = [string]$remoteSku.imageVersion }
                if ($remoteSku.imageBuildDate) { $imageBuildDate = [string]$remoteSku.imageBuildDate }
                if ($remoteSku.updatedUtc) { $imageUpdatedUtc = [string]$remoteSku.updatedUtc }
            }
        } catch { }
    }
    if (-not [string]::IsNullOrWhiteSpace($setDirForStamp)) {
        try {
            foreach ($markerLeaf in @('current', 'presplit-manifest.json')) {
                $markerPath = Join-Path $setDirForStamp $markerLeaf
                if (-not (Test-Path -LiteralPath $markerPath)) { continue }
                $mj = Get-Content -Raw -LiteralPath $markerPath -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                if (-not $imageVersion -and $mj.PSObject.Properties['imageVersion'] -and $mj.imageVersion) {
                    $imageVersion = [string]$mj.imageVersion
                }
                if (-not $imageUpdatedUtc) {
                    if ($mj.PSObject.Properties['updatedUtc'] -and $mj.updatedUtc) {
                        $imageUpdatedUtc = [string]$mj.updatedUtc
                    } elseif ($mj.PSObject.Properties['createdUtc'] -and $mj.createdUtc) {
                        $imageUpdatedUtc = [string]$mj.createdUtc
                    }
                }
                if (-not $imageBuildDate -and $mj.PSObject.Properties['imageBuildDate'] -and $mj.imageBuildDate) {
                    $imageBuildDate = [string]$mj.imageBuildDate
                }
            }
        } catch { }
    }
    if ($imageVersion -and (Get-Command -Name Get-LWCanonicalImageBuildDateYmd -ErrorAction SilentlyContinue)) {
        $healed = [string](Get-LWCanonicalImageBuildDateYmd -ImageVersion $imageVersion -UpdatedUtc $imageUpdatedUtc -ExplicitBuildDate $imageBuildDate)
        if ($healed) { $imageBuildDate = $healed }
    } elseif (-not $imageBuildDate -and $imageVersion -and (Get-Command -Name Get-LWImageVersionBuildDateYmd -ErrorAction SilentlyContinue)) {
        $imageBuildDate = [string](Get-LWImageVersionBuildDateYmd -ImageVersion $imageVersion)
    }
    if (-not $imageBuildDate -and -not [string]::IsNullOrWhiteSpace($setDirForStamp)) {
        try { $imageBuildDate = (Get-Item -LiteralPath $setDirForStamp).LastWriteTimeUtc.ToString('yyyy-MM-dd') } catch { }
    } elseif (-not $imageBuildDate -and -not $OverlayOnly -and -not [string]::IsNullOrWhiteSpace($StagingWim) -and (Test-Path -LiteralPath $StagingWim)) {
        try { $imageBuildDate = (Get-Item -LiteralPath $StagingWim).LastWriteTimeUtc.ToString('yyyy-MM-dd') } catch { }
    }
    if ($imageVersion) {
        EmitLog -Disk 0 -Msg ("image-identity: imageVersion={0} imageBuildDate={1} edition={2}" -f $imageVersion, $imageBuildDate, $winEdition)
    }

    $edgeToolsDir = Join-Path ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))) 'tools'
    # ARM64 drivers are injected into boot.wim only. $arm64InstallImageDir stays empty.

    # Warm WinPeUi (local trees or GitHub bin/ zips) before per-disk overlay / boot inject.
    # Packaged builds may download ~60-130 MB with no USB phase yet — emit disk-0 progress
    # so the UI is not stuck on Waiting 0%. OverlayOnly only needs the workflow arch.
    try {
        $uiArches = if ($OverlayOnly) {
            @($(if ($wfUpper -match 'ARM') { 'ARM64' } else { 'AMD64' }))
        } else {
            @('AMD64', 'ARM64')
        }
        Emit @{ event = 'progress'; disk = 0; phase = 'winpe-ui'; pct = 0; message = 'Preparing WinPE UI...' }
        Ensure-LwWinPeUiForBuild -Arches $uiArches
        Emit @{ event = 'progress'; disk = 0; phase = 'winpe-ui'; pct = 100; message = 'WinPE UI ready' }
    } catch {
        EmitLog -Disk 0 -Msg ("WinPeUi ensure: {0}" -f $_.Exception.Message)
    }

    $installLcuKb = ''
    $osBuildStamp = ''
    $lcuRefreshSetDir = ''
    $lcuImageVersion = ''
    $lcuImageBuildDate = ''
    $lcuPreRoot = ''
    if ($OverlayOnly -and (Get-Command -Name Get-LwDestageUupLayout -ErrorAction SilentlyContinue)) {
        try { $lcuPreRoot = [string](Get-LwDestageUupLayout).PreSplitRoot } catch { }
    } elseif (-not [string]::IsNullOrWhiteSpace($PreSplitRoot)) {
        $lcuPreRoot = [string]$PreSplitRoot
    }
    if ($lcuPreRoot -and (Get-Command -Name Read-LWRemoteVersionSku -ErrorAction SilentlyContinue)) {
        try {
            $lcuSku = Read-LWRemoteVersionSku -PreSplitRoot $lcuPreRoot -Arch $wfUpper -Edition $winEdition
            if ($lcuSku) {
                if ($lcuSku.installLcuKb) { $installLcuKb = [string]$lcuSku.installLcuKb }
                if ($lcuSku.osBuild) { $osBuildStamp = [string]$lcuSku.osBuild }
                if ($lcuSku.imageVersion) {
                    $lcuImageVersion = [string]$lcuSku.imageVersion
                    $cand = Join-Path $lcuPreRoot $lcuImageVersion
                    $swm = Join-Path $cand 'sources\install.swm'
                    if (Test-Path -LiteralPath $swm) { $lcuRefreshSetDir = $cand }
                }
                if ($lcuSku.imageBuildDate) { $lcuImageBuildDate = [string]$lcuSku.imageBuildDate }
            }
        } catch { }
    }
    if (-not $OverlayOnly -and -not [string]::IsNullOrWhiteSpace($PreSplitSetDir)) {
        $lcuRefreshSetDir = ''
        try {
            $manPath = Join-Path $PreSplitSetDir 'presplit-manifest.json'
            if (Test-Path -LiteralPath $manPath) {
                $man = Get-Content -Raw -LiteralPath $manPath | ConvertFrom-Json
                if ($man.installLcuKb) { $installLcuKb = [string]$man.installLcuKb }
                if ($man.osBuild) { $osBuildStamp = [string]$man.osBuild }
            }
        } catch { }
    }
    if ($OverlayOnly -and $lcuRefreshSetDir) {
        EmitLog -Disk 0 -Msg ("lcu: Quick Update can refresh install*.swm from '$lcuRefreshSetDir' ($installLcuKb)")
    }

    foreach ($diskNum in $requestedDisks) {
        EmitStart -Disk $diskNum
        if ($Sequential) {
            EmitLog -Disk $diskNum -Msg 'sequential mode: draining this disk end-to-end before starting the next'
        }
        $diskJob = Start-Job -Name "LW-Disk${diskNum}" -ScriptBlock $workerDiskBlock `
            -ArgumentList @(
                $diskNum,
                $espCache,
                $StagingWim,
                $espPartitionBytes,
                ([bool]$OverlayOnly),
                $DataVolumeLabel,
                $isoDriveLetter,
                ([bool]$NoPayload),
                $sharedWimMount,
                $overlayCache,
                $startnetForInjection,
                $wpeOcStaging,
                $ContentRoot,
                $WorkflowType,
                $stagingVersion,
                $Layout,
                ([bool]$QuickInstall),
                $SplitLibPath,
                $PreSplitSetDir,
                ([bool]$DevBuild),
                $LauncherVersion,
                $ScriptVersion,
                $ShareLauncherVersion,
                $ShareScriptVersion,
                $imageBuildDate,
                $imageVersion,
                $winEdition,
                $edgeToolsDir,
                ([bool]($DevBuild -and $DestageSkipWu)),
                $arm64UsbDriverDir,
                $Arm64DriverLibPath,
                $arm64InstallImageDir,
                $UsbOverlayLibPath,
                $bootInjectSourcesDirForWorker,
                ([bool]$DriveHttpDirect),
                $DriveHttpFolderId,
                $DriveHttpLibPath,
                $script:LwWinPeUiCacheRoot,
                $LcuLibPath,
                $lcuRefreshSetDir,
                $installLcuKb,
                $osBuildStamp,
                $lcuImageVersion,
                $lcuImageBuildDate
            )

        if ($Sequential) {
            # Sequential mode: drain this disk fully before the next.
            do {
                $out = Receive-Job $diskJob -ErrorAction SilentlyContinue
                foreach ($line in @($out)) {
                    $line = [string]$line
                    if ($line.TrimStart().StartsWith('{')) { Write-Output $line }
                }
                if ($diskJob.State -eq 'Running') { Start-Sleep -Milliseconds 300 }
            } until ($diskJob.State -ne 'Running')
            $out = Receive-Job $diskJob -ErrorAction SilentlyContinue
            foreach ($line in @($out)) {
                $line = [string]$line
                if ($line.TrimStart().StartsWith('{')) { Write-Output $line }
            }
            if ($diskJob.State -eq 'Completed') {
                $succeeded.Add($diskNum)
            } else {
                $failed.Add($diskNum)
                foreach ($cj in @($diskJob.ChildJobs)) {
                    foreach ($err in @($cj.Error)) { EmitError -Disk $diskNum -Msg $err.ToString() }
                }
            }
            Remove-Job $diskJob -Force -ErrorAction SilentlyContinue
        } else {
            $diskJobs += [pscustomobject]@{ Disk = $diskNum; Job = $diskJob; Done = $false }
        }
    }

    # Poll parallel disk jobs and forward JSON events (no-op in sequential mode)
    $jobsRemaining = $diskJobs.Count
    while ($jobsRemaining -gt 0) {
        foreach ($j in $diskJobs) {
            if ($j.Done) { continue }
            $out = Receive-Job -Job $j.Job -Keep:$false -ErrorAction SilentlyContinue
            foreach ($line in @($out)) {
                $line = [string]$line
                if ($line.TrimStart().StartsWith('{')) { Write-Output $line }
            }
            if ($j.Job.State -notin @('Running','NotStarted')) {
                $tail = Receive-Job -Job $j.Job -ErrorAction SilentlyContinue
                foreach ($line in @($tail)) {
                    $line = [string]$line
                    if ($line.TrimStart().StartsWith('{')) { Write-Output $line }
                }
                if ($j.Job.State -eq 'Completed') {
                    $succeeded.Add($j.Disk)
                } else {
                    $failed.Add($j.Disk)
                    foreach ($cj in @($j.Job.ChildJobs)) {
                        foreach ($err in @($cj.Error)) { EmitError -Disk $j.Disk -Msg $err.ToString() }
                    }
                }
                Remove-Job -Job $j.Job -Force -ErrorAction SilentlyContinue
                $j.Done = $true
                $jobsRemaining--
            }
        }
        if ($jobsRemaining -gt 0) { Start-Sleep -Milliseconds 1800 }
    }

    EmitSummary -Succeeded @($succeeded) -Failed @($failed)

    if ($failed.Count -gt 0) { exit 1 }

} catch {
    Emit @{ event='error'; disk=-1; message=$_.Exception.Message }
    exit 1
} finally {
    if (-not [string]::IsNullOrWhiteSpace($arm64InstallWorkDir) -and (Test-Path -LiteralPath $arm64InstallWorkDir -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $arm64InstallWorkDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    # Dismount shared WIM mount (must happen after all Phase 1 jobs complete).
    if (-not [string]::IsNullOrEmpty($sharedWimMount)) {
        & dism.exe /Unmount-Image /MountDir:"$sharedWimMount" /Discard 2>&1 | Out-Null
    }
    if (-not [string]::IsNullOrEmpty($sharedWimWorkDir) -and (Test-Path -LiteralPath $sharedWimWorkDir -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $sharedWimWorkDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    # Kill the dismount race: the ISO is a single network-backed mount shared by all
    # parallel per-disk robocopy workers. The normal parallel poll loop above only
    # exits once every disk job has left Running, but if the try block exited early
    # (an error before the loop drained) a LW-Disk job could still be reading from the
    # mount. Dismounting then would yank the source mid-copy (the exit-11 "some files
    # could not be copied" symptom). Wait for any straggler disk jobs before dismount.
    $isoStragglers = @(Get-Job -Name 'LW-Disk*' -ErrorAction SilentlyContinue |
        Where-Object { $_.State -in @('Running','NotStarted') })
    if ($isoStragglers.Count -gt 0) {
        Wait-Job -Job $isoStragglers -ErrorAction SilentlyContinue | Out-Null
    }
    # Dismount ISO if we mounted it (only after all jobs complete, per the wait above).
    # Mount was against the ISO's UNC/share path directly (no local copy), so dismount
    # that same share path. No local temp/cache ISO exists to delete.
    if ($null -ne $isoDiskImage) {
        Dismount-DiskImage -ImagePath $isoItem.FullName -ErrorAction SilentlyContinue | Out-Null
        Remove-LwMountedIso -Path $isoItem.FullName
    }
    if (-not $userProvidedCache -and -not [string]::IsNullOrWhiteSpace($CacheRoot) -and
        (Test-Path -LiteralPath $CacheRoot -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $CacheRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    # $noPayloadStartnetTempPath is always empty (WIN-INSTALL now uses WinPE-Startnet.cmd directly; no temp file created).
    if (-not [string]::IsNullOrEmpty($noPayloadStartnetTempPath) -and
        (Test-Path -LiteralPath $noPayloadStartnetTempPath -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $noPayloadStartnetTempPath -Force -ErrorAction SilentlyContinue
    }
    if (-not [string]::IsNullOrWhiteSpace($script:DriveHttpSupportRoot) -and
        (Test-Path -LiteralPath $script:DriveHttpSupportRoot -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $script:DriveHttpSupportRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    # Best-effort orphan sweep (success, failure, and cancel-via-exit all reach finally;
    # hard-kill is covered by -DismountOnly + next build-start sweep).
    Invoke-LwTempOrphanSweep -Reason 'build-end' -IncludeCache
}
