<#
.SYNOPSIS
  Shared FAT32 install-image split helper for Project LoneWolf.

.DESCRIPTION
  Dot-sourced by BOTH the USB builder (Invoke-LoneWolfBuild.ps1, inside its
  per-disk Start-Job runspace) and the pre-split producer (Stage-PreSplitImage.ps1).
  Keeping the split body in exactly one place guarantees the on-the-fly build
  fallback and the pre-staged .swm set are byte-identical (same span rule, same
  /CheckIntegrity, same ESD-export path, same chunk naming).

  This file defines FUNCTIONS ONLY - no top-level executable code - so it is safe
  to dot-source directly (`. .\lib\Split-LWImage.ps1`) and inside a background job
  runspace (which cannot see script-scope functions of the parent).

  Exposed functions:
    Split-LWImageForFat32   - port of the builder's original Split-LWInstallImageForFat32
    Get-LWImageVersionId    - stable image-version identity derived from a source ISO
    Get-LWImageVersionBuildDateYmd / Get-LWCanonicalImageBuildDateYmd
    Get-LWWindowsEdition    - Home | Pro (default Pro)
    Get-LWBareArch          - AMD64/ARM64 with workflow prefixes stripped
    Find-LWWindowsIso       - newest ISO for arch + SKU (flat ISO\ with home/pro in the name;
                              legacy ISO\Home, ISO\Pro, and untagged Pro files still read).
                              Optional FallbackIsoRoot is used only when the share IsoRoot
                              has no matching file (destage UUP ISO folder).
    Get-LWPreSplitScanDirs  - PreSplit\ (new) then legacy PreSplit\<ARCH>\<SKU>\
                              (Pro also: PreSplit\<ARCH>\)
    Get-LWPreSplitCandidateDirs / Write-LWPreSplitCurrentMarkers / Write-LWRemoteVersionJson
#>

# ---------------------------------------------------------------------------
# Get-LWFat32SplitPlan
#   Shared /FileSize rule for the producer and the builder fallback.
#   DISM /Split-Image returns error 87 when /FileSize is >= the image, and
#   /FileSize is the maximum size of each SWM.
#     * image larger than the cap (default 3800 MB): keep /FileSize at the cap
#     * image at or under the cap, and at least 512 MiB:
#         span = min(cap, ceil(imageBytes / 2 / 1MB))
#       That is the smallest whole MB at or above half the image, so DISM
#       writes two chunks. floor(imageMiB / 2) is short of half when the
#       byte length is not an even number of MiB and spills a third fragment.
#       The span stays strictly below the image and under the FAT32 4 GB limit.
#     * image under 512 MiB: copy one file
# ---------------------------------------------------------------------------
function Get-LWFat32SplitPlan {
    param(
        [Parameter(Mandatory)] [long] $LengthBytes,
        [int] $FileSizeMb = 3800
    )
    $capMb = $FileSizeMb
    if ($capMb -lt 1) { $capMb = 3800 }
    $tinyBytes = [long]512MB
    $capBytes  = [long]$capMb * 1MB
    $imageMiB  = [long][math]::Floor($LengthBytes / 1MB)
    if ($LengthBytes -lt $tinyBytes) {
        return [pscustomobject]@{ Split = $false; FileSizeMb = $capMb; ImageMiB = $imageMiB }
    }
    if ($LengthBytes -gt $capBytes) {
        $spanMb = $capMb
    } else {
        $spanMb = [int][math]::Ceiling($LengthBytes / [double](2MB))
        if ($spanMb -gt $capMb) { $spanMb = $capMb }
        if ($spanMb -lt 1) { $spanMb = 1 }
    }
    if (([long]$spanMb * 1MB) -ge $LengthBytes) {
        throw "wim-split: refused /FileSize:$spanMb MB; it is not strictly smaller than the $LengthBytes-byte image"
    }
    return [pscustomobject]@{ Split = $true; FileSizeMb = [int]$spanMb; ImageMiB = $imageMiB }
}

# ---------------------------------------------------------------------------
# Split-LWImageForFat32
#   Place the install image on a FAT32 destination as install*.swm chunks.
#   Images at or above 512 MiB are split with Get-LWFat32SplitPlan (two or
#   more install*.swm files). Images under 512 MiB are copied as one file.
#   install.esd that must be split is exported (index 1, /Compress:recovery
#   /CheckIntegrity) to a temp WIM, then split with the same plan. If a split
#   was required and fewer than two SWM chunks appear, this throws.
#
#   $Emit, when supplied, receives each log line (a single string) so the caller
#   can wrap it into its own JSON event shape; otherwise lines go to Write-Output.
# ---------------------------------------------------------------------------
function Split-LWImageForFat32 {
    param(
        [Parameter(Mandatory)] [string] $SourceSourcesDir,
        [Parameter(Mandatory)] [string] $DestSourcesDir,
        [int] $FileSizeMb = 3800,
        [scriptblock] $Emit,
        [scriptblock] $Progress
    )

    # Local log shim: route to $Emit when provided, else Write-Output.
    $log = {
        param([string]$Message)
        if ($Emit) { & $Emit $Message } else { Write-Output $Message }
    }

    # Local progress shim: route an integer percentage to $Progress when supplied,
    # else silently no-op. Callers opt in by passing -Progress; without it the split
    # runs the original synchronous DISM call and stays byte-for-byte unchanged.
    $prog = {
        param([int]$p)
        if ($Progress) { & $Progress $p }
    }

    $fat32Max = [long](4GB - 1)
    New-Item -ItemType Directory -Force -Path $DestSourcesDir -ErrorAction SilentlyContinue | Out-Null
    $srcWim = Join-Path $SourceSourcesDir 'install.wim'
    $srcEsd = Join-Path $SourceSourcesDir 'install.esd'

    if (Test-Path -LiteralPath $srcWim) {
        $len = (Get-Item -LiteralPath $srcWim).Length
        $plan = Get-LWFat32SplitPlan -LengthBytes $len -FileSizeMb $FileSizeMb
        if (-not $plan.Split) {
            Copy-Item -LiteralPath $srcWim -Destination (Join-Path $DestSourcesDir 'install.wim') -Force
            & $log ("wim-split: install.wim {0:N2} GB is under 512 MB. Copied as install.wim." -f ($len / 1GB))
            & $prog 100
        } else {
            $spanMb = [int]$plan.FileSizeMb
            & $log ("wim-split: install.wim {0:N2} GB - splitting into install.swm with /FileSize:{1} MB" -f ($len / 1GB), $spanMb)
            Get-ChildItem -LiteralPath $DestSourcesDir -Filter 'install*.swm' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
            $swm = Join-Path $DestSourcesDir 'install.swm'
            # /CheckIntegrity (5.1.55): validates the source WIM's resource hashes while
            # splitting AND writes an integrity table into every produced .swm, so the
            # deploy-side "dism /Apply-Image /CheckIntegrity" can actually detect a chunk
            # that rotted on the FAT32 stick. Without it a bit-damaged .swm applies a
            # right-size / wrong-content winload.efi that passes the pre-seal size gate
            # and only surfaces as 0xc000000f on the device's first boot.
            if ($Progress) {
                # Opt-in live progress: run DISM asynchronously so we can poll the
                # growing install*.swm bytes on the FAT32 volume against the source
                # WIM length. Same flags / same output as the synchronous branch.
                $g       = [guid]::NewGuid().ToString('N')
                $outFile = Join-Path $env:TEMP ("LW-Split-$g.out")
                $errFile = Join-Path $env:TEMP ("LW-Split-$g.err")
                try {
                    # Quote path values after the colon. Start-Process ArgumentList does not
                    # reliably quote embedded spaces (e.g. "Project Keyes"), and DISM then
                    # fails command-line validation ("could not recognize" / Error validating).
                    $proc = Start-Process dism.exe -ArgumentList @(
                        '/Split-Image',
                        "/ImageFile:`"$srcWim`"",
                        "/SWMFile:`"$swm`"",
                        "/FileSize:$spanMb",
                        '/CheckIntegrity'
                    ) -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
                    # Retain the process handle NOW. Without this reference .NET releases the
                    # handle when DISM exits and $proc.ExitCode comes back $null, which was
                    # misread as a failure ("failed (exit ):") even though DISM reported
                    # "The operation completed successfully." Reading .Handle keeps it alive.
                    $null = $proc.Handle
                    while (-not $proc.HasExited) {
                        Start-Sleep -Seconds 1
                        try {
                            $done = (Get-ChildItem -LiteralPath $DestSourcesDir -Filter 'install*.swm' -ErrorAction SilentlyContinue |
                                Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                            if (-not $done) { $done = 0 }
                            & $prog ([math]::Min(99, [int](100 * $done / [math]::Max($len, 1))))
                        } catch { }
                    }
                    $proc.WaitForExit()
                    $exit = $proc.ExitCode
                    $cap = ''
                    if (Test-Path -LiteralPath $outFile) { $cap += (Get-Content -Raw -LiteralPath $outFile -ErrorAction SilentlyContinue) }
                    if (Test-Path -LiteralPath $errFile) { $cap += (Get-Content -Raw -LiteralPath $errFile -ErrorAction SilentlyContinue) }
                    $splitOk = ($exit -eq 0) -or (($null -eq $exit) -and ($cap -match 'The operation completed successfully'))
                    if (-not $splitOk) {
                        throw "DISM /Split-Image (install.wim) failed (exit $exit): $cap"
                    }
                } finally {
                    Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
                    Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
                }
                & $prog 100
            } else {
                $o = & dism.exe /Split-Image /ImageFile:"$srcWim" /SWMFile:"$swm" /FileSize:$spanMb /CheckIntegrity 2>&1
                if ($LASTEXITCODE -ne 0) { throw "DISM /Split-Image (install.wim) failed (exit $LASTEXITCODE): $($o -join ' | ')" }
            }
            Remove-Item -LiteralPath (Join-Path $DestSourcesDir 'install.wim') -Force -ErrorAction SilentlyContinue
            if (-not (Test-Path -LiteralPath $swm)) { throw "wim-split: install.swm was not produced on the FAT32 volume" }
            $chunks = @(Get-ChildItem -LiteralPath $DestSourcesDir -Filter 'install*.swm' -ErrorAction SilentlyContinue)
            if ($chunks.Count -lt 2) {
                throw ("wim-split: install.wim is {0:N2} GB and /FileSize:{1} MB requires at least 2 SWM chunks, but only {2} .swm file was produced" -f ($len / 1GB), $spanMb, $chunks.Count)
            }
            & $log ("wim-split: produced {0} .swm chunk(s); monolithic install.wim omitted from FAT32 volume" -f $chunks.Count)
        }
    } elseif (Test-Path -LiteralPath $srcEsd) {
        $len = (Get-Item -LiteralPath $srcEsd).Length
        $plan = Get-LWFat32SplitPlan -LengthBytes $len -FileSizeMb $FileSizeMb
        if (-not $plan.Split) {
            Copy-Item -LiteralPath $srcEsd -Destination (Join-Path $DestSourcesDir 'install.esd') -Force
            & $log ("wim-split: install.esd {0:N2} GB is under 512 MB. Copied as install.esd." -f ($len / 1GB))
            & $prog 100
        } else {
            & $log ("wim-split: install.esd {0:N2} GB - exporting to WIM then splitting" -f ($len / 1GB))
            $exportedLen = 0
            $placedWim = $false
            $work = Join-Path $env:TEMP ('LW-EsdSplit-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
            New-Item -ItemType Directory -Force -Path $work | Out-Null
            try {
                $tmpWim = Join-Path $work 'install_export.wim'
                # /CheckIntegrity on the export as well (5.1.55): it seeds the intermediate
                # WIM with an integrity table, which is what /Split-Image /CheckIntegrity
                # below verifies and propagates into the .swm chunks.
                $o = & dism.exe /Export-Image /SourceImageFile:"$srcEsd" /SourceIndex:1 /DestinationImageFile:"$tmpWim" /Compress:recovery /CheckIntegrity 2>&1
                if ($LASTEXITCODE -ne 0) { throw "DISM /Export-Image (esd->wim) failed (exit $LASTEXITCODE): $($o -join ' | ')" }
                $exportedLen = (Get-Item -LiteralPath $tmpWim).Length
                $exportPlan = Get-LWFat32SplitPlan -LengthBytes $exportedLen -FileSizeMb $FileSizeMb
                if (-not $exportPlan.Split) {
                    Copy-Item -LiteralPath $tmpWim -Destination (Join-Path $DestSourcesDir 'install.wim') -Force
                    & $log ("wim-split: exported WIM {0:N2} GB is under 512 MB. Copied as install.wim." -f ($exportedLen / 1GB))
                    & $prog 100
                    $placedWim = $true
                    $exportedLen = 0
                } else {
                    $spanMb = [int]$exportPlan.FileSizeMb
                    & $log ("wim-split: exported WIM {0:N2} GB - splitting into install.swm with /FileSize:{1} MB" -f ($exportedLen / 1GB), $spanMb)
                }
                Get-ChildItem -LiteralPath $DestSourcesDir -Filter 'install*.swm' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
                $swm = Join-Path $DestSourcesDir 'install.swm'
                if ($exportedLen -le 0) {
                    # Exported image already fits in one FAT32 file. Skip /Split-Image.
                } elseif ($Progress) {
                    # Opt-in live progress: poll growing install*.swm bytes against the
                    # exported tmp WIM length. Same flags / same output as sync branch.
                    $denom   = (Get-Item -LiteralPath $tmpWim).Length
                    $g       = [guid]::NewGuid().ToString('N')
                    $outFile = Join-Path $env:TEMP ("LW-Split-$g.out")
                    $errFile = Join-Path $env:TEMP ("LW-Split-$g.err")
                    try {
                        $proc = Start-Process dism.exe -ArgumentList @(
                            '/Split-Image',
                            "/ImageFile:`"$tmpWim`"",
                            "/SWMFile:`"$swm`"",
                            "/FileSize:$spanMb",
                            '/CheckIntegrity'
                        ) -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
                        # Retain the handle so $proc.ExitCode is readable after exit (else $null
                        # -> false "failed (exit ):"). See the install.wim branch for detail.
                        $null = $proc.Handle
                        while (-not $proc.HasExited) {
                            Start-Sleep -Seconds 1
                            try {
                                $done = (Get-ChildItem -LiteralPath $DestSourcesDir -Filter 'install*.swm' -ErrorAction SilentlyContinue |
                                    Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                                if (-not $done) { $done = 0 }
                                & $prog ([math]::Min(99, [int](100 * $done / [math]::Max($denom, 1))))
                            } catch { }
                        }
                        $proc.WaitForExit()
                        $exit = $proc.ExitCode
                        $cap = ''
                        if (Test-Path -LiteralPath $outFile) { $cap += (Get-Content -Raw -LiteralPath $outFile -ErrorAction SilentlyContinue) }
                        if (Test-Path -LiteralPath $errFile) { $cap += (Get-Content -Raw -LiteralPath $errFile -ErrorAction SilentlyContinue) }
                        $splitOk = ($exit -eq 0) -or (($null -eq $exit) -and ($cap -match 'The operation completed successfully'))
                        if (-not $splitOk) {
                            throw "DISM /Split-Image (esd) failed (exit $exit): $cap"
                        }
                    } finally {
                        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
                        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
                    }
                    & $prog 100
                } else {
                    $o = & dism.exe /Split-Image /ImageFile:"$tmpWim" /SWMFile:"$swm" /FileSize:$spanMb /CheckIntegrity 2>&1
                    if ($LASTEXITCODE -ne 0) { throw "DISM /Split-Image (esd) failed (exit $LASTEXITCODE): $($o -join ' | ')" }
                }
            } finally {
                Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
            }
            Remove-Item -LiteralPath (Join-Path $DestSourcesDir 'install.esd') -Force -ErrorAction SilentlyContinue
            if (-not $placedWim) {
                if (-not (Test-Path -LiteralPath (Join-Path $DestSourcesDir 'install.swm'))) { throw "wim-split: install.swm was not produced from install.esd" }
                $chunks = @(Get-ChildItem -LiteralPath $DestSourcesDir -Filter 'install*.swm' -ErrorAction SilentlyContinue)
                if ($chunks.Count -lt 2) {
                    throw ("wim-split: exported install image is {0:N2} GB and /FileSize:{1} MB requires at least 2 SWM chunks, but only {2} .swm file was produced" -f ($exportedLen / 1GB), $spanMb, $chunks.Count)
                }
                & $log ("wim-split: produced {0} .swm chunk(s) from install.esd; monolithic install.esd omitted from FAT32 volume" -f $chunks.Count)
            }
        }
    } else {
        throw "Single layout: no install.wim or install.esd found under '$SourceSourcesDir' to place on the FAT32 volume"
    }
}

# ---------------------------------------------------------------------------
# Windows SKU (Home/Pro) + ISO lookup. Presplit identity is arch + Windows
# version (ISO name slug) + SKU. Not LoneWolf vs Quick Install.
# Write layout: Staging\ISO\ is a single blanket folder. Filenames carry
# edition + arch, e.g. 25h2_home_9.10(amd64).ISO / 25h2_pro_9.10(arm64).ISO.
# Read also accepts legacy ISO\Home, ISO\Pro, and untagged Pro files in ISO\
# or Staging\. Home never falls back to Pro (name must contain home vs pro).
# ---------------------------------------------------------------------------
function Get-LWWindowsEdition {
    param([string] $Edition)
    $e = ([string]$Edition).Trim()
    if ($e -match '^(?i)home$') { return 'Home' }
    return 'Pro'
}

function Get-LWBareArch {
    param([string] $Arch)
    $a = ([string]$Arch).ToUpperInvariant()
    if ([string]::IsNullOrWhiteSpace($a)) { return 'AMD64' }
    $a = [regex]::Replace($a, '^(QUICK-INSTALL-|WIN-INSTALL-|LONEWOLF-)', '')
    if ($a -match 'ARM') { return 'ARM64' }
    if ($a -match 'AMD' -or $a -match 'X64') { return 'AMD64' }
    return $a
}

function Get-LWIsoEditionFromName {
    param([string] $Name)
    $base = [System.IO.Path]::GetFileNameWithoutExtension($Name)
    if ($base -match '(?i)(^|[^a-z0-9])home([^a-z0-9]|$)') { return 'Home' }
    if ($base -match '(?i)(^|[^a-z0-9])pro([^a-z0-9]|$)') { return 'Pro' }
    return $null
}

function Test-LWIsoMatchesEdition {
    param(
        [Parameter(Mandatory)] [string] $FullName,
        [string] $Edition
    )
    $want = Get-LWWindowsEdition $Edition
    # Check the leaf and a few parent segments so Keyes LCU work dirs like
    # ...\amd64-Home\media (and ISO names like 25h2-home-....iso) all match.
    $cursor = $FullName
    for ($i = 0; $i -lt 4 -and -not [string]::IsNullOrWhiteSpace($cursor); $i++) {
        $leaf = [System.IO.Path]::GetFileName($cursor.TrimEnd('\', '/'))
        if (-not [string]::IsNullOrWhiteSpace($leaf)) {
            $fromName = Get-LWIsoEditionFromName $leaf
            if ($fromName) { return ($fromName -eq $want) }
        }
        try {
            $next = [System.IO.Path]::GetDirectoryName($cursor)
        } catch {
            $next = $null
        }
        if ([string]::IsNullOrWhiteSpace($next) -or $next -eq $cursor) { break }
        $cursor = $next
    }
    # Untagged file in a non-SKU folder (flat ISO\ or Staging\): Pro-only legacy.
    return ($want -eq 'Pro')
}

function Get-LWIsoSearchDirs {
    param(
        [Parameter(Mandatory)] [string] $StagingRoot,
        [Parameter(Mandatory)] [string] $IsoRoot,
        [string] $Edition
    )
    $ed = Get-LWWindowsEdition $Edition
    $dirs = New-Object System.Collections.Generic.List[string]
    $dirs.Add($IsoRoot)
    $dirs.Add((Join-Path $IsoRoot $ed))
    $dirs.Add($StagingRoot)
    return @($dirs)
}

function Find-LWWindowsIso {
    param(
        [Parameter(Mandatory)] [string] $StagingRoot,
        [Parameter(Mandatory)] [string] $IsoRoot,
        [Parameter(Mandatory)] [string] $Arch,
        [string] $Edition,
        [string] $FallbackIsoRoot = ''
    )
    $ed = Get-LWWindowsEdition $Edition
    $arch = Get-LWBareArch $Arch
    $seen = @{}
    $hits = New-Object System.Collections.Generic.List[System.IO.FileInfo]
    foreach ($dir in @(Get-LWIsoSearchDirs -StagingRoot $StagingRoot -IsoRoot $IsoRoot -Edition $ed)) {
        if ([string]::IsNullOrWhiteSpace($dir) -or -not (Test-Path -LiteralPath $dir)) { continue }
        $files = @(Get-ChildItem -LiteralPath $dir -File -Filter '*.iso' -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -like "*($arch)*.iso" -and
                (Test-LWIsoMatchesEdition -FullName $_.FullName -Edition $ed)
            })
        foreach ($f in $files) {
            if (-not $seen.ContainsKey($f.FullName)) {
                $seen[$f.FullName] = $true
                [void]$hits.Add($f)
            }
        }
    }
    if ($hits.Count -gt 0) {
        return ($hits | Sort-Object LastWriteTime -Descending | Select-Object -First 1)
    }
    # Destage: share miss only — do not merge fallback into the primary newest-wins set.
    if ([string]::IsNullOrWhiteSpace($FallbackIsoRoot)) { return $null }
    $fb = $FallbackIsoRoot.Trim()
    $same = $false
    try {
        $isoFull = [IO.Path]::GetFullPath($IsoRoot).TrimEnd('\')
        $fbFull = [IO.Path]::GetFullPath($fb).TrimEnd('\')
        $same = ($isoFull -eq $fbFull)
    } catch { }
    if ($same) { return $null }
    return Find-LWWindowsIso -StagingRoot $fb -IsoRoot $fb -Arch $arch -Edition $ed
}

function Get-LWMissingHomeIsoMessage {
    param([string] $Arch, [string] $IsoHomeDir)
    $a = Get-LWBareArch $Arch
    $dir = $IsoHomeDir
    if ([string]::IsNullOrWhiteSpace($dir)) { $dir = 'Staging\ISO' }
    return "No Windows Home ISO for $a in $dir. Place a *($a)*.iso with home in the name under ISO\ (do not use the Pro image)."
}

function Get-LWPreSplitCurrentKey {
    param([string] $Arch, [string] $Edition)
    return ("{0}-{1}" -f (Get-LWBareArch $Arch), (Get-LWWindowsEdition $Edition))
}

function Test-LWPreSplitFolderMatches {
    param(
        [Parameter(Mandatory)] [string] $FolderName,
        [Parameter(Mandatory)] [string] $Arch,
        [string] $Edition,
        [switch] $RequireArchInName
    )
    $ed = Get-LWWindowsEdition $Edition
    $arch = Get-LWBareArch $Arch
    $fromEd = Get-LWIsoEditionFromName $FolderName
    if ($fromEd -and $fromEd -ne $ed) { return $false }
    $n = $FolderName.ToLowerInvariant()
    $hasAmd = [bool]($n -match '(?i)(^|[^a-z0-9])(amd64|x64)([^a-z0-9]|$)')
    $hasArm = [bool]($n -match '(?i)(^|[^a-z0-9])arm64([^a-z0-9]|$)')
    if ($arch -eq 'ARM64' -and $hasAmd -and -not $hasArm) { return $false }
    if ($arch -eq 'AMD64' -and $hasArm -and -not $hasAmd) { return $false }
    if ($RequireArchInName) {
        if ($arch -eq 'ARM64') { return $hasArm }
        if ($arch -eq 'AMD64') { return $hasAmd }
    }
    return $true
}

function Get-LWPreSplitScanDirs {
    param(
        [Parameter(Mandatory)] [string] $PreSplitRoot,
        [Parameter(Mandatory)] [string] $Arch,
        [string] $Edition
    )
    if ([string]::IsNullOrWhiteSpace($PreSplitRoot)) { return @() }
    $ed = Get-LWWindowsEdition $Edition
    $arch = Get-LWBareArch $Arch
    $dirs = New-Object System.Collections.Generic.List[string]
    $dirs.Add($PreSplitRoot)
    $dirs.Add((Join-Path (Join-Path $PreSplitRoot $arch) $ed))
    if ($ed -eq 'Pro') {
        $dirs.Add((Join-Path $PreSplitRoot $arch))
    }
    return @($dirs)
}

function Get-LWPreSplitCandidateDirs {
    param(
        [Parameter(Mandatory)] [string] $PreSplitRoot,
        [Parameter(Mandatory)] [string] $Arch,
        [string] $Edition
    )
    if ([string]::IsNullOrWhiteSpace($PreSplitRoot)) { return @() }
    $ed = Get-LWWindowsEdition $Edition
    $arch = Get-LWBareArch $Arch
    $key = Get-LWPreSplitCurrentKey -Arch $arch -Edition $ed
    $out = New-Object System.Collections.Generic.List[string]
    $seen = @{}

    $rootFull = $null
    try { $rootFull = [IO.Path]::GetFullPath($PreSplitRoot).TrimEnd('\') } catch { }

    foreach ($scanDir in @(Get-LWPreSplitScanDirs -PreSplitRoot $PreSplitRoot -Arch $arch -Edition $ed)) {
        if ([string]::IsNullOrWhiteSpace($scanDir) -or -not (Test-Path -LiteralPath $scanDir)) { continue }
        $scanFull = $scanDir
        try { $scanFull = [IO.Path]::GetFullPath($scanDir).TrimEnd('\') } catch { }
        $isRoot = ($rootFull -and ($scanFull -eq $rootFull))

        $pending = New-Object System.Collections.Generic.List[string]
        foreach ($markerName in @('current.json', 'current')) {
            $marker = Join-Path $scanDir $markerName
            if (-not (Test-Path -LiteralPath $marker)) { continue }
            try {
                $mk = Get-Content -Raw -LiteralPath $marker -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                $propNames = @($mk.PSObject.Properties.Name)
                $isKeyedMap = $false
                foreach ($pn in $propNames) {
                    if ($pn -match '^(?i)(AMD64|ARM64)-(Home|Pro)$') { $isKeyedMap = $true; break }
                }
                $entry = $null
                if ($isKeyedMap) {
                    # Only the matching arch+SKU key. Never treat the whole map (or an
                    # AMD64-* entry) as current for ARM64.
                    if ($propNames -contains $key) { $entry = $mk.$key }
                } elseif ($propNames -contains 'imageVersion') {
                    $mkEd = $null
                    $mkArch = $null
                    if ($mk.PSObject.Properties['windowsEdition'] -and $mk.windowsEdition) {
                        $mkEd = Get-LWWindowsEdition ([string]$mk.windowsEdition)
                    }
                    if ($mk.PSObject.Properties['arch'] -and $mk.arch) {
                        $mkArch = Get-LWBareArch ([string]$mk.arch)
                    }
                    if ($isRoot) {
                        # A single root current without arch is global and would make
                        # ARM64 Stage ISO / Rebuild follow the AMD64 set.
                        if ($mkArch -and $mkArch -eq $arch -and ((-not $mkEd) -or ($mkEd -eq $ed))) {
                            $entry = $mk
                        }
                    } else {
                        $edOk = (-not $mkEd) -or ($mkEd -eq $ed)
                        $archOk = (-not $mkArch) -or ($mkArch -eq $arch)
                        if ($edOk -and $archOk) { $entry = $mk }
                    }
                }
                $iv = $null
                if ($entry -is [string]) { $iv = $entry }
                elseif ($entry -and $entry.PSObject.Properties['imageVersion']) { $iv = [string]$entry.imageVersion }
                if ($iv -and (Test-LWPreSplitFolderMatches -FolderName $iv -Arch $arch -Edition $ed -RequireArchInName:$isRoot)) {
                    [void]$pending.Add((Join-Path $scanDir $iv))
                }
            } catch { }
        }

        foreach ($d in @(Get-ChildItem -LiteralPath $scanDir -Directory -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending)) {
            if ($d.Name -like '*.tmp-*') { continue }
            if ($d.Name -match '^(?i)(AMD64|ARM64|Home|Pro)$') { continue }
            if (-not (Test-LWPreSplitFolderMatches -FolderName $d.Name -Arch $arch -Edition $ed -RequireArchInName:$isRoot)) { continue }
            [void]$pending.Add($d.FullName)
        }

        foreach ($p in $pending) {
            if ([string]::IsNullOrWhiteSpace($p)) { continue }
            $full = $p
            try { $full = [IO.Path]::GetFullPath($p) } catch { }
            if (-not $seen.ContainsKey($full) -and (Test-Path -LiteralPath $p)) {
                $seen[$full] = $true
                [void]$out.Add($p)
            }
        }
    }
    return @($out)
}

function Write-LWPreSplitCurrentMarkers {
    param(
        [Parameter(Mandatory)] [string] $PreSplitRoot,
        [string] $SetDir,
        [Parameter(Mandatory)] [string] $Arch,
        [string] $Edition,
        [Parameter(Mandatory)] [string] $ImageVersion,
        [string] $UpdatedUtc,
        [string] $InstallLcuKb = '',
        [string] $OsBuild = ''
    )
    if ([string]::IsNullOrWhiteSpace($PreSplitRoot)) { return }
    $ed = Get-LWWindowsEdition $Edition
    $arch = Get-LWBareArch $Arch
    if ([string]::IsNullOrWhiteSpace($UpdatedUtc)) {
        $UpdatedUtc = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    }
    $imageBuildDate = [string](Get-LWCanonicalImageBuildDateYmd -ImageVersion $ImageVersion -UpdatedUtc $UpdatedUtc)
    $payload = [ordered]@{
        imageVersion    = $ImageVersion
        imageBuildDate  = $imageBuildDate
        windowsEdition  = $ed
        arch            = $arch
        updatedUtc      = $UpdatedUtc
    }
    if (-not [string]::IsNullOrWhiteSpace($InstallLcuKb)) { $payload.installLcuKb = [string]$InstallLcuKb }
    if (-not [string]::IsNullOrWhiteSpace($OsBuild)) { $payload.osBuild = [string]$OsBuild }
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    if (-not [string]::IsNullOrWhiteSpace($SetDir) -and (Test-Path -LiteralPath $SetDir)) {
        try {
            [System.IO.File]::WriteAllText((Join-Path $SetDir 'current'), ($payload | ConvertTo-Json -Depth 6), $utf8)
        } catch { }
    }
    $key = Get-LWPreSplitCurrentKey -Arch $arch -Edition $ed
    $rootPath = Join-Path $PreSplitRoot 'current.json'
    $map = [ordered]@{}
    if (Test-Path -LiteralPath $rootPath) {
        try {
            $existing = Get-Content -Raw -LiteralPath $rootPath -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            foreach ($p in $existing.PSObject.Properties) {
                $map[$p.Name] = $p.Value
            }
        } catch { }
    }
    $map[$key] = $payload
    if (-not (Test-Path -LiteralPath $PreSplitRoot)) {
        New-Item -ItemType Directory -Force -Path $PreSplitRoot | Out-Null
    }
    try {
        [System.IO.File]::WriteAllText($rootPath, ($map | ConvertTo-Json -Depth 6), $utf8)
    } catch { }
    # Remote SoT for available Windows image versioning (share / Drive upload).
    try { Write-LWRemoteVersionJson -PreSplitRoot $PreSplitRoot } catch { }
}

# ---------------------------------------------------------------------------
# Write-LWRemoteVersionJson / Read-LWRemoteVersionSku
#   version.json beside current.json — per-SKU imageVersion + imageBuildDate.
#   Canonical display/compare date heals UUP ISO LastWrite traps (2024-04-01)
#   when updatedUtc / staging day is the real Image Ready day.
# ---------------------------------------------------------------------------
function Write-LWRemoteVersionJson {
    param(
        [Parameter(Mandatory)] [string] $PreSplitRoot
    )
    if ([string]::IsNullOrWhiteSpace($PreSplitRoot)) { return }
    if (-not (Test-Path -LiteralPath $PreSplitRoot)) {
        New-Item -ItemType Directory -Force -Path $PreSplitRoot | Out-Null
    }
    $currentPath = Join-Path $PreSplitRoot 'current.json'
    $skus = [ordered]@{}
    $newestUtc = ''
    if (Test-Path -LiteralPath $currentPath) {
        try {
            $map = Get-Content -Raw -LiteralPath $currentPath -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            foreach ($p in $map.PSObject.Properties) {
                if ($p.Name -notmatch '^(AMD64|ARM64)-(Home|Pro)$') { continue }
                $entry = $p.Value
                $iv = ''
                $ed = ''
                $arch = ''
                $upd = ''
                $explicit = ''
                $lcuKb = ''
                $osBuild = ''
                if ($entry -is [string]) {
                    $iv = [string]$entry
                } elseif ($entry) {
                    try { if ($entry.PSObject.Properties['imageVersion']) { $iv = [string]$entry.imageVersion } } catch { }
                    try { if ($entry.PSObject.Properties['windowsEdition']) { $ed = [string]$entry.windowsEdition } } catch { }
                    try { if ($entry.PSObject.Properties['arch']) { $arch = [string]$entry.arch } } catch { }
                    try { if ($entry.PSObject.Properties['updatedUtc']) { $upd = [string]$entry.updatedUtc } } catch { }
                    try { if ($entry.PSObject.Properties['imageBuildDate']) { $explicit = [string]$entry.imageBuildDate } } catch { }
                    try { if ($entry.PSObject.Properties['installLcuKb']) { $lcuKb = [string]$entry.installLcuKb } } catch { }
                    try { if ($entry.PSObject.Properties['osBuild']) { $osBuild = [string]$entry.osBuild } } catch { }
                }
                if ([string]::IsNullOrWhiteSpace($iv)) { continue }
                if (-not $arch -or -not $ed) {
                    $parts = $p.Name -split '-', 2
                    if (-not $arch) { $arch = $parts[0] }
                    if (-not $ed) { $ed = $parts[1] }
                }
                $arch = Get-LWBareArch $arch
                $ed = Get-LWWindowsEdition $ed
                $ymd = [string](Get-LWCanonicalImageBuildDateYmd -ImageVersion $iv -UpdatedUtc $upd -ExplicitBuildDate $explicit)
                $skuDoc = [ordered]@{
                    arch           = $arch
                    windowsEdition = $ed
                    imageVersion   = $iv
                    imageBuildDate = $ymd
                    updatedUtc     = $upd
                }
                if (-not [string]::IsNullOrWhiteSpace($lcuKb)) { $skuDoc.installLcuKb = $lcuKb }
                if (-not [string]::IsNullOrWhiteSpace($osBuild)) { $skuDoc.osBuild = $osBuild }
                $skus[$p.Name] = $skuDoc
                if ($upd -and ($upd -gt $newestUtc)) { $newestUtc = $upd }
            }
        } catch { }
    }
    if ([string]::IsNullOrWhiteSpace($newestUtc)) {
        $newestUtc = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    }
    $doc = [ordered]@{
        schema     = 1
        kind       = 'lonewolf-windows-image-version'
        updatedUtc = $newestUtc
        skus       = $skus
    }
    $outPath = Join-Path $PreSplitRoot 'version.json'
    [System.IO.File]::WriteAllText($outPath, ($doc | ConvertTo-Json -Depth 8),
        [System.Text.UTF8Encoding]::new($false))
}

function Read-LWRemoteVersionSku {
    param(
        [Parameter(Mandatory)] [string] $PreSplitRoot,
        [Parameter(Mandatory)] [string] $Arch,
        [string] $Edition = 'Pro'
    )
    $key = Get-LWPreSplitCurrentKey -Arch $Arch -Edition $Edition
    $verPath = Join-Path $PreSplitRoot 'version.json'
    if (Test-Path -LiteralPath $verPath) {
        try {
            $doc = Get-Content -Raw -LiteralPath $verPath -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $skus = $null
            if ($doc.PSObject.Properties['skus'] -and $doc.skus) { $skus = $doc.skus }
            elseif ($doc.PSObject.Properties['imageVersions'] -and $doc.imageVersions) { $skus = $doc.imageVersions }
            else { $skus = $doc }
            if ($skus -and $skus.PSObject.Properties[$key]) {
                $e = $skus.$key
                $iv = ''
                $ymd = ''
                $upd = ''
                $lcuKb = ''
                $osBuild = ''
                if ($e -is [string]) { $iv = [string]$e }
                else {
                    try { if ($e.PSObject.Properties['imageVersion']) { $iv = [string]$e.imageVersion } } catch { }
                    try { if ($e.PSObject.Properties['imageBuildDate']) { $ymd = [string]$e.imageBuildDate } } catch { }
                    try { if ($e.PSObject.Properties['updatedUtc']) { $upd = [string]$e.updatedUtc } } catch { }
                    try { if ($e.PSObject.Properties['installLcuKb']) { $lcuKb = [string]$e.installLcuKb } } catch { }
                    try { if ($e.PSObject.Properties['osBuild']) { $osBuild = [string]$e.osBuild } } catch { }
                }
                if ($iv) {
                    if (-not $ymd) {
                        $ymd = [string](Get-LWCanonicalImageBuildDateYmd -ImageVersion $iv -UpdatedUtc $upd)
                    }
                    return [pscustomobject]@{
                        imageVersion   = $iv
                        imageBuildDate = $ymd
                        updatedUtc     = $upd
                        installLcuKb   = $lcuKb
                        osBuild        = $osBuild
                        source         = 'version.json'
                    }
                }
            }
        } catch { }
    }
    $curPath = Join-Path $PreSplitRoot 'current.json'
    if (Test-Path -LiteralPath $curPath) {
        try {
            $map = Get-Content -Raw -LiteralPath $curPath -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if ($map.PSObject.Properties[$key] -and $map.$key) {
                $e = $map.$key
                $iv = ''
                $upd = ''
                $explicit = ''
                $lcuKb = ''
                $osBuild = ''
                if ($e -is [string]) { $iv = [string]$e }
                else {
                    try { if ($e.PSObject.Properties['imageVersion']) { $iv = [string]$e.imageVersion } } catch { }
                    try { if ($e.PSObject.Properties['updatedUtc']) { $upd = [string]$e.updatedUtc } } catch { }
                    try { if ($e.PSObject.Properties['imageBuildDate']) { $explicit = [string]$e.imageBuildDate } } catch { }
                    try { if ($e.PSObject.Properties['installLcuKb']) { $lcuKb = [string]$e.installLcuKb } } catch { }
                    try { if ($e.PSObject.Properties['osBuild']) { $osBuild = [string]$e.osBuild } } catch { }
                }
                if ($iv) {
                    $ymd = [string](Get-LWCanonicalImageBuildDateYmd -ImageVersion $iv -UpdatedUtc $upd -ExplicitBuildDate $explicit)
                    return [pscustomobject]@{
                        imageVersion   = $iv
                        imageBuildDate = $ymd
                        updatedUtc     = $upd
                        installLcuKb   = $lcuKb
                        osBuild        = $osBuild
                        source         = 'current.json'
                    }
                }
            }
        } catch { }
    }
    return $null
}

# ---------------------------------------------------------------------------
# Test-LWPreSplitSourceMatchesIso
#   True when a presplit-manifest.json source block matches this ISO / SkipISO
#   folder by name + size. LastWrite is optional (UUP/SkipISO often preserves
#   bogus media timestamps that must not drive identity).
# ---------------------------------------------------------------------------
function Test-LWPreSplitSourceMatchesIso {
    param(
        $Manifest,
        [Parameter(Mandatory)] [System.IO.FileSystemInfo] $Iso,
        [switch] $RequireLastWrite,
        [int] $LastWriteToleranceSec = 2
    )
    if (-not $Manifest) { return $false }
    $src = $null
    try {
        if ($Manifest.PSObject.Properties['source'] -and $Manifest.source) { $src = $Manifest.source }
    } catch { }
    if (-not $src) { return $false }
    if ([string]$src.isoName -ne $Iso.Name) { return $false }
    try {
        if ([long]$src.isoSizeBytes -ne [long]$Iso.Length) { return $false }
    } catch { return $false }
    if (-not $RequireLastWrite) { return $true }
    $mDate = $null
    try {
        $mDate = [datetime]::Parse([string]$src.isoLastWriteUtc, $null,
            [System.Globalization.DateTimeStyles]::RoundtripKind)
    } catch { return $false }
    $delta = [math]::Abs(($mDate.ToUniversalTime() - $Iso.LastWriteTimeUtc).TotalSeconds)
    return ($delta -le $LastWriteToleranceSec)
}

# ---------------------------------------------------------------------------
# Get-LWImageVersionId
#   PreSplit / Image Ready folder identity:
#     slug  = base filename (ISO w/o extension, or folder name) lowercased,
#             each run of [^a-z0-9]+ collapsed to '-', trimmed of leading/trailing '-'
#     sku   = home | pro (appended when not already in the slug)
#     stamp = staging UTC as 'yyyyMMddTHHmmssZ' (NOT ISO LastWriteTime — UUP/SkipISO
#             media often carries preserved 2024-era timestamps that are not the
#             rebuild day; trailing stamp drives the launcher pill + USB compare)
#     id    = "<slug>-<stamp>"  (sku already in slug when present)
#   Pass -StampUtc when minting a new set (producers use UtcNow). Matching an
#   existing set uses Test-LWPreSplitSourceMatchesIso / current.json — do not
#   recompute this id from LastWriteTime and expect string equality.
# ---------------------------------------------------------------------------
function Get-LWImageVersionId {
    param(
        [Parameter(Mandatory)] [System.IO.FileSystemInfo] $Iso,
        [string] $Edition = '',
        [DateTime] $StampUtc = [DateTime]::MinValue
    )
    # ISO files: strip .iso. SkipISO media folders use the ISO basename (e.g.
    # 25h2_home_10.12(amd64)) — do not treat ".12(amd64)" as an extension.
    if ($Iso.PSIsContainer) {
        $base = $Iso.Name
    } else {
        $base = [System.IO.Path]::GetFileNameWithoutExtension($Iso.Name)
    }
    $slug = $base.ToLowerInvariant()
    $slug = [regex]::Replace($slug, '[^a-z0-9]+', '-')
    $slug = $slug.Trim('-')
    if (-not [string]::IsNullOrWhiteSpace($Edition)) {
        $ed = (Get-LWWindowsEdition $Edition).ToLowerInvariant()
        if ($slug -notmatch [regex]::Escape($ed)) { $slug = "$slug-$ed" }
    }
    if ($StampUtc -eq [DateTime]::MinValue) {
        $StampUtc = [DateTime]::UtcNow
    } elseif ($StampUtc.Kind -eq [DateTimeKind]::Unspecified) {
        $StampUtc = [DateTime]::SpecifyKind($StampUtc, [DateTimeKind]::Utc)
    }
    $stamp = $StampUtc.ToUniversalTime().ToString("yyyyMMdd'T'HHmmss'Z'")
    return "$slug-$stamp"
}

# Calendar date from a PreSplit folder / imageVersionId trailing stamp.
# e.g. 25h2-home-9-22-amd64-20261005T164435Z → 2026-10-05
function Get-LWImageVersionBuildDateYmd {
    param([string] $ImageVersion)
    if ([string]::IsNullOrWhiteSpace($ImageVersion)) { return '' }
    if ($ImageVersion -match '(\d{8})T\d{6}Z$') {
        $d = $Matches[1]
        return ('{0}-{1}-{2}' -f $d.Substring(0, 4), $d.Substring(4, 2), $d.Substring(6, 2))
    }
    return ''
}

# Canonical Windows image calendar day for display / rebuild advice.
# Prefers an explicit imageBuildDate, then the folder stamp — unless that stamp
# is clearly a UUP/SkipISO preserved LastWrite (days before staging updatedUtc),
# in which case the staging day wins (e.g. stamp 2024-04-01 + updatedUtc 2026-10-13
# → 2026-10-13).
function Get-LWCanonicalImageBuildDateYmd {
    param(
        [string] $ImageVersion,
        [string] $UpdatedUtc = '',
        [string] $ExplicitBuildDate = ''
    )
    if ($ExplicitBuildDate -match '^(\d{4}-\d{2}-\d{2})') {
        return $Matches[1]
    }
    $stampYmd = [string](Get-LWImageVersionBuildDateYmd -ImageVersion $ImageVersion)
    $updYmd = ''
    if (-not [string]::IsNullOrWhiteSpace($UpdatedUtc)) {
        try {
            $dt = [datetime]::Parse([string]$UpdatedUtc, $null,
                [System.Globalization.DateTimeStyles]::RoundtripKind)
            $updYmd = $dt.ToUniversalTime().ToString('yyyy-MM-dd')
        } catch {
            if ($UpdatedUtc -match '^(\d{4}-\d{2}-\d{2})') { $updYmd = $Matches[1] }
        }
    }
    if ($stampYmd -and $updYmd) {
        try {
            $stampDay = [datetime]::ParseExact($stampYmd, 'yyyy-MM-dd', $null)
            $updDay = [datetime]::ParseExact($updYmd, 'yyyy-MM-dd', $null)
            if ($stampDay -lt $updDay.AddDays(-2)) { return $updYmd }
        } catch { }
    }
    if ($stampYmd) { return $stampYmd }
    if ($updYmd) { return $updYmd }
    return ''
}

# ---------------------------------------------------------------------------
# Test-LWPreSplitSet
#   Integrity validator for a staged pre-split set folder. Used by the producer
#   ("already-staged" check + post-copy verify), the builder (Get-LWPreSplitSet),
#   and Get-StagingVersion.ps1 so the same rules apply everywhere. Never throws -
#   returns a result object with Valid/Reason/Manifest.
#     - manifest parses
#     - every chunk.name exists with the EXACT chunk.sizeBytes (mandatory)
#     - sha256 checked only when -VerifyHash AND the manifest carries a hash
#   NOTE: this validates the SET only. Matching the set against a specific ISO
#   (name/size/last-write) is the caller's responsibility.
#   A finished set is install.swm + install2.swm (or more). One install.wim
#   or install.esd is valid only when the image is under 512 MiB. A one-file
#   set for a larger image is invalid so Stage ISO re-stages it.
# ---------------------------------------------------------------------------
function Get-LWPreSplitChunkLayoutReason {
    param(
        [System.Collections.IEnumerable] $Chunks,
        [long] $OriginalBytes = 0
    )
    $list = @($Chunks)
    $swm = @($list | Where-Object { [string]$_.name -match '(?i)^install\d*\.swm$' })
    $single = @($list | Where-Object { [string]$_.name -match '(?i)^install\.(wim|esd)$' })
    if ($swm.Count -ge 2 -and $single.Count -eq 0 -and $list.Count -eq $swm.Count) {
        return $null
    }
    $tinyBytes = [long]512MB
    if ($single.Count -eq 1 -and $swm.Count -eq 0 -and $list.Count -eq 1) {
        $bytes = $OriginalBytes
        if ($bytes -le 0) { $bytes = [long]$single[0].sizeBytes }
        if ($bytes -lt $tinyBytes) { return $null }
        return "single $($single[0].name) for a $bytes-byte image; images at or above 512 MiB must be at least two install*.swm chunks"
    }
    if ($swm.Count -eq 1) {
        return 'only one install*.swm chunk was staged; at least two are required'
    }
    return 'pre-split set must be at least two install*.swm chunks, or one install.wim/esd under 512 MiB'
}

function Get-LWPreSplitChunkDir {
    param(
        [Parameter(Mandatory)] [string] $SetDir
    )
    if ([string]::IsNullOrWhiteSpace($SetDir)) { return $SetDir }
    $sources = Join-Path $SetDir 'sources'
    if (Test-Path -LiteralPath $sources -PathType Container) {
        $hit = @(Get-ChildItem -LiteralPath $sources -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^install(\d*)\.(swm|wim|esd)$' })
        if ($hit.Count -gt 0) { return $sources }
    }
    return $SetDir
}

function Test-LWPreSplitSet {
    param(
        [Parameter(Mandatory)] [string] $SetDir,
        [switch] $VerifyHash
    )
    $result = [pscustomobject]@{ Valid = $false; Reason = ''; Manifest = $null }
    try {
        if ([string]::IsNullOrWhiteSpace($SetDir) -or -not (Test-Path -LiteralPath $SetDir)) {
            $result.Reason = "set folder not found: $SetDir"; return $result
        }
        $chunkDir = Get-LWPreSplitChunkDir -SetDir $SetDir
        $manifestPath = Join-Path $SetDir 'presplit-manifest.json'
        if (-not (Test-Path -LiteralPath $manifestPath)) {
            $result.Reason = "presplit-manifest.json missing in $SetDir"; return $result
        }
        try {
            $m = Get-Content -Raw -LiteralPath $manifestPath -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        } catch {
            $result.Reason = "presplit-manifest.json unreadable/unparseable: $($_.Exception.Message)"; return $result
        }
        $result.Manifest = $m
        $chunks = @()
        if ($m.PSObject.Properties['install'] -and $m.install -and $m.install.PSObject.Properties['chunks']) {
            $chunks = @($m.install.chunks)
        }
        if ($chunks.Count -eq 0) { $result.Reason = 'manifest lists no chunks'; return $result }
        foreach ($c in $chunks) {
            $name = [string]$c.name
            if ([string]::IsNullOrWhiteSpace($name)) { $result.Reason = 'manifest chunk with empty name'; return $result }
            $chunkPath = Join-Path $chunkDir $name
            if (-not (Test-Path -LiteralPath $chunkPath)) { $result.Reason = "chunk missing: $name"; return $result }
            $actual   = (Get-Item -LiteralPath $chunkPath).Length
            $expected = [long]$c.sizeBytes
            if ($actual -ne $expected) {
                $result.Reason = "chunk size mismatch for '$name' (manifest $expected, on-disk $actual)"; return $result
            }
            if ($VerifyHash -and $c.PSObject.Properties['sha256'] -and $c.sha256) {
                $h = (Get-FileHash -LiteralPath $chunkPath -Algorithm SHA256 -ErrorAction Stop).Hash
                if ($h -ne ([string]$c.sha256)) { $result.Reason = "chunk sha256 mismatch for '$name'"; return $result }
            }
        }
        $originalBytes = [long]0
        if ($m.PSObject.Properties['install'] -and $m.install -and
            $m.install.PSObject.Properties['originalWimSizeBytes'] -and
            $null -ne $m.install.originalWimSizeBytes) {
            try { $originalBytes = [long]$m.install.originalWimSizeBytes } catch { $originalBytes = [long]0 }
        }
        $layoutReason = Get-LWPreSplitChunkLayoutReason -Chunks $chunks -OriginalBytes $originalBytes
        if ($layoutReason) { $result.Reason = [string]$layoutReason; return $result }
        $result.Valid  = $true
        $result.Reason = 'ok'
        return $result
    } catch {
        $result.Reason = "validation error: $($_.Exception.Message)"
        return $result
    }
}

function Test-LwPreSplitMediaPackage {
    param(
        [Parameter(Mandatory)] [string] $SetDir
    )
    if ([string]::IsNullOrWhiteSpace($SetDir) -or -not (Test-Path -LiteralPath $SetDir)) { return $false }
    $chk = Test-LWPreSplitSet -SetDir $SetDir
    if (-not $chk.Valid) { return $false }
    $bootWim = Join-Path $SetDir 'sources\boot.wim'
    if (-not (Test-Path -LiteralPath $bootWim)) { return $false }
    $bootSdi = Join-Path $SetDir 'boot\boot.sdi'
    $efiBoot = Join-Path $SetDir 'efi'
    if (-not ((Test-Path -LiteralPath $bootSdi) -or (Test-Path -LiteralPath $efiBoot))) { return $false }
    return $true
}

function Test-LwPreSplitBootInjected {
    param(
        [Parameter(Mandatory)] [string] $SetDir
    )
    if (-not (Test-LwPreSplitMediaPackage -SetDir $SetDir)) { return $false }
    $sentinel = Join-Path $SetDir 'sources\boot.wim.lw-injected'
    $bootWim = Join-Path $SetDir 'sources\boot.wim'
    if (-not ((Test-Path -LiteralPath $sentinel) -and (Test-Path -LiteralPath $bootWim))) { return $false }
    try {
        if ((Get-Item -LiteralPath $sentinel).LastWriteTime -lt (Get-Item -LiteralPath $bootWim).LastWriteTime) { return $false }
    } catch { return $false }
    return $true
}
